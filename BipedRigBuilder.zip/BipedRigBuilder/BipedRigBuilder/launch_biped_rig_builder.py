"""Biped Rig Builder - paste into the Script Editor (Python tab) and press Ctrl+Enter.
(Middle-drag it to a shelf to get a button.)

The first time it asks for the folder that CONTAINS the biped_rig_builder folder, then
remembers it. Every run reloads the code, so edits show up without restarting Maya.
"""
import os
import sys

import maya.cmds as cmds

VAR = "bipedRigBuilder_folder"
PKG = "biped_rig_builder"


def _folder():
    path = cmds.optionVar(q=VAR) if cmds.optionVar(exists=VAR) else ""
    if path and os.path.isdir(os.path.join(path, PKG)):
        return path
    picked = cmds.fileDialog2(fileMode=3, caption="Pick the folder that contains '{}'".format(
        PKG))
    if not picked:
        return None
    path = picked[0]
    if not os.path.isdir(os.path.join(path, PKG)) and os.path.basename(path) == PKG:
        path = os.path.dirname(path)                  # they picked the package itself
    if not os.path.isdir(os.path.join(path, PKG)):
        cmds.error("No '{}' folder in {}".format(PKG, path))
    cmds.optionVar(stringValue=(VAR, path))
    return path


folder = _folder()
if folder:
    if folder not in sys.path:
        sys.path.insert(0, folder)
    for name in [m for m in sys.modules if m == PKG or m.startswith(PKG + ".")]:
        del sys.modules[name]                         # fresh code every run
    import biped_rig_builder
    biped_rig_builder.show()
