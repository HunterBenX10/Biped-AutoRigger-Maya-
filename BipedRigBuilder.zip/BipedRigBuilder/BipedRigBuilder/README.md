# Biped Rig Builder

Guides -> game-ready skeleton (UE5 mannequin names) -> preview rig with the reference rig
control layout, twist joints and skin.

## Install (drag and drop)
1. Unzip `BipedRigBuilder.zip` anywhere.
2. Drag `drag_drop_install.py` into the Maya viewport.
   It copies `biped_rig_builder` into your Maya scripts folder, adds a **BipedRig** button
   to the shelf that is open, and opens the tool. Drop it again to update.

Developer option: `launch_biped_rig_builder.py` runs the tool straight from the unzipped
folder (paste into the Script Editor, Ctrl+Enter) and reloads the code every run.

## Layout
| Folder / file | What's in it |
|---|---|
| `config.py` | every name, colour and path |
| `data/skeleton.json` | joint positions + orientation rules (world-aligned joints, aim overrides, limbs made planar at build, twist, mirror) |
| `data/guide_fit.json` | Fit-to-Mesh settings (limb reach, finger reach, spine depth) |
| `data/control_layout.json` | every reference rig ctrl/group: parent, anchor joint, relative matrix, CVs |
| `data/rig_rules.json` | grouping, switches, pole vectors, ctrl->joint hooks, shape-fit refs, skin exclusions, twist drive, channel locks |
| `core/` | `names` (sides/mirroring), `mathx` (matrices), `nodes` (undo, shapes, placement, locks), `mesh` (MeshSet + Raycaster), `template` (SkeletonTemplate), `data` (JSON loader) |
| `rig/guides.py` | `Guides` - create, live orientation, children follow, fit to mesh |
| `rig/skeleton.py` | `Skeleton` - build / delete, twist joints, mirror |
| `rig/controls.py` | `Controls` - rebuild the layout on any skeleton, fit shapes, switches, FK hooks, locks |
| `rig/systems.py` | `Systems` - FK/IK driver chains + blends, IK handles, pole vectors, stretch, foot-roll proxies, spline-IK spine, space switches, chest-corrective follow |
| `rig/deform.py` | `Deformation` - skin mesh, twist/chest-helper drivers, test poses (range of motion), mirror weights, unbind |
| `rig/correctives.py` | corrective joint rings (traps, shoulder, wrist, ankle): bend-driven, eased, auto weights |
| `rig/muscles.py` | muscle / volume joints (origin -> insertion, 1/sqrt volume) |
| `rig/fixmesh.py` | Fix Mesh: sculpt a bad pose, solved back into skin weights |
| `rig/twist.py` | twist-joint drivers (Twist Joints Creator setup), twist joint display |
| `rig/spaces.py` | Switch Space - change a space keeping the ctrl in place |
| `rig/skin.py` | bind + the adaptive solve (reads the skeleton / mesh for `weightmath`), weld |
| `rig/weightmath.py` | the solve itself - pure numpy, no Maya |
| `rig/preview.py` | `PreviewRig` - runs the stages, display toggles, remove |
| `ui/window.py` | `BuilderWindow` - buttons only |

## Changing things without touching code
- Different control layout: edit `data/control_layout.json` (or re-capture from a rig).
- Lock different channels: `locks` in `data/rig_rules.json` (regex -> "trs").
- New FK/IK switch: `switches` in `data/rig_rules.json`.
- Different skeleton proportions/orientation rules: `data/skeleton.json`.

## Rig features
- FK/IK arms, legs and spine (IK_FK_Switch on the switch ctrls and cog_ctrl: 1 = FK).
- Leg IK: reverse foot (heel, toe, ball, toe tap, banks) + the same as attrs on the IK ctrl.
- Stretchy IK arms/legs (`stretch` on the IK ctrls): elbow/knee and hand/foot IK joints slide out along their rest translate, so the limb still locks straight and follows the pole vector; follows World_ctrl scale.
- Spine: hip_ctrl pivots on the pelvis (like the reference rig) and bends the bottom of the spline-IK spine; spine_mid / spine_upper drive the rest.
- Spaces: head (Neck/Chest/World), FK legs (Hips/World), IK hands
  (World/COG/Chest/Shoulder/Hips/Head), FK arms (`FK_Space` on the hand switch:
  Shoulder/Chest/COG/World), arm pole vectors (`Follow`: Chest/Hand/World), leg pole vectors
  (Foot/World). Add more in `spaces` in `data/rig_rules.json`. (`rig/spaces.py` keeps a
  no-pop space switch for a future animator-tools tab - not in the window yet.)
- Fingers: `Fist`, `Spread` and `Thumb/Index/Middle/Ring/Pinky_Curl` on each hand's switch
  ctrl - the same values curl both hands the same way; the finger ctrls stay free on top.
- Chest volume helpers (pec, lat, chest) - Build Skeleton option (on by default), or
  **Add Chest Helpers** on an existing skinned skeleton. Strength: `root.Chest_Volume`.
- Guides rotate (whole limbs swing with Children follow on); "start in T-pose" option.

## Workflow
1. **Guides** - create (optionally in T-pose), fit to mesh, adjust.
2. **Skeleton + Skin** - build the skeleton, Skin Mesh (finished in one click). Paint touch-ups
   if you want, Mirror L -> R. All before any controls exist.
3. **Rig** - controls, IK/FK, spaces on top of the skinned skeleton. Remove Rig keeps the
   skin, so you can go back, repaint, and rebuild the rig.

## Build rules (what every position comes from)

The reference rig only supplies control *shapes*, colours and hierarchy. Every position
and axis is computed from your guides / skeleton with these rules:

1. **Joints sit exactly on the guides** - except a knee / elbow that is straighter than 1.5% of
   the limb: it is pre-bent (forward / back) so the IK solver always bends toward the pole.
2. **Leg & arm joints: Y down the bone, Z = world forward (+Z) made perpendicular to Y,
   X = Y x Z.** The right side is behaviour-mirrored from the left.
3. **Root, pelvis, head and feet are world-aligned**: rotate 0, the parent's rotation is
   cancelled in jointOrient (same as unparent - orient to world - reparent).
4. **Build Skeleton stores the rest pose** on `root`; Build Rig always resets to it first,
   so a posed or half-removed skeleton can't shift the rig.
5. **FK ctrls take the joint's frame; IK / world ctrls take world axes at the joint.**
   The head ctrl and its space group are world-upright.
6. **Every ctrl pivots on the joint it drives** (`thigh_l_ctrl` on the thigh...), wherever
   its shape floats. Overrides in `rig_rules.json` > `pivot_overrides` (`hip_ctrl` -> spine_02).
7. **Pole vectors:** knee/elbow + direction x (1.0 x leg length / 0.8 x arm length). Direction = world forward made
   perpendicular to the hip-ankle (shoulder-wrist) line, in front for legs, behind for arms;
   the real bend is used instead only when the limb is clearly bent that way.
8. **IK stretch:** factor = clamp(distance / (rest length x 1.0005 x World scale), 1, 100)
   (the 0.05% keeps a fully stretched limb dead straight), blended by
   `stretch`; the elbow/knee and the hand/foot IK joints translate by rest x factor.
9. **Spaces live on a group above the ctrl, never on the ctrl or joint.** Each space is a
   parentConstraint with its own offset per target (rotation-only spaces skip translate),
   so at rest every space gives the identical orientation and switching never moves the
   ctrl or rotates the joint.
10. **Constraints are made on an evaluated scene** (settle before hooks and spaces), with
   offsets kept, so building never pops the skeleton.
11. **Limb corrective joints - optional, off by default** (Skeleton > "Limb correctives"; `rig_rules.json` > `correctives`, all `*_l_hlp` / `*_r_hlp`): rings of
   joints INSIDE the flesh around each hinge - never on the bone. Traps (up), shoulder
   (up/front/back), wrist + ankle (front/back/out/in). Each is a child of the hinge joint (wrist ring under hand, ankle ring under foot...) and rides on a pivot that takes `follow` of the
   hinge rotation (slerp), so it orbits the bone at full radius under bend AND twist, and slides
   outward by remap(bend, 0 -> `angle`) x `slide` (never more than a third of the flesh thickness there). Bend = the larger of the swing and the
   twist angle vs rest (any axis, 0-180, can't flip). Placement uses a ray to the mesh
   surface x `depth`; weights are a soft patch taken only from the joints the ring sits between.
12. **Watertight:** after skinning and mirroring, vertices that touch (seams, separate pieces,
   across all meshes) are given identical weights.
13. **Test Poses** keys a real-human extreme range of motion (from the A-pose) and prints a report: squashed triangles
   per pose and how much volume each corrective keeps at its worst pose.
14. **Chest helpers (pec / lat / chest)** - pec / lat sit between a point on the ribcage and a
   point riding on the upper arm, so raising or swinging the arm pulls them; on top, each is
   pushed by how far the arm points up / forward / down (read in spine_05's space, eased 0 -> 1
   from the rest pose; `helpers[].push` in `rig_rules.json`, fractions of height), so the
   chest and armpit keep their volume. `root.Chest_Volume` (0-2) scales every push.
15. **Nothing you can see or edit elsewhere is connected or locked.** World_ctrl's toggles
   (Body_Ctrls, Finger_Ctrls, Skeleton_Vis, Rig_Systems_Vis) drive `lodVisibility` only;
   visibility, drawing overrides and Geometry_layer (starts as R) are yours in the Outliner,
   Attribute Editor and Layer Editor. Only animator channels a ctrl must not use (e.g. scale)
   are locked on the ctrls.
16. **Build Rig hides the Skeleton and Rig_Systems groups** (plain visibility - unhide them
   in the Outliner any time).
19. **World scale:** scale World_ctrl in the viewport; the rig uses (sx*sy*sz)^(1/3) so one
   axis alone still reads as one size. Skeleton and
   Rig_Systems follow World_ctrl (parent + scale), the spine curve doesn't inherit transforms
   (it's skinned), and every stretch divides by the world scale - so scaling the whole
   character changes nothing about how it moves.
20. **Muscle joints** (optional, Skeleton > "Muscle / volume joints"; `rig_rules.json` > `muscles`):
   traps, deltoid, back deltoid, quad, hamstrings, butt, TFL, achilles - each a line from an
   origin point (riding one bone) to an insertion point (riding the next), placed on the
   body by ray x depth. The joint sits between them, aims down the muscle, and scales across
   by 1/sqrt(length ratio) (blend = `.volume` on the joint): shorter = fatter, longer =
   thinner, same volume. Distances only - no flips, no snapping.
21. **IK twist check:** after the IK is built its chain is compared with the skeleton and the
   handle twist is rolled to match exactly (warns if a limb is set up backwards).
22. **Several objects:** the body (the piece spanning the character's height) is weighted with
   all the rules; pieces ON it (clothes, boots, hair) copy the body's weights by closest
   point; pieces that aren't (a separate head, a helmet) are weighted on their own.
23. **Test poses move the clavicle with the arm** (about 1 degree per 4 of the arm).
24. **Fingers and thumb:** Y down the finger, X (the bend axis) from the hand's X (palm
   normal) - the same convention as the reference rig, so the thumb rolls the same way on
   every mesh. Build Skeleton re-applies the orientation rules to existing guides first.
26. **Thumb roll is solved automatically:** its curl heads for the base of the little finger (D),
   X = -/+D with the same sign convention as the fingers, so with all fingers + thumb
   selected, rotate Z makes a fist. The yellow guide beside the thumb only shows the result.
27. **Knee (with "Muscle / volume joints" on):** a kneecap joint rides the knee's half-rotation
   pivot and pushes forward up to 15% of the knee's thickness between 90 and 150 degrees of
   bend; and the calf twist joints slide down the shin as the knee bends past 90 degrees
   (top one ~8% of the shin, lower ones less) - the calf itself carries no skin then, so the
   skin under the kneecap stretches instead of pinching. `root.Knee_Slide` 0-2 scales it;
   start / angle / slide live in `rig_rules.json` > `knee_slide` and the `kneecap_l` corrective.
28. **Fix Mesh** (Skin step): pose the character -> **Fix Pose** (a blue sculptable copy appears,
   the real mesh hides) -> sculpt / move vertices -> **Apply Fix**. Each moved vertex gets new
   weights (>= 0, sum 1, max 4, over its own + its neighbours' joints) that best reproduce the
   sculpt in this pose AND every pose fixed before, staying close to the old weights. Weights
   only - exports exactly as it looks. The console says how much of the fix the skin could
   match; the rest is corrective-joint work. Select a mesh first to fix that piece.
29. **Smooth Pose** (Skin step, the everyday fix): run Test Poses, stop on a frame that looks off,
   press **Smooth Pose**. Selected vertices / edges / faces are relaxed (Taubin smoothing - evens
   out without shrinking); with nothing selected it finds the squashed (<40%) or over-stretched
   (>250%) triangles itself, plus 2 rings around them. The relaxed shape is solved into the
   weights exactly like Fix Mesh (all fixed poses kept in balance). Repeat on other bad frames,
   then Clear the test poses -> correctives -> Fix Pose for what's left -> Build Rig.

31. **Spine:** spine_05 (the end of the spline) takes `spine_upper_ctrl`'s rotation 1:1 - the
   spline solver never rotates its end joint, so the chest, clavicles and neck lagged behind
   the ctrl. The curve's first two CVs ride the lower ctrl, the last two the upper ctrl (the end
   tangent turns exactly with it); `spine_mid_ctrl` pivots on spine_03, where its curve joint is.
32. **Twist joints** are drawn 1.6x the limb joints' size, light blue. Their forearm / shin
   twist is read round the forearm / shin axis (the axis they turn on). The twist joint next
   to the wrist / ankle turns fully with the hand / foot and the turn fades toward the elbow /
   knee (2 joints: 50%, 100%), so the wrist blend has no twist left over to pinch (no candy wrap).
35. **Knees follow the feet:** a leg's bend plane is the hip->ankle line + the foot's forward
   direction (ankle -> ball). Build Skeleton moves the knee guide sideways onto that plane
   (printed), and the pole vector is placed along the knee's own bend offset (positions only, same on both sides) - so knee, foot
   and pole always agree and a crouch folds the knees over the toes, never inward. Finger
   ctrls are no longer drawn on top of the mesh.
42. **No more "zero-length output vector" errors:** directional correctives (wrist, ankle,
   hip, waist, back...) read which way the joint bends with a plain dot product - at rest
   the bend is a zero vector, and the old normalizing node errored on every evaluation.
50. **Correctives come after the skin:** Build Skeleton no longer makes the chest helpers;
   every corrective - Chest included - is added in the Correctives tab, one at a time
   (works with the rig built, in rest pose). **Show Weights** (and every Add) opens Paint
   Skin Weights on the corrective's joint, so its area shows white.
51. **Hip corrective = front + back** (older side joints are removed when you Add / Remove).
52. **Chest helpers:** patches wider (8% of height, scaled to the body) and stronger (70% at
   the centre) - they take the armpit / lower back from the upper arm twist joints - and
   they sit closer to the skin (85%). The lat follows the arm only 15% (was 40%: the arm
   dragged the back in), reaches up with the arm raised and holds the back out when it drops.
53. **Finger corrective shapes:** every finger joint gets an automatic corrective shape
   (curl 30 / 60 / 95 deg, round the rig's own curl axis), so the knuckles keep their volume.
47. **Seam reach narrowed (SEAM_REACH 0.3 x limb radius):** at 0.5 the pelvis held the top
   of the inner thighs (80 leg vertices, up to 33%); now 13 vertices right at the crotch
   (at most 11%), and the hips still tear less than before the seam rule (10 strays, worst
   2.8 vs 29 / 3.0).
48. **Correctives follow the bend, never the twist:** each ring's pivot aims part of the way
   from where the bone pointed at rest to where it points now, its up axis held by the
   parent - a thigh rolling under a pelvis tipped far forward no longer rolls the hip ring.
49. **Defaults retuned:** the crease side pushes a little again (inner elbow, knee pit:
   0.15 - with the smoothed weights it adds volume, no new strays); the trap pushes less
   (0.06, along -0.08) and the chest helpers' arm-up push is halved (they bulged when the
   arms went up). Reset a corrective / Chest corrective to pick the new defaults up.
43. **Crotch / pelvis seam:** sibling branches (left and right leg off the pelvis, fingers
   off the hand, neck and clavicles off the chest) never share weight, so the crotch was a
   hard 100% left / 100% right seam that tore when one leg lifted. The flesh near a seam
   between siblings now fades back to their parent (pelvis, hand, chest). Full body test,
   after the extreme-pose repair: strays over all test poses 85 -> 51, at the hips 29 -> 5
   (worst 3.0 -> 1.6).
44. **Corrective weights, one method for all:** the ring joints take the MIDDLE of the
   parent / child blend (the band linear skinning collapses), shared by direction, then
   relaxed with their neighbours. Elbow 120 deg: volume 73% -> 83% (worst 51% -> 76%), knee
   71% -> 85% (50% -> 78%), shoulder raise 77% -> 82% (58% -> 71%), no new strays - the old
   round patch only reached 77% / 75%. Only the OUTER joint pushes (elbow point, kneecap);
   the crease-side joints no longer push into the bend (Reset updates older joints).
45. **Safe bind for clothes / shoes:** heat map and polyReduce only run on clean (manifold)
   meshes - on non-manifold geometry they can crash Maya. Other pieces bind to the closest
   joints and the solve builds their blends; the GPU voxel bind is no longer an automatic
   fallback.
46. **Auto_Clavicle defaults to 0:** moving the arm doesn't move the clavicle (set it on the
   clavicle ctrl to bring the lift back).
41. **Corrective editor = Move only:** each joint shows Move X / Y / Z on a -10..10 slider
   (1 step = 20% of the flesh thickness at that joint, so 10 = twice the thickness; type
   bigger numbers in the box). Angles and skin patch keep their defaults (still in
   rig_rules.json / on the joints). **Lighter drivers:** joints round the same hinge share
   one bend reader and one swing reader, and each joint's move is one vector x matrix node -
   about half the utility nodes per corrective joint. **Finalize** (Rig step) is now a button.
40. **Heel ctrl banks the foot:** tilting `foot_*_heel_ctrl` sideways (rotate Z) rolls the
   foot on its outer / inner edge (the bank pivots) instead of spinning on the heel point.
   One way rolls onto the inner edge, the other onto the outer. The bank ctrls and the
   bankIn / bankOut attrs on the leg IK ctrl still work on top.
39. **Chest scale for breathing:** the chest ctrls' scale is unlocked (FK `spine_05_ctrl`, IK
   `spine_upper_ctrl` - whichever the spine switch uses) and drives spine_05's scale, so the
   ribcage expands. Its child joints compensate the scale (segment scale compensate): neck,
   head, clavicles and arms ride outward with the chest without growing. Remove Rig puts the
   scale back to 1. Use it with or instead of the Breath shape.
38. **Facing check:** the character must face +Z (Maya's front view, its left on +X - the
   Maya / UE5 convention). Create Guides warns, and Build Skeleton stops, if it faces -Z
   (feet pointing -Z): built that way every _l / _r ctrl and joint would be on the wrong side.
   Rotate the character 180 in Y, freeze transforms, and Create Guides again.
37. **Hip corrective** (Correctives tab): front / back / outer / inner joints round the hip
   (like UE5 Manny's thigh_fwd / bck / out / in). They turn HALF as far as the thigh and take
   the middle of the pelvis / thigh blend - where linear skinning collapses most (on the Saint
   mesh, 120 degrees of hip flex: the worst blend vertex keeps 75% of its distance from the
   hip instead of 50%, the average 87% instead of 72%). Each also moves out (Move X/Y/Z) when
   the leg bends toward it. Skin size / strength set how much of the blend they take.
   Knee corrective front defaults now come out less and slide further along the thigh (more
   stretch). **Reset** puts a corrective back to the defaults.
36. **Back corrective** (Correctives tab, one option, both sides) - replaces the neck
   crease joint (older neck joints are swapped out when you Add it):
   - **Trap**: one joint over the clavicle toward the shoulder. When the arm raises (read
     from the chest to the upper arm, so the auto-clavicle counts) it rides 70% of the
     clavicle and moves UP and IN toward the neck (defaults: Move X up, Move Y along the
     clavicle negative = in).
   - **Deltoid**: top and back of the shoulder; turn half as far as the upper arm (holds the
     shoulder's volume) and bunch up / in as the arm raises (top) or swings back (back).
   Every option's sliders name what each axis points at on that joint (out / up / forward).
33. **Waist ring** (Correctives tab, "Waist ring (spine_02)"): front / back / left / right
   joints round spine_02. The bend is read from the pelvis to spine_03 (a waist bend is spread
   over several spine joints, and tipping the hips counts too), and each joint only pushes
   when the torso bends TOWARD it - the belly on a forward bend, the side being squeezed on a
   side bend. Twisting the torso leaves them alone. Defaults: Start 5, Full 45 degrees, Push
   = 12% of the waist's thickness - tune live on the joints. Centre correctives (`"centre":
   true`) are built once; `"measure": [a, b]` reads the bend over a longer stretch.
34. **Drivers are versioned:** Build Rig rebuilds skeleton drivers made by an older version of
   the tool (twist, chest helpers) - the skin is never touched.

40. **Rotation-only spaces pivot on their joint** (`spaces[].pivot`): the FK arm space group sat at
   the world origin, so Chest / COG / World swung the arm round the feet.

41. **Adaptive skin (any mesh, nothing stored):** Skin Mesh = one bind (heat map; voxel where
   the mesh isn't closed) + one vectorised solve (`rig/weightmath.py`, numpy, ~0.5 s for 25k
   vertices). Everything is measured on this mesh and skeleton - no body-part rules, no
   reference skin:
   - ownership: a vertex belongs to its nearest bone; other bones keep weight only within 2
     hierarchy steps and about as close (2 steps: only where nearly as close), on its side
   - flesh radius of every bone, measured from the vertices it owns
   - every joint (elbow, knee, knuckle, hip, neck...) blends its two bones across the joint's
     bisecting plane over a width = the flesh radius there (max 45% of the shorter bone); a
     child much thicker than its parent's tube (a head on a neck) takes what sticks out of
     the tube (jaw, skull)
   - blend vertices smoothed with their neighbours, limits re-applied
   - twist joints share their bone's weight by position along it
   - max 4 influences, pruned, normalised; correctives / helpers get their patches after
   Upper arm / thigh go into the bind (heat map works per bone segment) but only give weight.

42. **Corrective shapes, made per character** (Skin step option, on by default;
   `rig/autoshapes.py` + `rig/shapemath.py`): knees and elbows (bend), hips (leg forward) and
   shoulders (arm up), both sides. Each joint is bent to two sample angles; at each, the
   correct shape is worked out from the mesh - flesh that passed through the crease is
   pressed onto the joint's bisecting plane (the two sides flatten against each other), and
   the outside of the joint is pushed back to its rest distance from the bend axis (square
   corners, no rounding off) - sized by the joint's own measured flesh radius, smoothed,
   converted to rest space and stored as a blend shape (in-between + full) in front of the
   skin. The joint's bend in its bend plane dials it in (0 when bent the other way), so it
   works with or without the rig and exports as an ordinary morph target. Re-made after
   Mirror L>R; removed by Unbind. Measured on Saint: knee at 140 degrees went from flesh 6.05
   units through the thigh and 46% outer volume to 0 and 100%.
43. **Any body size:** chest helpers are placed by a ray from the ribcage to the skin (70% of
   the way), and their push and skin patch scale with what that ray measures; the head's
   reach is a ray to the top of the skull. Nothing assumes the template's proportions.

44. **Speed (same result):**
   - only the bones go into Maya's heat map / voxel bind; twist and helper joints are added
     afterwards with no weight (the solve gives twist joints their share, helpers get patches)
   - a body over 12k vertices is bound on a reduced copy (8k) and the weights copied by
     closest point - the bind only decides roughly which bone owns what; the solve rebuilds
     every blend on the full-resolution mesh (falls back to a full bind if reducing fails)
   - influence limit, helper patches and the watertight weld are vectorised (numpy)
   - corrective shapes: each sample pose is set once for all meshes, only the vertices that
     move are converted, and targets are written sparse, straight into the blend shape
     (no duplicate meshes)

45. **Breathing** (with the corrective shapes): `Breath` and `Belly_Breath` on `root` and, once
   the rig is built, on the chest ctrls (`spine_upper_ctrl`, `spine_05_ctrl`) - -0.5 (exhale)
   to 1 (inhale). Two blend shapes made from the mesh in rest space: the ribcage (the top
   spine joints + chest helpers by their skin weight) scales out from its own axis by 6% of
   each vertex's distance, the sternum more, and lifts by 5% of the chest's measured radius;
   the belly pushes forward. Any body size; exports as morph targets.

46. **Clean Channel Box:** every node the tool creates behind the scenes (constraints, maths /
   utility nodes, twist / corrective / breathing drivers, IK handles, ctrl curve shapes) has
   isHistoricallyInteresting off, so selecting a ctrl shows only its own channels - no
   INPUTS / OUTPUTS list. Skin clusters and blend shapes stay listed on the mesh.

47. **Hubs and siblings:** at a hub joint (pelvis: spine + both legs; chest: neck + clavicles)
   the blend plane sits square to the branching bone (a level hip line - the leg no longer
   pulls the waist), and sibling branches of one hub never share weight (spine vs leg,
   finger vs finger).
48. **Corrective-shape crease = the bend's wedge** (from the parent's side round to the child,
   +25 degrees), not a half-space: overhead, the stretched armpit / lat gets its volume back
   (Saint, arm raised 140 degrees: lat volume 82% -> 100%, worst vertex 34% -> 86%). The
   shoulder sample now reaches 140 degrees; the other side of every bend is the whole torso
   side (lats are mostly mid-spine weight).
49. **Neck follow:** `head_ctrl.Neck_Follow` (0-1, default 0.4) - the neck joint takes that share
   of the head ctrl's rotation while the head still points exactly where the ctrl does, so
   turning the head bends the whole neck. The head's Neck space follows the neck ctrl.

50. **Ownership by surface distance** (A-pose fix): each vertex belongs to the bone it reaches
   first walking over the mesh from that bone's core (vertices the bind and the geometry
   agree on), and a bone may only share vertices within about a joint radius of its own
   area along the surface. The upper arm hanging next to the ribs no longer owns the
   serratus (Saint, arm raised 100 degrees: rib side moved 2.47 -> 0.26 units on average).
   Lone vertices that disagree with all their neighbours are averaged (no spikes).
51. **Guides look like joints**: no locator crosses - a ball in the side colour, a green arrow
   down the bone (Y) and a blue tick forward (Z), all in the joint's axes. Selecting one
   guide lines the Move tool up with its joint axes (drag along / across the bone - easy on
   fingers); the Move tool's own mode comes back when you select anything else.
52. **Geometry group**: Build Rig moves the meshes into Biped_Rig|Geometry (same place in
   space); Remove Rig puts them back under their old parents.
53. **Thumb in a fist** folds slower than the fingers (`curl_scales` 0.35 / 0.6); finger ctrls
   are hidden inside the mesh (not drawn on top).
54. **Correctives tab**: Chest, Elbow, Wrist, Hip, Knee (back + front in one), Ankle, Waist and Back
   correctives; Add / Select Joints / Re-weight / Mirror Settings / Remove. Pick one and its
   joints show in the tab with sliders (applied live, both sides at once with "Edit both
   sides"): **Move X / Y / Z** at full bend (X out from the body - the character's left on the
   waist, Y along the bone toward the joint, Z forward; the same numbers mirror to the right),
   **Start / Full angle**, **Skin size / strength** (applied on Re-weight). Chest correctives
   (pec / lat / chest): Move X / Y / Z (out / up / forward) for arm up, forward and down.
   Defaults come from the flesh thickness measured there; the settings live on the joints
   (hidden from the Channel Box). Works with the rig built (rest pose).
55. **Extreme-pose repair (automatic, inside Skin Mesh):** after the solve, the skin is posed in
   memory in 20 test poses (arms up / forward / back, elbows, hips forward / out, knees, spine,
   neck - nothing in the scene moves). Vertices that break out of line with their neighbours
   (strays, torn seams) are found and their patch is rebuilt from the ring around it, every
   bone kept inside its own area except right at a seam between two bones (the armpit), up to
   3 passes. Saint: 243 strays (worst 17.4) -> 58 (worst 2.9), every earlier check intact.
   **Smooth Weights** (Skin step) does the same rebuild on vertices you select.
56. **Bent base poses**: a clearly bent knee / elbow in the model sets the hinge (joint X) and
   the pole vector from its own bend plane, so the IK folds the way the limb already does.

57. **Build Rig always finishes:** optional steps (Geometry group, neck follow, finger / breathing
   attrs, spaces, Channel Box clean-up) warn with a full trace if they fail and the core rig
   (ctrls, IK/FK, switches, display toggles) still completes.

58. **Auto clavicle:** raising the arm (FK or IK) lifts the clavicle up to 30 degrees when the arm
   points straight up (`clavicle ctrl .Auto_Clavicle` 0-1, default 1). Read from the FK ctrl's
   own rotate channels / the IK hand's position in the chest's space - never through the
   clavicle, so no loop; the IK hand's Shoulder space was dropped for the same reason. The pec
   helper now follows mostly the ribcage and lifts (up push) instead of swinging with the arm.
59. **Correctives:** older joints' Push / Push_Along convert to Move X / Y / Z on the next Build
   Rig. Older two-part knees (pit + kneecap) are replaced when you Add the Knee corrective.
   The knee front defaults push less out and slide along the thigh (a broad, flat knee front, not a
   point). Wrist / ankle rings are directional: a joint only pushes when the joint bends
   toward its side (they pushed on every bend, so the far side bulged the wrong way).

60. **Legs / pelvis back to the plain method:** the pelvis is skinned again (it IS the hips joint;
   folding it into spine_01 cost groin volume: 93% -> 87% in a lunge), no butt lift, and the
   extreme-pose repair no longer tests the knee bend - it was "fixing" the normal knee crease by
   smearing the knee blend over a third of the thigh, which is the knee-back volume loss. Hips in
   a lunge: 71% -> 77% volume (low end 79% -> 88% on the back leg). Every number in the leg skin
   is a fraction of the limb's own thickness, so it follows the character's proportions.
61. (removed - see 60)
62. **Ankle back:** the Back joint pushes out 0.3 AND slides up the calf 0.4 (Move Y) when the foot
   points, so the heel rising into the Achilles makes a smooth ramp, not a collapsed shelf.
63. **Window:** switching tabs or bringing the window back to the front re-lays it out at its
   current size (Qt left the Build column squashed until a manual resize).

64. **Legs + pelvis play back as dual quaternion (Maya's "weight blended" skinning):** no
   tuning, any proportions. Each vertex mixes linear / DQ by how much it belongs to pelvis,
   spine_01 and the legs (rule dq_skin), so arms and upper body stay linear. Measured on a full
   body: hip flexed 110 deg, median thickness 79% -> 100%; knee 130 deg, 78% -> 100%. Clothes
   get it too. The automatic knee / hip shapes are no longer made (the hip shape added stray
   vertices, and on top of DQ they'd double up); the Hip / Knee / Ankle / Waist correctives
   aren't needed. Engines skin linearly: in UE5 the legs play back without the DQ volume.

65. **Faster Skin Mesh:** the corrective shapes pose the skin in numpy (only the bent joints'
   matrices are read) instead of redrawing the viewport and reading every mesh per sample;
   corrective weights work on one numpy array (no per-corrective list copies) and smooth only
   their own area; muscle weights are vectorised. The Script Editor prints the time each step
   took ("Skin Mesh times: ...", "Corrective shapes took ...").

## Upgrading a rig built with an older version
Remove Rig -> Unbind -> Skin Mesh -> Build Rig (Add Chest Helpers first if the skeleton was
built without them). A skeleton with 3 forearm / calf twist joints needs Delete Skeleton ->
Build Skeleton first.

## Current state (latest)
- Skin Mesh: one bind + one adaptive solve (rule 41) - finished in one click, no extra passes,
  no stored reference data. Linear, 4 influences, normalised = Unreal-ready.
- Skin step buttons: Skin Mesh, Mirror L>R, Add Chest Helpers, Unbind.
- Workflow: Build Skeleton -> Skin Mesh -> Build Rig. Skin Mesh needs numpy (ships with Maya).
- Joints are drawn bigger (body / 45; helpers and correctives / 40; twist joints 1.6x).
