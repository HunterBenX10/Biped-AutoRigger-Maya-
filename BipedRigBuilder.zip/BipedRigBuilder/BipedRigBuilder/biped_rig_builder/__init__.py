"""Biped Rig Builder - guides -> game-ready skeleton -> preview rig, for Maya.

    biped_rig_builder/
        config.py        names, colours, file paths - every magic string lives here
        data/            everything captured from the reference rig (JSON, no code)
        core/            small Maya helpers shared by everything (names, maths, nodes, meshes)
        rig/             one class per stage: Guides, Skeleton, Controls, Skinner, PreviewRig
        ui/              the window (only calls the rig classes, holds no logic)

Run from Maya with launch.py, or:  import biped_rig_builder; biped_rig_builder.show()
"""
__version__ = "2.0.0"


def show():
    from .ui.window import BuilderWindow
    return BuilderWindow().show()
