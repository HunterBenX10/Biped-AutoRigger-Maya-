"""The window. Four steps, top to bottom; each step has one main button, a row of small
tools and folded-away options. A status line always says what to do next, and buttons
that can't be used yet are greyed out. Hover any button for a short explanation.
Holds no rig logic - every button calls one method on a rig class."""
import traceback

import maya.cmds as cmds

from .. import config
from ..core.mesh import MeshSet
from ..rig import corrective_tool, fixmesh
from ..rig.deform import Deformation
from ..rig.guides import Guides
from ..rig.preview import PreviewRig
from ..rig.skeleton import Skeleton

# light Maya greys; colour only on the buttons
MAIN = (0.18, 0.45, 0.80)          # the one main button per step (blue)
TOOL = (0.44, 0.44, 0.44)          # small tool buttons
DANGER = (0.78, 0.26, 0.26)        # delete / remove (red)
HEADER = (0.38, 0.38, 0.38)        # step title bars
BANNER = (0.42, 0.42, 0.42)        # window title
STATUS = (0.33, 0.33, 0.33)        # "Next:" line


class BuilderWindow(object):
    def __init__(self):
        self.guides = Guides()
        self.ui = {}
        self.needs = {}            # control -> stage required to use it

    # ---------------------------------------------------------------- state
    @staticmethod
    def stage():
        """0 nothing, 1 guides, 2 skeleton, 3 skinned, 4 rig, 5 finalized."""
        if PreviewRig.exists():
            from ..core import nodes
            return 5 if nodes.get_string(PreviewRig.top, "finalized") else 4
        if Skeleton.exists():
            return 3 if Deformation.skins() else 2
        return 1 if Guides.exist() else 0

    NEXT = ["Select your character, then  Create Guides.",
            "Move the guides into place (Fit to Mesh helps), then  Build Skeleton.",
            "Skeleton built.  Skin Mesh  next.",
            "Skinned.  Build Rig  next.",
            "Rig built (skeleton hidden - unhide it in the Outliner). Remove Rig to go back.",
            "Finalized - clean history, optimised skin. Remove Rig still goes back."]

    def refresh(self):
        st = self.stage()
        try:
            self.fill_correctives()
        except Exception:
            pass
        if cmds.text(self.ui.get("status", ""), exists=True):
            cmds.text(self.ui["status"], edit=True, label="Next:  " + self.NEXT[st])
        for ctrl, (low, high) in self.needs.items():
            if cmds.control(ctrl, exists=True):
                cmds.control(ctrl, edit=True, enable=low <= st <= high)

    def run(self, fn):
        def call(*_):
            try:
                fn()
            except Exception as e:                       # report, keep the window alive
                traceback.print_exc()
                cmds.warning("{}: {}".format(config.TITLE, e))
            self.refresh()
        return call

    def value(self, key, default=True):
        w = self.ui.get(key)
        if w and cmds.optionMenu(w, exists=True):
            return cmds.optionMenu(w, q=True, value=True)
        if w and cmds.checkBox(w, exists=True):
            return cmds.checkBox(w, q=True, value=True)
        return default

    # ---------------------------------------------------------------- actions
    def create_guides(self):
        self.guides.create(MeshSet.from_selection(), follow=self.value("follow"),
                           tpose=self.value("tpose", False))

    def toggle_xray(self):
        meshes = Guides.meshes() or MeshSet.from_selection()
        if meshes:
            meshes.see_through(not meshes.is_see_through())

    @staticmethod
    def redirect_selection():
        """Clicking a guide's rings selects the guide (kept out of the undo queue)."""
        sel = cmds.ls(selection=True) or []
        new = [(cmds.listRelatives(s, parent=True) or [s])[0]
               if s.endswith(config.ORIENT_SUFFIX) else s for s in sel]
        if new != sel:
            cmds.undoInfo(stateWithoutFlush=False)
            try:
                cmds.select(list(dict.fromkeys(new)), replace=True)
            finally:
                cmds.undoInfo(stateWithoutFlush=True)
        try:                                   # Move tool follows the guide's joint axes
            Guides.align_move_tool(list(dict.fromkeys(new)))
        except Exception:
            pass

    # ---------------------------------------------------------------- widgets
    def main(self, label, fn, tip, stages):
        b = cmds.button(label=label, height=34, backgroundColor=MAIN, annotation=tip,
                        command=self.run(fn))
        self.needs[b] = stages

    def tools(self, *items):
        """A row of small buttons sharing the width (resizes with the window)."""
        form = cmds.formLayout(height=26)
        made = []
        for i, (label, fn, tip, stages, *danger) in enumerate(items):
            kw = {"backgroundColor": DANGER if danger else TOOL}
            b = cmds.button(label=label, height=24, annotation=tip, command=self.run(fn), **kw)
            self.needs[b] = stages
            made.append(b)
        n = len(made)
        cmds.formLayout(form, edit=True, attachPosition=sum(
            ([(b, "left", 2, 100 * i // n), (b, "right", 2, 100 * (i + 1) // n)]
             for i, b in enumerate(made)), []),
            attachForm=sum(([(b, "top", 0), (b, "bottom", 0)] for b in made), []))
        cmds.setParent("..")

    WIDTH = 440                    # also the minimum: tool buttons never squash together

    @staticmethod
    def _qt():
        """(wrapInstance, QWidget, QApplication) for Maya's Qt binding, or None."""
        try:
            try:
                from shiboken6 import wrapInstance
                from PySide6.QtWidgets import QApplication, QWidget
            except ImportError:
                from shiboken2 import wrapInstance
                from PySide2.QtWidgets import QApplication, QWidget
            return wrapInstance, QWidget, QApplication
        except Exception:
            return None

    def min_width(self, px):
        """Maya's window command has no minimum size - set it on the Qt window."""
        qt = self._qt()
        if not qt:
            return
        import maya.OpenMayaUI as omui
        ptr = omui.MQtUtil.findWindow(config.WINDOW)
        if ptr:
            qt[0](int(ptr), qt[1]).setMinimumWidth(px)

    def fit(self, *_):
        """Size the window to its content, so every button and line shows without
        scrolling: the column's real size (Qt size hint) + the window frame, capped at
        90% of the screen (taller than that, the scroll bar takes over). Never narrower
        than WIDTH. Runs on open and whenever a step is folded / unfolded."""
        if not cmds.window(config.WINDOW, exists=True):
            return
        w, h = self.WIDTH, 760                          # no Qt: a size that fits the steps
        qt = self._qt()
        col = self.ui.get("column")
        if qt and col:
            try:
                import maya.OpenMayaUI as omui
                ptr = omui.MQtUtil.findLayout(col)
                if ptr:
                    widget = qt[0](int(ptr), qt[1])
                    widget.adjustSize()
                    hint = widget.sizeHint()
                    w = max(self.WIDTH, hint.width() + 30)
                    h = hint.height() + 64              # tab bar + frame + scroll margins
                    screen = qt[2].primaryScreen()
                    if screen:
                        h = min(h, int(screen.availableGeometry().height() * 0.9))
            except Exception:
                pass
        cmds.window(config.WINDOW, edit=True, width=w, height=h)

    def nudge(self, *_):
        """Re-lay the window out at its CURRENT size (the user's size is kept): Qt can leave
        a tab's column squashed after the window loses focus or the tab changes, until the
        window is resized - so resize it by one pixel and back."""
        if not cmds.window(config.WINDOW, exists=True):
            return
        w = cmds.window(config.WINDOW, query=True, width=True)
        cmds.window(config.WINDOW, edit=True, width=w + 1)

        def back():
            if cmds.window(config.WINDOW, exists=True):
                cmds.window(config.WINDOW, edit=True, width=w)
        cmds.evalDeferred(back)

    def _watch_focus(self):
        """Nudge the layout whenever the window comes back to the front."""
        qt = self._qt()
        if not qt:
            return
        try:
            try:
                from PySide6.QtCore import QEvent, QObject
            except ImportError:
                from PySide2.QtCore import QEvent, QObject
            import maya.OpenMayaUI as omui
            ptr = omui.MQtUtil.findWindow(config.WINDOW)
            if not ptr:
                return
            win = qt[0](int(ptr), qt[1])
            nudge = self.nudge

            class _Focus(QObject):
                def eventFilter(self, obj, ev):
                    if ev.type() == QEvent.WindowActivate:
                        cmds.evalDeferred(nudge)
                    return False

            self._focus = _Focus(win)
            win.installEventFilter(self._focus)
        except Exception:
            pass

    def relayout(self, *_):
        """Opening / closing a fold: re-fit once Maya has laid the fold out."""
        cmds.evalDeferred(self.fit)

    def options(self):
        """Options are always visible (no fold): a thin divider, then the settings."""
        cmds.separator(style="in", height=8)
        cmds.columnLayout(adjustableColumn=True, rowSpacing=3, columnOffset=("left", 4))

    def end_options(self):
        cmds.separator(style="none", height=4)        # breathing room under the last row
        cmds.setParent("..")

    def check(self, key, label, tip, value=True, **kw):
        self.ui[key] = cmds.checkBox(label=label, value=value, annotation=tip, **kw)

    # ---------------------------------------------------------------- correctives tab
    def _correctives_tab(self):
        col = cmds.columnLayout(adjustableColumn=True, rowSpacing=6, columnOffset=("both", 6))
        cmds.text(label="  Correctives", align="left", height=30, font="boldLabelFont",
                  backgroundColor=BANNER)
        for line in ("Joints that move as a joint bends, so it keeps its shape.",
                     "Pick one, Add, then edit it below - it updates live.",
                     "Works with the rig built too (in its rest pose)."):
            cmds.text(label=line, align="left", height=16, font="smallPlainLabelFont")
        self.ui["cor_list"] = cmds.textScrollList(allowMultiSelection=True, numberOfRows=8,
                                                  height=150,
                                                  selectCommand=self.show_editor)
        cor = corrective_tool

        def act(fn):
            def go():
                chosen = self.chosen_correctives()
                if not chosen:
                    cmds.warning("Pick a corrective in the list first.")
                    return
                fn(chosen)
                self.fill_correctives()
            return go
        self.tools(("Add", act(cor.add), "Create the picked correctives (limbs: both sides), "
                    "drive them, weight them on the skin and show where they act", (3, 5)),
                   ("Show Weights", act(cor.show_weights), "Paint Skin Weights on the "
                    "picked corrective's joint: its area shows white", (3, 5)),
                   ("Select Joints", act(cor.select), "Select their joints in the scene",
                    (3, 5)),
                   ("Re-weight", act(cor.reweight), "Fresh skin patch for the picked ones "
                    "(after a re-skin, or to undo hand-painting on them)", (3, 5)))
        self.tools(("Mirror Settings L>R", act(cor.mirror_settings),
                    "Copy every setting from the left joints to the right", (3, 5)),
                   ("Reset", act(cor.reset), "Back to the default settings (move, angles, "
                    "skin) for the picked ones", (3, 5)),
                   ("Remove", act(cor.remove), "Delete the picked correctives (their skin "
                    "goes back to the joints round them)", (3, 5), True))
        cmds.setParent(col)
        cmds.separator(style="in", height=10)
        self.ui["cor_both"] = cmds.checkBox(label="Edit both sides", value=True,
                                            annotation="Every change goes to the left and "
                                            "the right joint together")
        self.ui["cor_edit"] = cmds.columnLayout(adjustableColumn=True, rowSpacing=4)
        cmds.setParent(col)
        cmds.setParent("..")
        self.fill_correctives()

    def show_editor(self, *_):
        """Sliders for the picked corrective's joints (left / centre side; 'Edit both
        sides' copies every change to the right). Move = how far at full bend / pose."""
        box = self.ui.get("cor_edit")
        if not box or not cmds.layout(box, exists=True):
            return
        full = cmds.layout(box, q=True, fullPathName=True)
        for kid in cmds.layout(box, q=True, childArray=True) or []:
            cmds.deleteUI(full + "|" + kid)
        cmds.setParent(box)
        chosen = self.chosen_correctives()
        if len(chosen) != 1:
            cmds.text(label="Pick one corrective to edit it." if chosen else "",
                      align="left", height=18)
            return
        items = corrective_tool.edit_items(chosen[0])
        if not items:
            cmds.text(label="Not added yet - press Add.", align="left", height=18)
            return
        cmds.text(label="  How far each joint moves at full bend (10 = twice the flesh "
                  "thickness there; type more in the box).", align="left", height=16,
                  font="smallPlainLabelFont")
        for n, (j, title, attrs) in enumerate(items):
            cmds.setParent(box)
            cmds.frameLayout(label="{}   ({})".format(title, j), collapsable=True,
                             collapse=n > 2, marginWidth=6, marginHeight=4,
                             backgroundColor=HEADER,
                             expandCommand=self.relayout, collapseCommand=self.relayout)
            cmds.columnLayout(adjustableColumn=True, rowSpacing=2)
            unit = corrective_tool.move_unit(j)
            for attr, label, kind in attrs:
                value = corrective_tool.get_value(j, attr) / unit
                ctl = cmds.floatSliderGrp(label=label, field=True, value=value,
                                          minValue=-10.0, maxValue=10.0, fieldMinValue=-1000,
                                          fieldMaxValue=1000, step=0.1, precision=2,
                                          columnWidth3=(130, 64, 100), adjustableColumn=3)
                cmd = self._editor_cmd(j, attr, ctl, unit)
                cmds.floatSliderGrp(ctl, edit=True, dragCommand=cmd, changeCommand=cmd)
        self.relayout()

    def _editor_cmd(self, j, attr, ctl, unit=1.0):
        def go(*_):
            v = cmds.floatSliderGrp(ctl, q=True, value=True) * unit
            corrective_tool.set_value(j, attr, v, cmds.checkBox(self.ui["cor_both"], q=True,
                                                                 value=True))
        return go

    def fill_correctives(self):
        lst = self.ui.get("cor_list")
        if not lst or not cmds.textScrollList(lst, exists=True):
            return
        keep = self.chosen_correctives() if getattr(self, "_cor_names", None) else []
        self._cor_names = []
        cmds.textScrollList(lst, edit=True, removeAll=True)
        for name, label, added in corrective_tool.presets():
            self._cor_names.append(name)
            cmds.textScrollList(lst, edit=True,
                                append="{}{}".format(label, "      [added]" if added else ""))
        for name in keep:
            if name in self._cor_names:
                cmds.textScrollList(lst, edit=True,
                                    selectIndexedItem=self._cor_names.index(name) + 1)
        self.show_editor()

    def chosen_correctives(self):
        lst = self.ui.get("cor_list")
        idx = cmds.textScrollList(lst, q=True, selectIndexedItem=True) or []
        return [self._cor_names[i - 1] for i in idx if 0 < i <= len(self._cor_names)]

    # ---------------------------------------------------------------- layout
    def show(self):
        for w in (config.WINDOW, "baseSkeletonWin"):
            if cmds.window(w, exists=True):
                cmds.deleteUI(w)
            if cmds.windowPref(w, exists=True):
                cmds.windowPref(w, remove=True)        # never reuse an old, too-small size
        cmds.window(config.WINDOW, title=config.TITLE, width=self.WIDTH, sizeable=True)
        tabs = cmds.tabLayout(innerMarginWidth=2, innerMarginHeight=2)
        build_tab = cmds.scrollLayout(childResizable=True, horizontalScrollBarThickness=0)
        col = cmds.columnLayout(adjustableColumn=True, rowSpacing=6, columnOffset=("both", 6))
        self.ui["column"] = col
        cmds.text(label="  " + config.TITLE, align="left", height=30, font="boldLabelFont",
                  backgroundColor=BANNER)
        self.ui["status"] = cmds.text(label="", align="left", wordWrap=True, height=52,
                                      backgroundColor=STATUS)

        def step(title, hint):
            cmds.setParent(col)
            cmds.frameLayout(label=title, collapsable=True, marginWidth=8, marginHeight=6,
                             backgroundColor=HEADER, font="boldLabelFont",
                             expandCommand=self.relayout, collapseCommand=self.relayout)
            cmds.columnLayout(adjustableColumn=True, rowSpacing=5)
            # fixed height, no word-wrap: wrapped text makes Maya under-size the fold,
            # which clipped the last row of every step
            cmds.text(label=hint, align="left", height=18, font="smallPlainLabelFont",
                      enableBackground=False)

        g = self.guides
        step("1   Guides", "Place a guide on every joint of the character.")
        self.main("Create Guides", self.create_guides,
                  "Select the character (meshes or their group) first. Guides scale to it.",
                  (0, 1))
        self.tools(("Fit to Mesh", lambda: g.fit(self.value("fingers")),
                    "Centre knees, elbows, wrists, fingers and spine inside the body", (1, 1)),
                   ("Show / Hide", g.toggle, "Show or hide the guides", (1, 5)),
                   ("X-Ray", self.toggle_xray, "See-through mesh on / off", (0, 5)),
                   ("Delete", g.delete, "Delete the guides", (1, 1), True))
        self.options()
        self.check("tpose", "Start in T-pose", "Arms straight out instead of A-pose",
                   value=False)
        self.check("follow", "Move children with parent",
                   "Moving / rotating a guide carries everything below it",
                   changeCommand=lambda v: g.set_follow(v))
        self.check("fingers", "Fit fingers too", "Fit to Mesh also centres the fingers")
        self.end_options()

        step("2   Skeleton", "Game-ready joints from the guides (UE5 names).")
        # limb correctives are switched off for now (base skeleton + skin first)
        self.main("Build Skeleton",
                  lambda: Skeleton().build(helpers=False, correctives=False),
                  "Joints from the guides (UE5 names, twist joints, mirrored right side)",
                  (1, 1))
        self.tools(("Delete Skeleton", Skeleton().delete,
                    "Back to the guides (removes skin and rig too)", (2, 5), True))
        # every corrective (the chest's too) is added in the Correctives tab AFTER the
        # skin, one at a time, so you see exactly where each one acts

        d = Deformation()
        step("3   Skin", "One click: a finished, game-ready skin.")
        self.main("Skin Mesh", lambda: d.skin(shapes=self.value("shapes")),
                  "Game-ready linear skin (4 influences), finished in one click: heat map "
                  "body + voxel hands / feet, limb ownership and twist spread, hip line, "
                  "clean head / neck, smooth transitions and a smoothing pass over extreme "
                  "poses",
                  (2, 2))
        self.tools(("Mirror L>R", d.mirror_weights, "Copy left-side weights to the right",
                    (3, 5)),
                   ("Unbind", d.unbind, "Remove the skin (materials kept)", (3, 3), True))
        self.tools(("Smooth Weights", fixmesh.smooth_selected,
                    "Select stray vertices and press: their weights are rebuilt from the "
                    "vertices around them, so they blend evenly in every pose. (Skin Mesh "
                    "already checks extreme poses and repairs strays by itself.)", (3, 5)))
        self.options()
        self.check("shapes", "Corrective + breathing shapes",
                   "Blend shapes made for this mesh: knees, elbows, hips and shoulders keep "
                   "their shape in deep bends; Breath / Belly_Breath on the chest ctrls "
                   "expand and lift the ribcage / push the belly out.")
        self.end_options()

        step("4   Rig", "Controls, IK / FK, spaces.")
        self.main("Build Rig", lambda: PreviewRig().build(fit_shapes=self.value("wrap")),
                  "Controls, IK/FK, spaces - on top of the skinned skeleton", (2, 3))
        self.tools(("Finalize", PreviewRig().finalize,
                    "Hand-off clean-up: bakes away construction history (skin kept), prunes "
                    "and caps the skin at 4 influences, drops unused influences, frees the "
                    "Outliner toggles. Run it last, before export.", (4, 4)),
                   ("Remove Rig", PreviewRig().remove,
                    "Back to the skinned skeleton (skin is kept)", (4, 5), True))
        self.options()
        self.check("wrap", "Fit controls to the body",
                   "Resize controls so they wrap this character's body")
        self.end_options()

        cmds.setParent(tabs)
        cor_tab = cmds.scrollLayout(childResizable=True, horizontalScrollBarThickness=0)
        self._correctives_tab()
        cmds.tabLayout(tabs, edit=True, tabLabel=((build_tab, "Build"),
                                                  (cor_tab, "Correctives")),
                       changeCommand=self.nudge)
        cmds.showWindow(config.WINDOW)
        self.min_width(self.WIDTH)
        self.fit()
        self.relayout()                                 # re-measure once it's on screen
        self._watch_focus()
        cmds.scriptJob(event=["SelectionChanged", self.redirect_selection],
                       parent=config.WINDOW)
        for ev in ("Undo", "Redo", "SceneOpened", "NewSceneOpened"):   # keep the status true
            cmds.scriptJob(event=[ev, self.refresh], parent=config.WINDOW)
        self.refresh()
        return self
