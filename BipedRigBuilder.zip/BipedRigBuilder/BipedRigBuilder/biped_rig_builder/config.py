"""Every name, colour and path the tool uses."""
import os

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PACKAGE_DIR, "data")

TITLE = "Biped Rig Builder"
WINDOW = "bipedRigBuilderWin"

# guides
GUIDE_GRP = "biped_guides"
GUIDE_SUFFIX = "_guide"
ORIENT_SUFFIX = "_guide_orient"
GUIDE_UTIL = "biped_guide_util"          # prefix of the guides' DG helper nodes

# preview rig
RIG_TOP = "Biped_Rig"
RIG_UTIL = "biped_preview_util"          # prefix of the rig's DG helper nodes
SKEL_UTIL = "biped_skel_util"            # prefix of skeleton-level nodes (twist, helpers)
HOOK_SUFFIX = "_preview_parentConstraint"
DISPLAY_ENUM = "Normal:Template:Reference"

# colours (Maya index colours)
SIDE_COLOR = {"c": 17, "l": 13, "r": 6}  # yellow / red / blue
MIRROR_COLOR = {13: 6, 6: 13}
AXIS_COLOR = (13, 14, 6)                 # X red, Y green, Z blue
HELPER_COLOR = 9                         # magenta corrective joints
TWIST_COLOR = 18                         # light blue twist joints
TWIST_RADIUS = 1.6                       # twist joint size vs the limb joints (bigger = easy to see)
DRIVER_REV = "10"                         # bump when the skeleton drivers change: rebuilt on next Build Rig

# skinning
MAX_INFLUENCES = 4

# the character must face +Z (Maya's front view), its left on +X - UE5 / Maya convention
FACING_MSG = ("The character faces -Z (away from Maya's front view). Sides are named for a "
              "character facing +Z, so left and right would come out swapped. Rotate the "
              "character 180 in Y (and freeze transforms) so it faces +Z, then Create Guides "
              "again.")
