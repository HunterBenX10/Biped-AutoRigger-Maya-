"""IK/FK machinery, built inside Rig_Systems (hidden from animators).

Same architecture as the reference rig:
  * every limb / the spine gets a <joint>_fk and a <joint>_ik driver chain
  * bind joints are parentConstrained to both; IK_FK_Switch (1 = FK) sets the weights
  * legs/arms: RP IK handle + pole vector, end joints oriented by the IK ctrls,
    stretch (0-1 "stretch" attr on the IK ctrl), foot-roll attrs proxied onto the
    leg IK ctrl
  * spine: spline IK on a curve skinned to 3 ctrl joints, advanced twist
  * space switches (enum attrs)
Everything is driven by data/rig_rules.json.
"""
import math

import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes


def _util(node_type, tag):
    return cmds.createNode(node_type, name="{}_{}".format(config.RIG_UTIL, tag))


def _sides(name):
    return "lr" if names.is_left(name) else "c"


class Systems(object):
    def __init__(self, systems_grp):
        self.grp = systems_grp
        self.rules = data.rules()
        self._rev = {}
        self._scale = None

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def target(name, side):
        """A joint as-is, a ctrl through its follower (constraints and Offset Parent
        Matrix don't mix)."""
        n = names.for_side(name, side)
        if not cmds.objExists(n):
            return None
        return n if cmds.nodeType(n) == "joint" else nodes.follower(n)

    def reverse(self, plug):
        if plug not in self._rev:
            r = _util("reverse", plug.replace(".", "_") + "_rev")
            cmds.connectAttr(plug, r + ".inputX")
            self._rev[plug] = r + ".outputX"
        return self._rev[plug]

    def world_scale(self):
        if self._scale is None:
            nodes.ensure_plugins("matrixNodes")
            dm = _util("decomposeMatrix", "world_scale")
            cmds.connectAttr("World_ctrl.worldMatrix[0]", dm + ".inputMatrix")
            # (sx * sy * sz) ^ 1/3: one size even if World_ctrl is scaled on one axis
            xy = _util("multiplyDivide", "world_scale_xy")
            cmds.connectAttr(dm + ".outputScaleX", xy + ".input1X")
            cmds.connectAttr(dm + ".outputScaleY", xy + ".input2X")
            xyz = _util("multiplyDivide", "world_scale_xyz")
            cmds.connectAttr(xy + ".outputX", xyz + ".input1X")
            cmds.connectAttr(dm + ".outputScaleZ", xyz + ".input2X")
            root = _util("multiplyDivide", "world_scale_cbrt")
            cmds.setAttr(root + ".operation", 3)
            cmds.connectAttr(xyz + ".outputX", root + ".input1X")
            cmds.setAttr(root + ".input2X", 1.0 / 3.0)
            self._scale = root + ".outputX"
        return self._scale

    def group(self, name, follow=None):
        g = cmds.createNode("transform", name=name, parent=self.grp)
        if follow:
            cmds.parentConstraint(follow, g, maintainOffset=True)
        return g

    CHAIN_COLOR = {"_fk": 6, "_ik": 13}            # FK blue, IK red (when Rig_Systems is shown)

    @classmethod
    def chain(cls, joints, suffix, parent):
        """Driver copy of bind joints: same placement, rotation in jointOrient."""
        out = []
        for j in joints:
            d = cmds.createNode("joint", name=j + suffix, parent=out[-1] if out else parent)
            cmds.setAttr(d + ".radius", cmds.getAttr(j + ".radius") * 1.3)
            nodes.style(d, cls.CHAIN_COLOR.get(suffix))
            cmds.setAttr(d + ".rotateOrder", cmds.getAttr(j + ".rotateOrder"))
            cmds.xform(d, ws=True, matrix=cmds.xform(j, q=True, ws=True, matrix=True))
            cmds.makeIdentity(d, apply=True, rotate=True, scale=True)
            out.append(d)
        return out

    def blend(self, bind, fk, ik, switch):
        """Bind joint follows FK at switch = 1, IK at 0."""
        con = cmds.parentConstraint(fk, ik, bind, maintainOffset=True,
                                    name=bind + config.HOOK_SUFFIX)[0]
        cmds.setAttr(con + ".interpType", 2)
        w_fk, w_ik = cmds.parentConstraint(con, q=True, weightAliasList=True)
        cmds.connectAttr(switch, con + "." + w_fk)
        cmds.connectAttr(self.reverse(switch), con + "." + w_ik)

    # ---------------------------------------------------------------- limbs
    def limbs(self):
        built = []
        for kind, cfg in self.rules["limbs"].items():
            for side in "lr":
                f = lambda n: names.for_side(n, side)
                bind = [f(j) for j in cfg["chain"]]
                need = bind + [f(cfg[k]) for k in ("switch", "ik_ctrl", "pole", "handle_parent")]
                if not all(cmds.objExists(n) for n in need):
                    continue
                self._limb(kind, side, cfg, bind, f)
                built.append(f(kind + "_l"))
        return built

    def _limb(self, kind, side, cfg, bind, f):
        switch = f(cfg["switch"]) + ".IK_FK_Switch"
        grp = self.group(f(kind + "_l_systems"), self.target(cfg["follow"], side))
        fk, ik = self.chain(bind, "_fk", grp), self.chain(bind, "_ik", grp)
        self._preferred_angle(ik, f(cfg["pole"]))
        handle = cmds.ikHandle(startJoint=ik[0], endEffector=ik[2], solver="ikRPsolver",
                               name=f(kind + "_l_ikHandle"))[0]
        handle = cmds.parent(handle, f(cfg["handle_parent"]))[0]
        cmds.setAttr(handle + ".visibility", 0)
        cmds.poleVectorConstraint(self.target(cfg["pole"], side), handle)
        for jn, ctrl in cfg["orient"].items():           # hand / foot / ball follow the ctrls
            jik = ik[cfg["chain"].index(jn)]
            t = cmds.createNode("transform", name=jik + "_target", parent=f(ctrl))
            cmds.xform(t, ws=True, matrix=cmds.xform(jik, q=True, ws=True, matrix=True))
            cmds.orientConstraint(t, jik, maintainOffset=False)
        self._stretch(ik, grp, f(cfg["ik_ctrl"]), f(cfg["handle_parent"]))
        self._pole_line(ik[1], f(cfg["pole"]), f(cfg["ik_ctrl"]))
        nodes.settle()
        self._align_twist(handle, ik, bind)
        # blend LAST, once the IK has settled - so IK and FK give the exact same rest pose
        nodes.settle()
        for b, j_fk, j_ik in zip(bind, fk, ik):
            self.blend(b, j_fk, j_ik, switch)

    @staticmethod
    def _pole_line(mid, pole, ik_ctrl):
        """Dashed-style guide line knee/elbow -> pole vector; shows with the IK ctrls."""
        nodes.ensure_plugins("matrixNodes")
        grp = cmds.listRelatives(ik_ctrl, parent=True)[0]
        crv = cmds.curve(degree=1, point=[(0, 0, 0), (0, 0, 0)], name=pole + "_line")
        crv = cmds.parent(crv, grp)[0]
        cmds.setAttr(crv + ".inheritsTransform", 0)
        for t in "tr":
            cmds.setAttr(crv + "." + t, 0, 0, 0)
        shp = cmds.listRelatives(crv, shapes=True)[0]
        for i, src in enumerate((mid, pole)):
            dm = _util("decomposeMatrix", "{}_line_{}".format(names.short(pole), i))
            cmds.connectAttr(src + ".worldMatrix[0]", dm + ".inputMatrix")
            cmds.connectAttr(dm + ".outputTranslate", "{}.controlPoints[{}]".format(shp, i))
        nodes.style(shp, template=True)           # grey, unselectable, hidden by the mesh
        nodes.lock(crv, nodes.TRS)                # visibility left free

    @staticmethod
    def _align_twist(handle, ik, bind):
        """The RP solver can settle the IK chain rolled 180 degrees round the hip->ankle
        line (knee 'facing' away from the pole) and still look identical when the leg is
        straight. The blend constraint would then hide it at rest and the knee bends the
        wrong way later - the 'inverted pole vector'. Fix: compare the IK thigh's axes
        with the bind thigh's and roll the handle (twist) until they match exactly."""
        def err():
            a, c = mathx.pos(ik[0]), mathx.pos(ik[2])
            line = (c - a).normal()
            u = mathx.axis(mathx.world(ik[0]), 0)
            v = mathx.axis(mathx.world(bind[0]), 0)
            u, v = u - line * (u * line), v - line * (v * line)
            if u.length() < 1e-6 or v.length() < 1e-6:
                return 0.0
            u.normalize()
            v.normalize()
            return math.degrees(math.atan2((u ^ v) * line, u * v))

        for _ in range(6):
            e = err()
            if abs(e) < 0.01:
                break
            if abs(e) > 90:                          # rolled over: the pole is on the
                cmds.warning("{}: IK chain rolled {:.0f} deg - the knee / elbow guide "
                             "bends away from the pole. Rebuild the skeleton (it pre-bends "
                             "limbs now).".format(handle, e))
                return
            t0 = cmds.getAttr(handle + ".twist")
            cmds.setAttr(handle + ".twist", t0 + e)
            nodes.settle()
            if abs(err()) > abs(e):                  # wrong sign convention: go the other way
                cmds.setAttr(handle + ".twist", t0 - e)
                nodes.settle()
        left = err()
        if abs(left) > 0.5:
            cmds.warning("{}: IK chain is {:.1f} deg off the skeleton - check the knee / "
                         "elbow guide isn't dead straight.".format(handle, left))

    @staticmethod
    def _preferred_angle(ik, pole):
        """Bend the mid joint toward the pole vector so the RP solver picks that side."""
        mid, end = mathx.pos(ik[1]), mathx.pos(ik[2])
        x = mathx.axis(mathx.world(ik[1]), 0)
        to_pole = mathx.pos(pole) - mid
        swing = (end - mid).rotateBy(om.MQuaternion(math.radians(10), x)) - (end - mid)
        # bending the knee/elbow toward the pole swings the end AWAY from it
        cmds.setAttr(ik[1] + ".preferredAngleX", 10 if swing * to_pole < 0 else -10)

    def _stretch(self, ik, start_parent, ctrl, end_parent):
        """Same network as the reference rig: past full reach the elbow/knee and the
        hand/foot IK joints slide out along their rest offsets (translate, not scale),
        so the chain still goes perfectly straight and keeps aiming at the pole vector.
            factor = blend(clamp(dist / (rest * World scale), 1, 100), 1, ctrl.stretch)
            joint.translate = rest translate * factor
        """
        if not cmds.attributeQuery("stretch", node=ctrl, exists=True):
            cmds.addAttr(ctrl, longName="stretch", attributeType="double", min=0, max=1,
                         defaultValue=1, keyable=True)
        tag = names.short(ik[0])
        start = cmds.createNode("transform", name=tag + "_stretch_start", parent=start_parent)
        end = cmds.createNode("transform", name=tag + "_stretch_end", parent=end_parent)
        cmds.xform(start, ws=True, translation=tuple(mathx.pos(ik[0])))
        cmds.xform(end, ws=True, translation=tuple(mathx.pos(ik[2])))
        rest = sum((mathx.pos(ik[i + 1]) - mathx.pos(ik[i])).length() for i in (0, 1))
        # a hair (0.05%) longer than the real chain: past full reach the chain is always a
        # touch SHORTER than the distance, so the solver locks it dead straight instead of
        # hunting for a tiny bend at the exact reach limit
        rest *= 1.0005
        dist = _util("distanceBetween", tag + "_stretch_dist")
        cmds.connectAttr(start + ".worldMatrix[0]", dist + ".inMatrix1")
        cmds.connectAttr(end + ".worldMatrix[0]", dist + ".inMatrix2")
        scaled = nodes.mult("{}_{}_stretch_rest".format(config.RIG_UTIL, tag))
        cmds.setAttr(scaled + ".input1", rest)
        cmds.connectAttr(self.world_scale(), scaled + ".input2")
        ratio = _util("multiplyDivide", tag + "_stretch_ratio")
        cmds.setAttr(ratio + ".operation", 2)
        cmds.connectAttr(dist + ".distance", ratio + ".input1X")
        cmds.connectAttr(scaled + ".output", ratio + ".input2X")
        clamp = _util("clamp", tag + "_stretch_clamp")             # never shrink
        cmds.setAttr(clamp + ".minR", 1)
        cmds.setAttr(clamp + ".maxR", 100)
        cmds.connectAttr(ratio + ".outputX", clamp + ".inputR")
        mix = _util("blendColors", tag + "_stretch_blend")         # stretch attr on/off
        cmds.connectAttr(clamp + ".outputR", mix + ".color1R")
        cmds.setAttr(mix + ".color2R", 1)
        cmds.connectAttr(ctrl + ".stretch", mix + ".blender")
        for j in ik[1:3]:
            md = _util("multiplyDivide", names.short(j) + "_stretch_md")
            cmds.setAttr(md + ".input1", *cmds.getAttr(j + ".translate")[0])
            for ax in "XYZ":
                cmds.connectAttr(mix + ".outputR", md + ".input2" + ax)
            cmds.connectAttr(md + ".output", j + ".translate", force=True)

    def foot_proxies(self):
        """heelRoll, toeRoll, bankIn... on the leg IK ctrl, driving the visible pivot ctrls."""
        for ctrl, attrs in self.rules["foot_proxies"].items():
            for side in _sides(ctrl):
                c = names.for_side(ctrl, side)
                if not cmds.objExists(c):
                    continue
                cmds.addAttr(c, longName="FOOT", attributeType="enum", enumName="--------")
                cmds.setAttr(c + ".FOOT", channelBox=True, lock=True)
                for attr, plug in attrs.items():
                    plug = names.for_side(plug, side)
                    if cmds.objExists(plug):
                        cmds.addAttr(c, longName=attr, proxy=plug)

    def heel_bank(self):
        """Tilting the heel ctrl sideways (rotate Z) banks the foot: it rolls on the edge
        that stays on the ground - the bank in / bank out pivot - instead of spinning on
        the heel point. The heel's own Z is cancelled in its offset group (same pivot), so
        the heel ctrl turns with the foot exactly once. The bank ctrls still work on top."""
        made = 0
        for side in "lr":
            f = lambda n: names.for_side(n, side)
            heel, heel_off = f("foot_l_heel_ctrl"), f("foot_l_heel_ctrl_off_grp")
            banks = [f("foot_l_bankIn_ctrl_off_grp"), f("foot_l_bankOut_ctrl_off_grp")]
            if not all(cmds.objExists(n) for n in [heel, heel_off] + banks):
                continue
            # rotate Z + lifts the +X side, so the foot rests on the edge with the smaller X
            low, high = sorted(banks, key=lambda n: mathx.pos(n).x)
            tag = names.short(heel)
            for grp, lo, hi in ((low, 0, 180), (high, -180, 0)):
                cl = _util("clamp", "{}_bank_{}".format(tag, "pos" if lo == 0 else "neg"))
                cmds.setAttr(cl + ".minR", lo)
                cmds.setAttr(cl + ".maxR", hi)
                cmds.connectAttr(heel + ".rotateZ", cl + ".inputR")
                cmds.connectAttr(cl + ".outputR", grp + ".rotateZ", force=True)
            neg = nodes.mult("{}_{}".format(config.RIG_UTIL, tag + "_bank_cancel"))
            cmds.setAttr(neg + ".input2", -1)
            cmds.connectAttr(heel + ".rotateZ", neg + ".input1")
            cmds.connectAttr(neg + ".output", heel_off + ".rotateZ", force=True)
            made += 1
        return made

    # ---------------------------------------------------------------- spine
    def spine(self):
        cfg = self.rules["spine"]
        bind, switch = cfg["chain"], cfg["switch"] + ".IK_FK_Switch"
        if not all(cmds.objExists(n) for n in bind + [cfg["switch"]]):
            return False
        grp = self.group("spine_systems")
        fk, ik = self.chain(bind, "_fk", grp), self.chain(bind, "_ik", grp)
        # curve passes THROUGH every spine joint, so the spline IK doesn't shift them
        curve = cmds.curve(editPoint=[tuple(mathx.pos(j)) for j in ik], degree=3,
                           name="spine_ik_curve")
        handle = cmds.ikHandle(startJoint=ik[0], endEffector=ik[-1], solver="ikSplineSolver",
                               createCurve=False, curve=curve, name="spine_ikHandle")[0]
        for n in (handle, curve):            # (Maya sometimes moves the curve already)
            if (cmds.listRelatives(n, parent=True) or [None])[0] != grp:
                cmds.parent(n, grp)
        cmds.setAttr(handle + ".visibility", 0)
        cmds.setAttr(curve + ".inheritsTransform", 0)   # skinned: never move it twice
        ctrl_jnts = []
        for tag, at, ctrl in cfg["ctrl_joints"]:
            j = cmds.createNode("joint", name="spine_{}_ctrl_jnt".format(tag), parent=grp)
            cmds.xform(j, ws=True, translation=tuple(mathx.pos(at)))
            cmds.parentConstraint(self.target(ctrl, "c"), j, maintainOffset=True)
            cmds.setAttr(j + ".radius", cmds.getAttr(at + ".radius") * 2)
            nodes.style(j, 17)                               # yellow curve ctrl joints
            ctrl_jnts.append(j)
        sc = cmds.skinCluster(ctrl_jnts, curve, toSelectedBones=True, maximumInfluences=2,
                              name=config.RIG_UTIL + "_spine_curve_skinCluster")[0]
        nodes.delete(*(cmds.listConnections(sc + ".bindPose", source=True,
                                            destination=False) or []))
        self._spine_curve_weights(sc, curve, ctrl_jnts)
        # advanced twist: start/end ctrl joints, joints aim +Y with +Z up (world-aligned)
        for attr, value in (("dTwistControlEnable", 1), ("dWorldUpType", 4),
                            ("dForwardAxis", 2), ("dWorldUpAxis", 3)):
            cmds.setAttr("{}.{}".format(handle, attr), value)
        for attr in ("dWorldUpVector", "dWorldUpVectorEnd"):
            cmds.setAttr("{}.{}".format(handle, attr), 0, 0, 1)
        cmds.connectAttr(ctrl_jnts[0] + ".worldMatrix[0]", handle + ".dWorldUpMatrix")
        cmds.connectAttr(ctrl_jnts[-1] + ".worldMatrix[0]", handle + ".dWorldUpMatrixEnd")
        # RULE: the chest IS the upper ctrl. The spline solver only rotates the joints
        # BEFORE its end joint, so spine_05 just inherited spine_04 and lagged behind
        # spine_upper_ctrl (and the clavicles / neck that follow spine_05 with it):
        # the end joint now takes the ctrl's rotation 1:1.
        upper = self.target(cfg["ctrl_joints"][-1][2], "c")
        end_t = cmds.createNode("transform", name=ik[-1] + "_target", parent=upper)
        cmds.xform(end_t, ws=True, matrix=cmds.xform(ik[-1], q=True, ws=True, matrix=True))
        cmds.orientConstraint(end_t, ik[-1], maintainOffset=False)
        self._spine_stretch(curve, ik, cfg["switch"])
        nodes.settle()
        for b, j_fk, j_ik in zip(bind, fk, ik):         # last: after the spline has settled
            self.blend(b, j_fk, j_ik, switch)
        return True

    @staticmethod
    def _spine_curve_weights(sc, curve, ctrl_jnts):
        """Explicit curve CV weights (instead of distance-based): the first two CVs ride
        the lower ctrl, the last two the upper ctrl - so the END TANGENT turns exactly
        with the ctrl - and the CVs between blend by where they sit along the curve."""
        shape = cmds.listRelatives(curve, shapes=True, fullPath=True)[0]
        n = cmds.getAttr(shape + ".spans") + cmds.getAttr(shape + ".degree")
        if n < 5 or len(ctrl_jnts) != 3:
            return
        lo, mid, hi = ctrl_jnts
        # written straight into weightList with normalising paused: skinPercent
        # re-normalised each CV against the old weights and printed "Some weights
        # required modification for normalization"
        col = {}
        for j in ctrl_jnts:
            plug = cmds.listConnections(j + ".worldMatrix[0]", type="skinCluster",
                                        plugs=True) or []
            plug = [p for p in plug if p.split(".")[0] == sc]
            if not plug:
                return
            col[j] = int(plug[0].split("[")[-1].rstrip("]"))
        cmds.setAttr(sc + ".normalizeWeights", 0)
        for i in range(n):
            if i <= 1:
                tv = [(lo, 1.0)]
            elif i >= n - 2:
                tv = [(hi, 1.0)]
            else:
                f = (i - 1) / float(n - 3)                  # 0 at CV1 .. 1 at CV n-2
                tv = [(lo, max(0.0, 1 - 2 * f)), (mid, 1 - abs(2 * f - 1)),
                      (hi, max(0.0, 2 * f - 1))]
            tot = sum(x for _, x in tv) or 1.0
            for j in ctrl_jnts:
                x = dict(tv).get(j, 0.0) / tot
                cmds.setAttr("{}.weightList[{}].weights[{}]".format(sc, i, col[j]), x)
        cmds.setAttr(sc + ".normalizeWeights", 1)

    def _spine_stretch(self, curve, ik, ctrl):
        """Spine joints stretch/squash with the curve length, so the chest stays on the
        upper spine ctrl when the hips wiggle (no bobbing up and down).
        Spine_Stretch on cog_ctrl: 1 = on, 0 = fixed length."""
        if not cmds.attributeQuery("Spine_Stretch", node=ctrl, exists=True):
            cmds.addAttr(ctrl, longName="Spine_Stretch", attributeType="double", min=0, max=1,
                         defaultValue=1, keyable=True)
        shape = cmds.listRelatives(curve, shapes=True, fullPath=True)[0]
        info = _util("curveInfo", "spine_curve_info")
        cmds.connectAttr(shape + ".worldSpace[0]", info + ".inputCurve")
        rest = cmds.getAttr(info + ".arcLength")
        scaled = nodes.mult("{}_spine_stretch_rest".format(config.RIG_UTIL))
        cmds.setAttr(scaled + ".input1", rest)
        cmds.connectAttr(self.world_scale(), scaled + ".input2")
        ratio = _util("multiplyDivide", "spine_stretch_ratio")
        cmds.setAttr(ratio + ".operation", 2)
        cmds.connectAttr(info + ".arcLength", ratio + ".input1X")
        cmds.connectAttr(scaled + ".output", ratio + ".input2X")
        mix = _util("blendColors", "spine_stretch_blend")
        cmds.connectAttr(ratio + ".outputX", mix + ".color1R")
        cmds.setAttr(mix + ".color2R", 1)
        cmds.connectAttr(ctrl + ".Spine_Stretch", mix + ".blender")
        for j in ik[1:]:
            md = _util("multiplyDivide", names.short(j) + "_stretch_md")
            cmds.setAttr(md + ".input1", *cmds.getAttr(j + ".translate")[0])
            for ax in "XYZ":
                cmds.connectAttr(mix + ".outputR", md + ".input2" + ax)
            cmds.connectAttr(md + ".output", j + ".translate", force=True)

    # ---------------------------------------------------------------- spaces
    def spaces(self):
        """Enum space switches: each option turns on one constraint weight."""
        made = []
        for sp in self.rules["spaces"]:
            for side in _sides(sp["ctrl"]):
                ctrl, grp = names.for_side(sp["ctrl"], side), names.for_side(sp["group"], side)
                targets = [self.target(t, side) for t in sp["targets"]]
                if not (cmds.objExists(ctrl) and cmds.objExists(grp)) or None in targets:
                    continue
                cmds.addAttr(ctrl, longName=sp["attr"], attributeType="enum",
                             enumName=":".join(sp["names"]), defaultValue=sp["default"],
                             keyable=True)
                # parentConstraint even for rotation-only spaces: it keeps a SEPARATE offset
                # per target, so every space gives the exact same rest orientation and
                # switching never rotates the ctrl (orientConstraint keeps only ONE offset,
                # taken from the blend of all targets - that was the head popping)
                kw = dict(skipTranslate=("x", "y", "z")) if sp["kind"] == "orient" else {}
                if sp.get("pivot"):
                    # RULE: a rotation-only space turns its group round the joint it
                    # serves. The layout put the FK arm group at the WORLD ORIGIN, so any
                    # space but its own parent's swung the whole arm round the feet
                    pj = names.for_side(sp["pivot"], side)
                    if cmds.objExists(pj):
                        p = cmds.xform(pj, q=True, ws=True, translation=True)
                        cmds.xform(grp, ws=True, pivots=p)
                con = cmds.parentConstraint(*(targets + [grp]), maintainOffset=True, **kw)[0]
                cmds.setAttr(con + ".interpType", 2)
                for i, alias in enumerate(cmds.parentConstraint(con, q=True,
                                                                weightAliasList=True)):
                    c = _util("condition", "{}_{}_{}".format(names.short(ctrl), sp["attr"], i))
                    cmds.connectAttr("{}.{}".format(ctrl, sp["attr"]), c + ".firstTerm")
                    cmds.setAttr(c + ".secondTerm", i)
                    cmds.setAttr(c + ".colorIfTrueR", 1)
                    cmds.setAttr(c + ".colorIfFalseR", 0)
                    cmds.connectAttr(c + ".outColorR", con + "." + alias)
                if sp.get("translate"):    # rides on the neck like a child (orbits with it)
                    cmds.parentConstraint(self.target(sp["translate"], side), grp,
                                          maintainOffset=True, skipRotate=("x", "y", "z"))
                made.append("{}.{}".format(ctrl, sp["attr"]))
        return made
