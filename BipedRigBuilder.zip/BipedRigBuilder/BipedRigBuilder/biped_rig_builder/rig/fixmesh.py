"""Fix Mesh - repair bad deformation by sculpting, solved back into SKIN WEIGHTS.

  1. Pose the character (a test pose, or the rig ctrls) where it deforms badly.
  2. Fix Pose      a sculptable copy of the posed mesh appears (blue) and the real one
                   hides. Sculpt / move vertices until the shape looks right.
  3. Apply Fix     every vertex you moved gets new weights so the skin itself makes
                   that shape: for each vertex the solver picks weights (>= 0, sum 1,
                   max 4) over its own joints + its neighbours' joints that best
                   reproduce your fix - in THIS pose and every pose fixed before, while
                   staying close to the old weights (so other poses don't break).
  Cancel Fix       throws the sculpt away.

It only ever changes weights, so the result exports to any engine exactly as it looks.
Linear skinning can't make every shape - the console reports how much of each fix was
matched; what's left over is a job for a corrective joint.

Fixes are stored on the skinCluster (attr brb_fixes) and re-used by later fixes.
"""
import json

import maya.cmds as cmds
import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

from .. import config
from ..core import names, nodes

SUFFIX = "_FIX"
ATTR = "brb_fixes"
MOVED = 1e-4                 # a vertex counts as edited past this (fraction of height)
STAY = 0.08                  # how strongly weights stay near the old ones (0 = free)
CANDIDATES = 6               # joints a vertex may choose from


# ---------------------------------------------------------------- helpers
def _dag(node):
    sel = om.MSelectionList()
    sel.add(node)
    return sel.getDagPath(0)


def _skin_of(shape_or_transform):
    hist = cmds.listHistory(shape_or_transform, pruneDagObjects=True) or []
    scs = cmds.ls(hist, type="skinCluster")
    return scs[0] if scs else None


def _target():
    """The skinned mesh to fix: the selected one, else the body (most height)."""
    from .deform import Deformation
    sel = [s for s in cmds.ls(selection=True, long=True) or [] if _skin_of(s)]
    if sel:
        return sel[0], _skin_of(sel[0])
    skins = Deformation.skins()
    if not skins:
        cmds.error("Skin the mesh first.")
    shapes = [(cmds.skinCluster(sc, q=True, geometry=True) or [None])[0] for sc in skins]

    def height(shape):
        bb = cmds.exactWorldBoundingBox(shape)
        return bb[4] - bb[1]
    i = max(range(len(skins)), key=lambda k: height(shapes[k]) if shapes[k] else 0)
    return cmds.listRelatives(shapes[i], parent=True, fullPath=True)[0], skins[i]


def _pending():
    return cmds.ls("*" + SUFFIX, long=True, type="transform") or []


# ---------------------------------------------------------------- 1. Fix Pose
def start():
    for old in _pending():
        cmds.delete(old)
    mesh, sc = _target()
    fix = cmds.duplicate(mesh, name=names.short(mesh) + SUFFIX)[0]
    for s in cmds.listRelatives(fix, shapes=True, fullPath=True) or []:
        if cmds.getAttr(s + ".intermediateObject"):
            cmds.delete(s)
    for attr in ("t", "r", "s"):
        for ax in "xyz":
            cmds.setAttr("{}.{}{}".format(fix, attr, ax), lock=False)
    if cmds.listRelatives(fix, parent=True):
        fix = cmds.parent(fix, world=True)[0]
    shader = "brb_fix_blinn"
    if not cmds.objExists(shader):
        shader = cmds.shadingNode("blinn", asShader=True, name=shader)
        cmds.setAttr(shader + ".color", 0.25, 0.5, 0.9, type="double3")
    cmds.sets(fix, edit=True, forceElement=_sg(shader))
    nodes.add_string(fix, "brb_source", mesh)
    nodes.add_string(fix, "brb_skin", sc)
    nodes.add_string(fix, "brb_pose", json.dumps(_pose(sc)))
    _show(mesh, False)
    cmds.select(fix)
    print("Fix Pose: sculpt / move vertices on {} (blue), then Apply Fix.".format(
        names.short(fix)))
    return fix


def _show(mesh, on):
    """Hide the real mesh while sculpting (lodVisibility - never touches what you edit)."""
    try:
        cmds.setAttr(mesh + ".lodVisibility", 1 if on else 0)
    except RuntimeError:
        pass


def _sg(shader):
    sg = shader + "SG"
    if not cmds.objExists(sg):
        sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name=sg)
        cmds.connectAttr(shader + ".outColor", sg + ".surfaceShader")
    return sg


def _shape(transform):
    return [s for s in cmds.listRelatives(transform, shapes=True, fullPath=True) or []
            if not cmds.getAttr(s + ".intermediateObject")][0]


def _pose(sc):
    """bindPre x world matrix per influence (by name) for the current pose."""
    fn = oma.MFnSkinCluster(_dep(sc))
    out = {}
    for p in fn.influenceObjects():
        idx = fn.indexForInfluenceObject(p)
        pre = om.MMatrix(cmds.getAttr("{}.bindPreMatrix[{}]".format(sc, idx)))
        wm = om.MMatrix(cmds.getAttr(p.fullPathName() + ".worldMatrix[0]"))
        m = pre * wm
        out[names.short(p.partialPathName())] = [m.getElement(i // 4, i % 4)
                                                 for i in range(16)]
    return out


def _dep(node):
    sel = om.MSelectionList()
    sel.add(node)
    return sel.getDependNode(0)


# ---------------------------------------------------------------- 3. Apply / Cancel
def cancel():
    for fix in _pending():
        src = nodes.get_string(fix, "brb_source")
        if src and cmds.objExists(src):
            _show(src, True)
        cmds.delete(fix)
    print("Fix cancelled.")


def apply():
    fixes = _pending()
    if not fixes:
        cmds.error("Press Fix Pose first.")
    fix = fixes[0]
    mesh, sc = nodes.get_string(fix, "brb_source"), nodes.get_string(fix, "brb_skin")
    pose = json.loads(nodes.get_string(fix, "brb_pose"))
    from .skeleton import Skeleton
    eps = Skeleton.height() * MOVED
    posed = om.MFnMesh(_dag(_shape(mesh))).getPoints(om.MSpace.kWorld)
    target = om.MFnMesh(_dag(_shape(fix))).getPoints(om.MSpace.kWorld)
    moved = {v: [target[v].x, target[v].y, target[v].z]
             for v in range(min(len(posed), len(target)))
             if posed[v].distanceTo(target[v]) > eps}
    _show(mesh, True)
    cmds.delete(fix)
    if not moved:
        cmds.warning("No vertices were moved - nothing to fix.")
        return
    _commit(mesh, sc, pose, moved, "Apply Fix")


def _commit(mesh, sc, pose, moved, label):
    """Store this pose's targets with the earlier ones and re-solve the touched verts."""
    with nodes.undo_chunk():
        stored = json.loads(nodes.get_string(sc, ATTR) or "[]")
        stored.append({"pose": pose, "targets": {str(k): v for k, v in moved.items()}})
        nodes.add_string(sc, ATTR, json.dumps(stored))
        matched = _solve(mesh, sc, stored, set(moved))
    print("{}: {} vertices re-weighted, {:.0f}% of the change matched by the skin ({} "
          "fixed pose(s) kept in balance). Anything left over needs a corrective.".format(
              label, len(moved), matched * 100, len(stored)))


# ---------------------------------------------------------------- Smooth Pose
def smooth_selected(grow_rings=1):
    """Smooth Weights button: the selected vertices (+ a ring) get their weights rebuilt
    from the vertices around them (each = the average of its neighbours, the border held
    fixed), so a stray patch blends evenly into its surroundings in EVERY pose - not just
    nudged. Nothing selected: Smooth Pose behaviour (finds the bad area on this frame)."""
    mesh, sc, verts = _smooth_target()
    if not verts:
        return smooth()
    import numpy as np
    from . import stretchmath as st
    from .skin import _np_weights, _np_set, _edges
    shape = _shape(mesh)
    fn, dag, mfn, comp, W, infl = _np_weights(sc, shape)
    edges = _edges(mfn)
    region = np.zeros(len(W), bool)
    region[list(verts)] = True
    region = st.grow(region, edges, grow_rings)
    with nodes.undo_chunk():
        _np_set(fn, dag, comp, st.heal(W, region, edges, max_inf=config.MAX_INFLUENCES))
    print("Smooth Weights: {} vertices re-blended from their surroundings.".format(
        int(region.sum())))


def smooth(strength=0.6, iterations=4, rings=2):
    """On a bad frame: even out the deformation, then bake it into the weights.
    Selected vertices / edges / faces are relaxed; with nothing selected the tool finds
    the problem area itself (triangles squashed below 40% or stretched past 250% of
    their bind size, plus a couple of rings around them). Relaxing is Taubin smoothing
    (shrink + grow passes) so the area evens out without losing volume; the vertices
    around it stay put. The result goes through the same solver as Apply Fix."""
    mesh, sc, verts = _smooth_target()
    shape = _shape(mesh)
    dag = _dag(shape)
    posed = om.MFnMesh(dag).getPoints(om.MSpace.kWorld)
    nbrs = _neighbours(dag)
    if not verts:
        verts = _bad_area(mesh, sc, dag, posed, nbrs, rings)
        if not verts:
            print("Smooth Pose: nothing squashed or over-stretched on this frame.")
            return
    pts = [om.MVector(p) for p in posed]
    for _ in range(iterations):
        for factor in (0.5 * strength, -0.53 * strength):           # Taubin
            new = {}
            for v in verts:
                ns = nbrs[v]
                if not ns:
                    continue
                avg = sum((pts[u] for u in ns), om.MVector()) / len(ns)
                new[v] = pts[v] + (avg - pts[v]) * factor
            for v, p in new.items():
                pts[v] = p
    from .skeleton import Skeleton
    eps = Skeleton.height() * MOVED
    moved = {v: [pts[v].x, pts[v].y, pts[v].z] for v in verts
             if (pts[v] - om.MVector(posed[v])).length() > eps}
    if not moved:
        print("Smooth Pose: already even here.")
        return
    _commit(mesh, sc, _pose(sc), moved, "Smooth Pose")
    cmds.select(["{}.vtx[{}]".format(shape, v) for v in sorted(moved)])


def _smooth_target():
    """(mesh, skinCluster, selected vertex ids) - from a component selection, a selected
    mesh, or the body."""
    sel = [s for s in cmds.ls(selection=True, long=True) or [] if "." in s]   # components
    comps = cmds.polyListComponentConversion(sel, toVertex=True) if sel else []
    comps = cmds.ls(comps or [], flatten=True, long=True)
    if comps:
        node = comps[0].split(".")[0]
        if cmds.nodeType(node) == "mesh":
            node = cmds.listRelatives(node, parent=True, fullPath=True)[0]
        sc = _skin_of(node)
        if not sc:
            cmds.error("The selected vertices aren't on a skinned mesh.")
        ids = {int(c.split("[")[-1].rstrip("]")) for c in comps
               if c.split(".")[0] in (node, _shape(node))}
        return node, sc, ids
    mesh, sc = _target()
    return mesh, sc, set()


def _neighbours(dag):
    out = {}
    it = om.MItMeshVertex(dag)
    while not it.isDone():
        out[it.index()] = list(it.getConnectedVertices())
        it.next()
    return out


def _bad_area(mesh, sc, dag, posed, nbrs, rings, squash=0.4, stretch=2.5):
    bind = _bind_points(mesh, sc)
    tris = list(om.MFnMesh(dag).getTriangles()[1])
    bad = set()
    for k in range(0, len(tris), 3):
        a, b, c = tris[k:k + 3]
        r = ((om.MVector(bind[b]) - om.MVector(bind[a])) ^
             (om.MVector(bind[c]) - om.MVector(bind[a]))).length()
        p = ((om.MVector(posed[b]) - om.MVector(posed[a])) ^
             (om.MVector(posed[c]) - om.MVector(posed[a]))).length()
        if r > 1e-9 and not squash < p / r < stretch:
            bad.update((a, b, c))
    for _ in range(rings):
        bad |= {u for v in list(bad) for u in nbrs[v]}
    return bad


def clear_history():
    from .deform import Deformation
    for sc in Deformation.skins():
        if cmds.attributeQuery(ATTR, node=sc, exists=True):
            cmds.deleteAttr(sc + "." + ATTR)
    print("Stored fixes forgotten (weights stay as they are).")


# ---------------------------------------------------------------- the solver
def _bind_points(mesh, sc):
    """Vertex positions in world space going INTO the skin right now - the skin's input
    mesh, so corrective / breathing blend shapes in front of the skin are included and
    the solver doesn't try to undo them."""
    try:
        sel = om.MSelectionList()
        sel.add(sc)
        fn = om.MFnDependencyNode(sel.getDependNode(0))
        elem = fn.findPlug("input", False).elementByLogicalIndex(0)
        plug = next(elem.child(i) for i in range(elem.numChildren())
                    if elem.child(i).partialName(useLongNames=True).endswith(
                        "inputGeometry"))
        data = plug.asMObject()
        if not data.isNull():
            pts = om.MFnMesh(data).getPoints(om.MSpace.kObject)
            gm = om.MMatrix(cmds.getAttr(sc + ".geomMatrix"))
            return [om.MPoint(p) * gm for p in pts]
    except (RuntimeError, TypeError, StopIteration):
        pass
    geo = cmds.listConnections(sc + ".input[0].inputGeometry", source=True,
                               destination=False, shapes=True) or []
    for node in geo + (cmds.listHistory(sc, future=False) or []):
        if cmds.nodeType(node) == "mesh" and cmds.getAttr(node + ".intermediateObject"):
            pts = om.MFnMesh(_dag(node)).getPoints(om.MSpace.kObject)
            gm = om.MMatrix(cmds.getAttr(sc + ".geomMatrix"))
            return [om.MPoint(p) * gm for p in pts]
    cmds.error("Couldn't find the skin's original mesh.")


def _solve(mesh, sc, stored, verts):
    fn = oma.MFnSkinCluster(_dep(sc))
    shape = _shape(mesh)
    dag = _dag(shape)
    infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
    ninf = len(infl)
    comp_fn = om.MFnSingleIndexedComponent()
    comp = comp_fn.create(om.MFn.kMeshVertComponent)
    comp_fn.setCompleteData(om.MFnMesh(dag).numVertices)
    w, _ = fn.getWeights(dag, comp)
    w = list(w)
    bind = _bind_points(mesh, sc)
    it = om.MItMeshVertex(dag)
    ring = {}
    while not it.isDone():
        if it.index() in verts:
            ring[it.index()] = list(it.getConnectedVertices())
        it.next()
    mats = [{n: om.MMatrix(m) for n, m in s["pose"].items()} for s in stored]
    done = before = after = 0.0
    for v in verts:
        row = v * ninf
        old = w[row:row + ninf]
        cand = sorted(range(ninf), key=lambda i: -old[i])
        cand = [i for i in cand if old[i] > 1e-4]
        for u in ring.get(v, []):                       # neighbours' joints too
            nb = w[u * ninf:(u + 1) * ninf]
            for i in sorted(range(ninf), key=lambda k: -nb[k]):
                if nb[i] > 1e-3 and i not in cand:
                    cand.append(i)
        cand = cand[:CANDIDATES]
        if not cand:
            continue
        rows, rhs = [], []
        for s, m in zip(stored, mats):
            t = s["targets"].get(str(v))
            cols = [om.MPoint(bind[v]) * m[infl[i]] if infl[i] in m else bind[v]
                    for i in cand]
            if t is None:                     # not edited in that pose: keep its old shape
                t = [sum(old[i] * cols[k][a] for k, i in enumerate(cand)) for a in range(3)]
            for a in range(3):
                rows.append([cols[k][a] for k in range(len(cand))])
                rhs.append(t[a])
        w0 = [old[i] for i in cand]
        tot0 = sum(w0) or 1.0
        w0 = [x / tot0 for x in w0]
        new = _nnls_sum1(rows, rhs, w0, STAY)
        err = lambda ws: sum((sum(r[k] * ws[k] for k in range(len(ws))) - b) ** 2
                             for r, b in zip(rows, rhs)) ** 0.5
        before += err(w0)
        after += err(new)
        keep = sorted(range(len(cand)), key=lambda k: -new[k])[:config.MAX_INFLUENCES]
        tot = sum(new[k] for k in keep) or 1.0
        w[row:row + ninf] = [0.0] * ninf
        for k in keep:
            w[row + cand[k]] = new[k] / tot
        done += 1
    fn.setWeights(dag, comp, om.MIntArray(list(range(ninf))), om.MDoubleArray(w), True)
    return 1.0 - (after / before) if before > 1e-9 else 1.0


def _nnls_sum1(A, b, w0, lam):
    """min |A w - b|^2 + lam |w - w0|^2,  w >= 0,  sum w = 1  (tiny active-set solver).
    A is scaled so lam means the same for any character size."""
    n = len(w0)
    # sum w = 1, so each row can be measured from its own mean: only the DIFFERENCES
    # between joints matter, and lam is relative to those (same feel on any size)
    means = [sum(r) / len(r) for r in A]
    A = [[x - m for x in r] for r, m in zip(A, means)]
    b = [x - m for x, m in zip(b, means)]
    scale = max(max(abs(x) for r in A for x in r), 1e-9)
    A = [[x / scale for x in r] for r in A]
    b = [x / scale for x in b]
    active = list(range(n))
    for _ in range(n + 1):
        m = len(active)
        # KKT system for the free set:  [2(AtA+lam I)  1] [w]   [2(Atb+lam w0)]
        #                                 [ 1^T        0] [mu] = [1]
        K = [[0.0] * (m + 1) for _ in range(m + 1)]
        r = [0.0] * (m + 1)
        for i, ai in enumerate(active):
            for j, aj in enumerate(active):
                K[i][j] = 2 * sum(row[ai] * row[aj] for row in A) + (2 * lam if i == j else 0)
            K[i][m] = K[m][i] = 1.0
            r[i] = 2 * sum(row[ai] * bb for row, bb in zip(A, b)) + 2 * lam * w0[ai]
        r[m] = 1.0
        sol = _gauss(K, r)
        if sol is None:
            return w0
        ws = dict(zip(active, sol[:m]))
        neg = [i for i in active if ws[i] < 0]
        if not neg:
            return [max(ws.get(i, 0.0), 0.0) for i in range(n)]
        active.remove(min(neg, key=lambda i: ws[i]))
        if not active:
            return w0
    return w0


def _gauss(K, r):
    n = len(r)
    M = [row[:] + [r[i]] for i, row in enumerate(K)]
    for c in range(n):
        p = max(range(c, n), key=lambda i: abs(M[i][c]))
        if abs(M[p][c]) < 1e-12:
            return None
        M[c], M[p] = M[p], M[c]
        for i in range(n):
            if i != c:
                f = M[i][c] / M[c][c]
                for j in range(c, n + 1):
                    M[i][j] -= f * M[c][j]
    return [M[i][n] / M[i][i] for i in range(n)]


# ---------------------------------------------------------------- Auto Smooth (1 click)
ROGUE = 0.6          # weight difference to the neighbours' average that counts as rogue
SQUASH, STRETCH = 0.4, 2.5
PASSES = 4


def auto_smooth(quiet=False):
    """One click, no editing: goes through every test pose (makes them for the check if
    there are none), finds
       * rogue vertices - weights very different from their neighbours' (spikes, holes)
       * bad areas      - triangles squashed below 40% / stretched past 250% of bind size
    and smooths the skin WEIGHTS there (plus one ring around), keeping left / right apart
    and 4 influences. Run it again to smooth further."""
    from .deform import Deformation
    from .skin import limit_influences
    d = Deformation()
    skins = d.skins()
    if not skins:
        cmds.error("Skin the mesh first.")
    made_poses = False
    frames = d.test_frames()
    if not frames:
        d.test_poses(report=False)
        frames, made_poses = d.test_frames(), True
        if not frames:
            cmds.error("Auto Smooth needs the test poses - Remove Rig first (they key the "
                       "skeleton directly).")
    now = cmds.currentTime(q=True)
    total = 0
    with nodes.undo_chunk():
        for sc in skins:
            shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
            if not shape:
                continue
            n = _auto_one(sc, shape, frames)
            limit_influences(sc, shape)
            total += n
            print("Auto Smooth: {} - {} vertices smoothed.".format(names.short(shape), n))
        # smoothing must not blur the head / neck back into the face (measured in the
        # rest pose: frame 0 of the test poses; skipped while a rig drives the joints)
        from .preview import PreviewRig
        if not PreviewRig.exists():
            from .skin import rigid_rules
            cmds.currentTime(0)
            rigid_rules(skins)
        cmds.currentTime(now)
    if made_poses:
        d.clear_test()
    print("Auto Smooth done: {} vertices in total. Scrub the test poses - run it again "
          "where it still looks rough.".format(total))


def _bad_tris(tris, rest, pts):
    """Vertices of triangles squashed / stretched past the limits (numpy when there)."""
    try:
        import numpy as np
        t = np.array(tris, dtype=np.int64).reshape(-1, 3)
        r = np.array([(p.x, p.y, p.z) for p in rest])
        q = np.array([(p.x, p.y, p.z) for p in pts])

        def areas(a):
            return np.linalg.norm(np.cross(a[t[:, 1]] - a[t[:, 0]], a[t[:, 2]] - a[t[:, 0]]),
                                  axis=1)
        a0, a1 = areas(r), areas(q)
        ok = a0 > 1e-9
        ratio = np.where(ok, a1 / np.where(ok, a0, 1), 1)
        bad = (ratio < SQUASH) | (ratio > STRETCH)
        return set(int(v) for v in np.unique(t[bad]))
    except ImportError:
        out = set()
        for k in range(0, len(tris), 3):
            a, b, c = tris[k:k + 3]
            r0 = ((om.MVector(rest[b]) - om.MVector(rest[a])) ^
                  (om.MVector(rest[c]) - om.MVector(rest[a]))).length()
            r1 = ((om.MVector(pts[b]) - om.MVector(pts[a])) ^
                  (om.MVector(pts[c]) - om.MVector(pts[a]))).length()
            if r0 > 1e-9 and not SQUASH < r1 / r0 < STRETCH:
                out.update((a, b, c))
        return out


def _auto_one(sc, shape, frames):
    fn = oma.MFnSkinCluster(_dep(sc))
    dag = _dag(shape)
    mfn = om.MFnMesh(dag)
    infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
    sides = [names.side(n) for n in infl]
    ninf = len(infl)
    comp_fn = om.MFnSingleIndexedComponent()
    comp = comp_fn.create(om.MFn.kMeshVertComponent)
    comp_fn.setCompleteData(mfn.numVertices)
    w = list(fn.getWeights(dag, comp)[0])
    nbrs = {}
    it = om.MItMeshVertex(dag)
    while not it.isDone():
        nbrs[it.index()] = list(it.getConnectedVertices())
        it.next()
    region = set()
    for v, ns in nbrs.items():                                    # rogue weights
        if not ns:
            continue
        row = v * ninf
        diff = sum(abs(w[row + c] - sum(w[u * ninf + c] for u in ns) / len(ns))
                   for c in range(ninf))
        if diff > ROGUE:
            region.add(v)
    tris = list(mfn.getTriangles()[1])
    cmds.currentTime(0)
    rest = mfn.getPoints(om.MSpace.kWorld)
    for f in frames:                                              # bad deformation
        cmds.currentTime(f)
        region.update(_bad_tris(tris, rest, mfn.getPoints(om.MSpace.kWorld)))
    region |= {u for v in list(region) for u in nbrs[v]}         # + one ring
    if not region:
        return 0
    from .skeleton import Skeleton
    band = Skeleton.height() * 0.005
    for _ in range(PASSES):
        new = list(w)
        for v in region:
            ns = nbrs[v]
            if not ns:
                continue
            for c in range(ninf):
                new[v * ninf + c] = 0.5 * w[v * ninf + c] + \
                    0.5 * sum(w[u * ninf + c] for u in ns) / len(ns)
        w = new
    for v in region:                                              # keep sides apart
        x = rest[v].x
        wrong = "r" if x > band else "l" if x < -band else None
        if wrong:
            row = v * ninf
            for c in range(ninf):
                if sides[c] == wrong:
                    w[row + c] = 0.0
            tot = sum(w[row:row + ninf]) or 1.0
            for c in range(ninf):
                w[row + c] /= tot
    fn.setWeights(dag, comp, om.MIntArray(list(range(ninf))), om.MDoubleArray(w), True)
    return len(region)
