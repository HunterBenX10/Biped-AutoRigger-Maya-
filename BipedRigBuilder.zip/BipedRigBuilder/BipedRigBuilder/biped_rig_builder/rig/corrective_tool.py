"""Correctives tab: add / select / re-weight / remove corrective joints on a skinned
skeleton, any time (with or without the rig - the skeleton just has to be in its rest
pose). Each corrective = a ring of joints round a hinge (rig_rules.json > correctives),
both sides. The chest correctives (pec / lat / chest helpers) are listed too. Once added,
pick one and edit its joints in the tab (Move X / Y / Z, angles, skin) - live.
"""
import maya.cmds as cmds

from ..core import names, nodes
from . import correctives
from .skeleton import Skeleton


CHEST = "chest"
RING_LABEL = {"front": "Front", "back": "Back", "out": "Outer", "in": "Inner",
              "up": "Top", "down": "Bottom", "left": "Left", "right": "Right"}


def _chest_joints(left_only=False):
    from ..core import data
    return [j for h in data.rules()["helpers"]
            for j in ([h["name"]] if left_only else [h["name"], names.mirror(h["name"])])
            if cmds.objExists(j)]


def presets():
    """[(name, label, added?)] for every option in the rules + the chest helpers."""
    out = [(CHEST, "Chest corrective", bool(_chest_joints()))]
    for name, label, parts in correctives.groups():
        added = any(cmds.objExists(j) for d in parts for j in correctives.all_joints(d))
        out.append((name, label, added))
    return out


def joints_of(names_):
    names_ = correctives.expand(names_)
    js = [j for d in correctives.defs() if d["name"] in names_
          for j in correctives.all_joints(d) if cmds.objExists(j)]
    return js + (_chest_joints() if CHEST in names_ else [])


# ---------------------------------------------------------------- editing (the tab)
def edit_items(name):
    """What the editor shows for one corrective: [(joint, title, [(attr, label, kind)])]
    for the left (or centre) joints - kind 'move' / 'angle' / 'skin'. Empty if not added
    or its drivers aren't built yet."""
    def have(j, attrs):
        return all(cmds.attributeQuery(a, node=j, exists=True) for a, _, _ in attrs)
    items = []
    if name == CHEST:
        from .deform import HELPER_KEYS
        for j in _chest_joints(left_only=True):
            title = names.base(j).replace("_hlp", "").capitalize()
            for key, label in HELPER_KEYS:
                attrs = [("{}_{}".format(key.capitalize(), c),
                          "Move {} ({})".format(c, w), "move")
                         for c, w in zip("XYZ", ("out", "up", "forward"))]
                if have(j, attrs):
                    items.append((j, "{} - {}".format(title, label), attrs))
        return items
    parts = [x for x in correctives.defs() if x["name"] in correctives.expand([name])]
    for d in parts:
        items += _part_items(d, have, len(parts) > 1)
    return items


def _part_items(d, have, prefix):
    items = []
    s = correctives.sides(d)[0]
    words = correctives.axis_words(d, s, Skeleton.height())
    for r in d["ring"]:
        j = correctives.joint_name(d, r, s)
        if not cmds.objExists(j):
            continue
        attrs = [("Move_" + c, "Move {} ({})".format(c, w), "move")
                 for c, w in zip("XYZ", words)]
        if have(j, attrs):
            title = RING_LABEL.get(r, r.capitalize())
            if prefix:
                title = "{} - {}".format(d.get("label", names.base(d["name"])), title)
            items.append((j, title, attrs))
    return items


def move_unit(j):
    """Scene units per editor step: 20% of the flesh thickness at the joint (stored on it
    by the drivers); chest helpers 0.4% of the character's height."""
    if cmds.attributeQuery("Move_Unit", node=j, exists=True):
        u = cmds.getAttr(j + ".Move_Unit")
        if u > 1e-6:
            return u
    return max(Skeleton.height(), 1.0) * 0.004


def get_value(j, attr):
    return cmds.getAttr(j + "." + attr)


def set_value(j, attr, value, both=True):
    """Set on the joint and (both) its other side. The move axes are mirror-symmetric,
    so the same number means the same thing on the right."""
    targets = [j]
    if both and names.side(j) == "l" and cmds.objExists(names.mirror(j)):
        targets.append(names.mirror(j))
    for t in targets:
        if cmds.attributeQuery(attr, node=t, exists=True):
            cmds.setAttr(t + "." + attr, value)


def _clean_legacy(chosen, scs):
    """Older builds' two knee presets (pit / cap): removed when the knee is redone."""
    old = [j for n in chosen for j in correctives.legacy_joints(n)]
    if not old:
        return
    for sc in scs:
        have = set(cmds.skinCluster(sc, q=True, influence=True) or [])
        present = [j for j in old if j in have]
        if present:
            cmds.skinCluster(sc, edit=True, removeInfluence=present)
    nodes.delete(*old)
    print("Replaced older correctives: " + ", ".join(old))


def _at_rest():
    """True if every bind joint sits where Build Skeleton put it (rig at rest / no rig)."""
    import ast
    text = nodes.get_string("root", Skeleton.REST_ATTR)
    if not text:
        return True
    for j, (t, r) in ast.literal_eval(text).items():
        if not cmds.objExists(j) or "twist" in j or j.endswith("_hlp"):
            continue
        cur = cmds.getAttr(j + ".rotate")[0]
        if any(abs(a - b) > 0.01 for a, b in zip(cur, r)):
            return False
    return True


def _need_rest():
    if not Skeleton.exists():
        cmds.error("Build the skeleton (and skin it) first.")
    if not _at_rest():
        cmds.error("Put the rig back in its rest pose first (zero the ctrls / go to the "
                   "bind pose) - correctives are measured and bound at rest.")


def _rebuild_drivers():
    from .deform import Deformation
    d = Deformation()
    d.remove_drivers()
    d.ensure_drivers()


def add(chosen):
    """Create the chosen correctives (both sides), drive them and give them skin."""
    chosen = correctives.expand(chosen)
    from .deform import Deformation
    from .guides import Guides
    from . import skin
    if CHEST in chosen:
        _need_rest()
        if not _chest_joints():
            Deformation().add_chest_helpers()
        chosen = [c for c in chosen if c != CHEST]
        if not chosen:
            show_weights([CHEST])
            return []
    _need_rest()
    h = Skeleton.height()
    with nodes.undo_chunk():
        from .deform import Deformation as D
        D().remove_drivers()
        _clean_legacy(chosen, Deformation.skins())
        meshes = Guides.meshes()
        made = correctives.create(h, meshes.rays() if meshes else None, only=set(chosen))
        Skeleton.store_rest()
        _rebuild_drivers()
        for sc in Deformation.skins():
            shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
            if not shape:
                continue
            have = set(cmds.skinCluster(sc, q=True, influence=True) or [])
            for j in made:
                if j not in have:
                    skin.label_joint(j)
                    cmds.skinCluster(sc, edit=True, addInfluence=j, weight=0.0,
                                     lockWeights=False)
            correctives.apply_weights(sc, shape, h, only=set(chosen))
    print("Correctives added: {} joints - their weights are showing (Paint Skin Weights). "
          "Edit the moves in the Correctives tab.".format(len(made)))
    show_weights(chosen)
    return made


def show_weights(chosen):
    """Paint Skin Weights on the first joint of the picked corrective: where it acts shows
    white on the mesh. (Escape / the Select tool to leave.)"""
    import maya.mel as mel
    from .deform import Deformation
    js = [j for j in joints_of(chosen) if names.side(j) in ("l", "c")] or joints_of(chosen)
    skins = Deformation.skins()
    if not js or not skins:
        cmds.warning("Add it first (and skin the mesh).")
        return
    shape = (cmds.skinCluster(skins[0], q=True, geometry=True) or [None])[0]
    mesh = (cmds.listRelatives(shape, parent=True, fullPath=True) or [shape])[0]
    cmds.select(mesh, replace=True)
    try:
        mel.eval("ArtPaintSkinWeightsTool;")
        mel.eval('artSkinSelectInfluence("artAttrSkinPaintCtx", "{}");'.format(js[0]))
        print("Showing the weights of {} (white = where it acts). Its other joints: "
              "pick them in the Paint Skin Weights influence list.".format(js[0]))
    except RuntimeError as e:
        cmds.warning("Couldn't open Paint Skin Weights ({}) - select {} and use Skin > "
                     "Paint Skin Weights.".format(e, js[0]))


def reweight(chosen):
    """Give the chosen correctives a fresh skin patch (after a re-skin or a big tweak)."""
    chosen = correctives.expand(chosen)
    from .deform import Deformation
    _need_rest()
    if CHEST in chosen:
        from . import skin
        for sc in Deformation.skins():
            shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
            if shape:
                skin.helper_patch(sc, shape)
                skin.limit_influences(sc, shape)
    chosen = [c for c in chosen if c != CHEST]
    js = joints_of(chosen)
    with nodes.undo_chunk():
        for sc in Deformation.skins():
            shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
            have = set(cmds.skinCluster(sc, q=True, influence=True) or [])
            present = [j for j in js if j in have]
            if not shape or not present:
                continue
            cmds.skinCluster(sc, edit=True, removeInfluence=present)
            for j in present:
                cmds.skinCluster(sc, edit=True, addInfluence=j, weight=0.0,
                                 lockWeights=False)
            correctives.apply_weights(sc, shape, Skeleton.height(), only=set(chosen))
    print("Re-weighted: " + ", ".join(chosen))


def remove(chosen):
    """Delete the chosen correctives: their skin goes back to the joints around them."""
    chosen = correctives.expand(chosen)
    from .deform import Deformation
    if CHEST in chosen:
        cmds.warning("The chest correctives are part of the skeleton (Build Skeleton's "
                     "'Chest volume helpers'); set their moves to 0 to turn them off.")
        chosen = [c for c in chosen if c != CHEST]
    js = joints_of(chosen) + [j for n in chosen for j in correctives.legacy_joints(n)]
    if not js:
        return
    with nodes.undo_chunk():
        for sc in Deformation.skins():
            have = set(cmds.skinCluster(sc, q=True, influence=True) or [])
            present = [j for j in js if j in have]
            if present:
                cmds.skinCluster(sc, edit=True, removeInfluence=present)
        from .deform import Deformation as D
        D().remove_drivers()                    # drops every skeleton driver...
        nodes.delete(*js)
        Skeleton.store_rest()
        D().ensure_drivers()                    # ...and rebuilds the ones still needed
    print("Removed: " + ", ".join(chosen))


def reset(chosen):
    """Back to the tool's defaults: the settings are deleted from the joints and the
    drivers rebuilt (they're re-made from rig_rules.json), then a fresh skin patch."""
    chosen = correctives.expand(chosen)
    from .deform import Deformation, HELPER_KEYS
    _need_rest()
    with nodes.undo_chunk():
        Deformation().remove_drivers()
        for name in chosen:
            for j in joints_of([name]):
                attrs = [a for a, _ in correctives.LIVE] if name != CHEST else \
                    ["{}_{}".format(k.capitalize(), c) for k, _ in HELPER_KEYS for c in "XYZ"]
                for a in attrs:
                    if cmds.attributeQuery(a, node=j, exists=True):
                        cmds.deleteAttr(j + "." + a)
        Deformation().ensure_drivers()
    reweight(chosen)
    print("Reset to defaults: " + ", ".join(chosen))


def select(chosen):
    js = joints_of(chosen)
    if js:
        cmds.select(js, replace=True)
        print("Selected {} corrective joints.".format(len(js)))
    else:
        cmds.warning("Add them first.")


def mirror_settings(chosen):
    """Copy every edited setting from the left joints to the right ones."""
    count = 0
    for name in chosen:
        for j, _, attrs in edit_items(name):
            r = names.mirror(j)
            if names.side(j) != "l" or not cmds.objExists(r):
                continue
            for attr, _, _ in attrs:
                if cmds.attributeQuery(attr, node=r, exists=True):
                    cmds.setAttr(r + "." + attr, cmds.getAttr(j + "." + attr))
                    count += 1
    print("Mirrored {} settings left -> right.".format(count))

