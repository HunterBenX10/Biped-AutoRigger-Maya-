"""Stage 1 - placeable guides that show the joint orientation live."""
import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes, template
from ..core.mesh import MeshSet


def guide(name):
    return name + config.GUIDE_SUFFIX


def orient(name):
    return name + config.ORIENT_SUFFIX


def _loc(name):
    return cmds.listRelatives(guide(name), shapes=True, type="locator")[0] + ".worldPosition[0]"


class Guides(object):
    def __init__(self):
        self.tpl = template.get()

    # ---------------------------------------------------------------- state
    @staticmethod
    def exist():
        return cmds.objExists(config.GUIDE_GRP)

    @classmethod
    def meshes(cls):
        return MeshSet.from_string(nodes.get_string(config.GUIDE_GRP, "mesh"))

    def show(self, on=True):
        if self.exist():
            cmds.setAttr(config.GUIDE_GRP + ".visibility", on)
            self.meshes().see_through(on)

    def toggle(self):
        if self.exist():
            self.show(not cmds.getAttr(config.GUIDE_GRP + ".visibility"))

    _MOVE_MODE = []                    # the Move tool's own axis mode, to put back

    @classmethod
    def align_move_tool(cls, selection):
        """One guide selected: the Move tool's axes line up with that guide's JOINT axes
        (Y down the bone, Z forward) - drag along the bone, across it, or sideways, even
        on a finger pointing anywhere. Anything else selected: the Move tool goes back
        to the mode you had."""
        try:
            cur = cmds.manipMoveContext("Move", q=True, mode=True)
        except RuntimeError:
            return
        g = None
        if len(selection) == 1 and selection[0].endswith(config.GUIDE_SUFFIX) and \
                cmds.objExists(selection[0].replace(config.GUIDE_SUFFIX,
                                                    config.ORIENT_SUFFIX)):
            g = selection[0]
        if g is None:
            if cls._MOVE_MODE:
                cmds.manipMoveContext("Move", e=True, mode=cls._MOVE_MODE.pop())
            return
        o = g.replace(config.GUIDE_SUFFIX, config.ORIENT_SUFFIX)
        if not cls._MOVE_MODE:
            cls._MOVE_MODE.append(cur if cur != 6 else 2)
        try:                                       # Maya 2019+: orient to an object
            cmds.manipMoveContext("Move", e=True, mode=6, orientObject=o)
        except (RuntimeError, TypeError):
            import math
            r = cmds.xform(o, q=True, ws=True, rotation=True)
            cmds.manipMoveContext("Move", e=True, mode=6,
                                  orientAxes=[math.radians(a) for a in r])

    @staticmethod
    def move(name, p):
        """Move one guide in world space; guides below it stay where they are."""
        g = guide(name)
        kids = cmds.listRelatives(g, children=True, type="transform", fullPath=True) or []
        kids = [k for k in kids if cmds.listRelatives(k, shapes=True, type="locator")]
        keep = [(k, cmds.xform(k, q=True, ws=True, translation=True)) for k in kids]
        locked = cmds.getAttr(g + ".translateX", lock=True)
        cmds.setAttr(g + ".translateX", lock=False)
        cmds.xform(g, ws=True, translation=(p[0], p[1], p[2]))
        cmds.setAttr(g + ".translateX", lock=locked)
        for k, kp in keep:
            cmds.xform(k, ws=True, translation=kp)

    def positions(self):
        """World position per joint (centre joints forced onto X = 0)."""
        out = {}
        for n in self.tpl.names:
            p = mathx.pos(guide(n))
            if names.side(n) == "c":
                p.x = 0.0
            out[n] = p
        return out

    def orientations(self):
        """World axes (x, y, z) per joint, read from the live orientation nodes."""
        return {n: [mathx.axis(mathx.world(orient(n)), i) for i in range(3)]
                for n in self.tpl.names}

    # ---------------------------------------------------------------- create
    def create(self, meshes=None, follow=True, tpose=False):
        if self.exist():
            self.show(True)
            self.refresh_orient()
            cmds.warning("Guides already exist - shown them and refreshed their orientation "
                         "setup (positions kept). Delete Guides to start over.")
            return
        meshes = meshes or MeshSet()
        if meshes and meshes.facing() < 0:
            cmds.warning(config.FACING_MSG)
        scale = meshes.height() / self.tpl.height if meshes else 1.0
        with nodes.undo_chunk():
            grp = cmds.group(empty=True, name=config.GUIDE_GRP)
            nodes.add_string(grp, "mesh", meshes.to_string())
            lines = cmds.group(empty=True, name=config.GUIDE_GRP + "_lines", parent=grp)
            cmds.setAttr(lines + ".inheritsTransform", 0)
            start = self._tpose() if tpose else self.tpl.position
            for name, parent, _ in self.tpl.joints:
                self._make(name, grp, scale, start[name])
                if parent:
                    self._line(name, parent, lines)
            self._orient_rules()
            self.set_follow(follow)
            meshes.see_through(True)
            cmds.select(clear=True)
        print("Guides created (scale {:.3f}). Fit to Mesh, tweak, then Build.".format(scale))

    def _make(self, name, grp, scale, p):
        snap = self.tpl.snap.get(name)
        size = (1.0 if self.tpl.is_finger(name) else 3.5) * scale
        color = config.SIDE_COLOR[names.side(name)]
        g = cmds.spaceLocator(name=guide(name))[0]
        lshp = cmds.listRelatives(g, shapes=True)[0]
        # the locator carries the position (lines read it); it stays visible but tiny
        # (a dot in the middle of the marker) - a guide with no visible shape of its own
        # makes Frame Selected (F) zoom out to the whole world
        cmds.setAttr(lshp + ".localScale", *[size * 0.06] * 3)
        nodes.style(lshp, color, on_top=True)
        if snap:
            cmds.setAttr(lshp + ".visibility", 0)
        nodes.lock(g, nodes.TRS[6:])                # rotate is free: swing whole limbs
        o = cmds.createNode("transform", name=orient(name), parent=g)
        if not snap:                               # a joint-like marker in the joint's axes
            self._marker(o, size, color)
        g = cmds.parent(g, guide(snap) if snap else grp)[0]
        if snap:
            cmds.setAttr(g + ".translate", 0, 0, 0)
            cmds.setAttr(g + ".translate", lock=True)
        else:
            x = 0.0 if names.side(name) == "c" else p[0] * scale
            cmds.xform(g, ws=True, translation=(x, p[1] * scale, p[2] * scale))
            if names.side(name) == "c":
                cmds.setAttr(g + ".translateX", lock=True)

    @staticmethod
    def _marker(o, size, color):
        """What a guide looks like: a ball (one ring facing the camera-ish plane + one
        round the bone) in the side colour, an arrow down the bone (Y, green - where the
        child goes) and a short tick forward (Z, blue - the joint's front). Everything is
        drawn in the joint's own axes, so you see exactly how the joint will sit. Click
        any part: the guide is selected (and the Move tool lines up with these axes)."""
        r = size * 0.32
        nodes.add_circle(o, (0, 1, 0), r, color=color, width=2, on_top=True)  # round bone
        nodes.add_circle(o, (0, 0, 1), r, color=color, width=1, on_top=True)
        ln = size * 0.95
        head = size * 0.18
        nodes.add_curve(o, [(0, r, 0), (0, ln, 0), (head * 0.6, ln - head, 0), (0, ln, 0),
                            (-head * 0.6, ln - head, 0)], color=config.AXIS_COLOR[1],
                        width=2, on_top=True)                                  # Y arrow
        nodes.add_curve(o, [(0, 0, r), (0, 0, r + size * 0.35)],
                        color=config.AXIS_COLOR[2], width=2, on_top=True)     # Z tick

    def _tpose(self):
        """Template positions with the arm swung up to horizontal (+X) about the shoulder."""
        pos = {n: om.MVector(*p) for n, p in self.tpl.position.items()}
        sh = pos["upperarm_l"]
        q = om.MQuaternion((pos["hand_l"] - sh).normal(), om.MVector(1, 0, 0))
        for n in self.tpl.names:
            if "upperarm_l" in list(self.tpl.ancestors(n)):
                pos[n] = sh + (pos[n] - sh).rotateBy(q)
        return {n: (p.x, p.y, p.z) for n, p in pos.items()}

    @staticmethod
    def _line(name, parent, lines):
        crv = cmds.parent(cmds.curve(degree=1, point=[(0, 0, 0)] * 2, name=name + "_line"),
                          lines)[0]
        cs = cmds.listRelatives(crv, shapes=True)[0]
        cmds.connectAttr(_loc(parent), cs + ".controlPoints[0]")
        cmds.connectAttr(_loc(name), cs + ".controlPoints[1]")
        nodes.style(cs, reference=True, on_top=True)

    # ---------------------------------------------------------------- orientation
    @staticmethod
    def _util(node_type, tag):
        return cmds.createNode(node_type, name="{}_{}".format(config.GUIDE_UTIL, tag))

    # ---------------------------------------------------------------- up guides
    @staticmethod
    def up_guides():
        """{chain root: joints} whose roll you set by hand with an 'up' guide (thumb)."""
        return data.skeleton().get("up_guides", {})

    @staticmethod
    def up_name(root):
        return root + "_up" + config.GUIDE_SUFFIX

    def _ensure_up_guides(self):
        """Thumb roll, solved automatically every time the orientation is refreshed
        (Create Guides / Build Skeleton):
          fingers   X = the hand's X (palm axis), Y down the finger -> rotate Z curls
          thumb     its curl must head for the base of the little finger (that's how a
                    thumb folds), so the thumb's bend direction D = toward pinky_01,
                    made perpendicular to the thumb bone, and X = -/+D with the SAME sign
                    convention the fingers get - so rotating Z curls the thumb exactly
                    like the fingers (all fingers + thumb selected, rotate Z = a fist).
        A small yellow up-guide shows the result (the thumb's Z points at it)."""
        for root, chain in self.up_guides().items():
            if not cmds.objExists(guide(root)) or len(chain) < 2:
                continue
            up = self.up_name(root)
            p0, p1 = mathx.pos(guide(root)), mathx.pos(guide(chain[1]))
            y = (p1 - p0).normal()
            hand, mid = guide("hand_l"), guide("middle_01_l")
            hy = (mathx.pos(mid) - mathx.pos(hand)).normal() if cmds.objExists(mid) \
                else om.MVector(0, -1, 0)
            hz = (om.MVector(0, 0, 1) - hy * hy.z).normal()
            hx = (hy ^ hz).normal()                              # the fingers' X
            target = guide("pinky_01_l") if cmds.objExists(guide("pinky_01_l")) else mid
            d = mathx.pos(target) - p0
            d = (d - y * (d * y)).normal()                       # thumb's curl direction
            # fingers: +Z swings the tip toward -X. Which side is the palm? The thumb
            # sits on the palm side, so its tip tells us.
            tip = mathx.pos(guide(chain[-1])) - mathx.pos(hand)
            s = 1.0 if tip * (-hx) >= 0 else -1.0
            x = (d * (-s)).normal()
            z = (x ^ y).normal()
            size = (p1 - p0).length()
            if not cmds.objExists(up):
                loc = cmds.spaceLocator(name=up)[0]
                shp = cmds.listRelatives(loc, shapes=True)[0]
                cmds.setAttr(shp + ".localScale", *[size * 0.25] * 3)
                nodes.style(shp, 17, on_top=True)                  # yellow
                cmds.parent(loc, guide(root))
                lines = config.GUIDE_GRP + "_lines"
                if cmds.objExists(lines):
                    crv = cmds.parent(cmds.curve(degree=1, point=[(0, 0, 0)] * 2,
                                                 name=up + "_line"), lines)[0]
                    cs = cmds.listRelatives(crv, shapes=True)[0]
                    cmds.connectAttr(_loc(root), cs + ".controlPoints[0]")
                    cmds.connectAttr(shp + ".worldPosition[0]", cs + ".controlPoints[1]")
                    nodes.style(cs, 17, on_top=True)
            for attr in ("tx", "ty", "tz"):
                cmds.setAttr("{}.{}".format(up, attr), lock=False)
            cmds.xform(up, ws=True, translation=tuple(p0 + z * size * 1.2))
            nodes.lock(up, nodes.TRS)                                # automatic now

    def _orient_rules(self):
        """Y aims down the bone, Z forward (fingers: the hand's Z); world-aligned joints
        stay put; end joints copy their parent. Arms/legs are made planar at Build."""
        self._ensure_up_guides()
        by_up = {j: self.up_name(root) for root, chain in self.up_guides().items()
                 for j in chain if cmds.objExists(self.up_name(root))}
        for name, parent, _ in self.tpl.joints:
            if name in self.tpl.world:             # stays world-aligned when guides rotate
                cmds.orientConstraint(config.GUIDE_GRP, orient(name))
                continue
            target = self.tpl.aim_target(name)
            if target is None:
                if parent:
                    cmds.orientConstraint(orient(parent), orient(name))
                continue
            src = self.tpl.up_source(name)
            if name in by_up:                      # roll set by hand: Z points at the up guide
                cmds.aimConstraint(guide(target), orient(name), aimVector=(0, 1, 0),
                                   upVector=(0, 0, 1), worldUpType="object",
                                   worldUpObject=by_up[name])
            elif src:
                # fingers AND thumb: the bend axis (X) follows the hand's X (palm
                # normal), Y down the finger. Using the hand's Z as up broke the thumb:
                # the thumb points along the hand's Z, so its roll was random per mesh
                cmds.aimConstraint(guide(target), orient(name), aimVector=(0, 1, 0),
                                   upVector=(1, 0, 0), worldUpVector=(1, 0, 0),
                                   worldUpType="objectrotation", worldUpObject=orient(src))
            else:
                cmds.aimConstraint(guide(target), orient(name), aimVector=(0, 1, 0),
                                   upVector=(0, 0, 1), worldUpVector=(0, 0, 1),
                                   worldUpType="vector")

    def refresh_orient(self):
        """Rebuild the orientation setup on existing guides (positions kept)."""
        with nodes.undo_chunk():
            for n in self.tpl.names:
                o = orient(n)
                if cmds.objExists(o):
                    cons = [c for c in cmds.listRelatives(o, children=True, fullPath=True) or []
                            if "Constraint" in cmds.nodeType(c)]
                    if cons:
                        cmds.delete(cons)
                    cmds.setAttr(o + ".rotate", 0, 0, 0)
            nodes.delete(config.GUIDE_UTIL + "_*")
            self._orient_rules()

    # ---------------------------------------------------------------- hierarchy
    def set_follow(self, on):
        """on: moving a guide drags everything below it. off: every guide moves alone."""
        if not self.exist():
            return
        for n in self.tpl.names:
            if n in self.tpl.snap or not cmds.objExists(guide(n)):
                continue
            p = self.tpl.parent.get(n)
            want = guide(p) if (on and p) else config.GUIDE_GRP
            if (cmds.listRelatives(guide(n), parent=True) or [None])[0] != want:
                cmds.parent(guide(n), want)

    # ---------------------------------------------------------------- fit to mesh
    def fit(self, fingers=True):
        meshes = self.meshes() or MeshSet.from_selection()
        if not self.exist() or not meshes:
            cmds.error("Create Guides with the mesh selected first.")
        table = data.guide_fit()
        bb = meshes.bbox()
        h, cz = bb[4] - bb[1], (bb[2] + bb[5]) * 0.5
        rays = meshes.rays()
        moved, skipped = [], []
        with nodes.undo_chunk():
            for n in self.tpl.names:
                g = guide(n)
                if n in self.tpl.snap or not cmds.objExists(g):
                    continue
                p = mathx.pos(g)
                if n in table["centre_depth"]:
                    new = self._fit_depth(rays, p, cz, h, table["centre_depth"][n])
                elif n in table["limbs"]:
                    a, b, reach = table["limbs"][n]
                    new = rays.centre_across(p, mathx.pos(guide(b)) - mathx.pos(guide(a)),
                                             reach * h)
                elif fingers and self.tpl.is_finger(n) and "meta" not in n \
                        and not n.endswith("_01_l"):     # knuckles sit in the palm
                    a, b = self.tpl.parent[n], self.tpl.first_child(n) or n
                    d = mathx.pos(guide(b)) - mathx.pos(guide(a))
                    new = rays.centre_across(p, d, table["finger_reach"] * h) \
                        if d.length() > 1e-4 else None
                else:
                    continue
                if new is None:
                    skipped.append(n)
                elif (new - p).length() > 1e-3:
                    locked = cmds.getAttr(g + ".translateX", lock=True)
                    cmds.setAttr(g + ".translateX", lock=False)
                    cmds.xform(g, ws=True, translation=(new.x, new.y, new.z))
                    cmds.setAttr(g + ".translateX", lock=locked)
                    moved.append("{:<14} {:.2f}".format(n, (new - p).length()))
        print("Fitted (name, distance moved):\n  " + ("\n  ".join(moved) or "none"))
        if skipped:
            print("Couldn't fit (guide is outside the mesh - drag it inside and Fit again): "
                  + ", ".join(skipped))

    @staticmethod
    def _fit_depth(rays, p, cz, h, fraction):
        """Centre joints: place front-to-back at the reference-rig fraction (0 back, 1 front)."""
        for start in (om.MVector(0, p.y, p.z), om.MVector(0, p.y, cz)):
            f = rays.hit(start, om.MVector(0, 0, 1), h)
            b = rays.hit(start, om.MVector(0, 0, -1), h)
            if f is not None and b is not None:
                back, front = start.z - b, start.z + f
                return om.MVector(0, p.y, back + (front - back) * fraction)
        return None

    # ---------------------------------------------------------------- delete
    def delete(self):
        if self.exist():
            self.meshes().see_through(False)
            cmds.delete(config.GUIDE_GRP)
        nodes.delete(config.GUIDE_UTIL + "_*")
        print("Guides deleted.")
