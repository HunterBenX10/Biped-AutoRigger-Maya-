"""Adaptive skin solve - pure numpy, no Maya (testable anywhere).

Nothing in here knows about arms, legs or heads, and nothing is stored: every width and
every boundary is measured on THIS mesh and THIS skeleton. The bind (heat map / voxel)
gives the starting weights; the solve keeps what agrees with the geometry and rebuilds the
rest:

  1. OWNERSHIP     a vertex belongs to the bone it sits nearest to (bone = segment from a
                   joint to its child). Another bone may keep weight on it only if it is
                   close in the hierarchy (<= 2 steps) and nearly as close in space, and
                   on the vertex's side.
  2. THICKNESS     each bone's flesh radius = median distance of the vertices it owns
                   around its middle.
  3. JOINT BLENDS  across every joint, the parent's and the child's share are re-split by
                   the vertex's signed distance to the joint's bisecting plane, over a
                   width = the flesh radius at that joint (capped at 45% of the shorter
                   bone). Elbows, knees, knuckles, hips, neck: same rule, own size.
                   A child much thicker than its parent's tube (a head on a neck) takes
                   everything that sticks out of that tube past the plane (jaw, skull).
  4. SMOOTHING     two neighbour-averaging passes over blend vertices only, then the
                   ownership limits are re-applied.
  5. TWIST SPREAD  a bone's share goes to its twist joints by where the vertex sits along
                   the bone (linear between neighbours), so twist changes smoothly.
  6. LIMIT         max influences, prune, normalise.
All of it is vectorised: one bind's worth of weights is solved in well under a second for
a 25k vertex body (N x bones arrays, no per-vertex Python loops).
"""
import numpy as np


def smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def seg_distance(V, a, b):
    """Distance from every point to the segment a-b, and the clamped parameter t."""
    ab = b - a
    l2 = float(ab @ ab)
    if l2 < 1e-12:
        return np.linalg.norm(V - a, axis=1), np.zeros(len(V))
    t = np.clip((V - a) @ ab / l2, 0.0, 1.0)
    return np.linalg.norm(V - (a + t[:, None] * ab), axis=1), t


class Bone(object):
    """One family: a skeleton joint + its twist joints (they share one bone).

    pos        the joint's position          parent  family index or -1
    segs       [(a, b)] segments it owns (to each child; leaves: a tip)
    side       'l' / 'r' / 'c'
    members    [(column, fraction along the main segment)] weight receivers
    donors     columns whose weight belongs to this family but never receive any
               (an excluded bone, the root, temporary tip joints)
    """

    def __init__(self, pos, parent, segs, side, members, donors=()):
        self.pos = np.asarray(pos, float)
        self.parent = parent
        self.segs = [(np.asarray(a, float), np.asarray(b, float)) for a, b in segs]
        self.side = side
        self.members = list(members)
        self.donors = list(donors)


def neighbour_lists(counts, connects, n):
    """Edges from polygon data (MFnMesh.getVertices) -> (i, j) arrays, both directions."""
    counts = np.asarray(counts, np.int64)
    connects = np.asarray(connects, np.int64)
    start = np.repeat(np.cumsum(counts) - counts, counts)
    pos = np.arange(len(connects)) - start
    nxt = start + (pos + 1) % np.repeat(counts, counts)
    i, j = connects, connects[nxt]
    i, j = np.concatenate([i, j]), np.concatenate([j, i])
    key = np.unique(i * n + j)
    return key // n, key % n


def surface_owner(V, edges, seeds, n_labels):
    """Multi-source Dijkstra over the mesh edges: every vertex gets the label of the seed
    it reaches first ALONG THE SURFACE (not through the air). seeds: (N,) label or -1.
    Returns (label (N,), distance (N,)); unreached vertices keep -1 / inf."""
    import heapq
    N = len(V)
    i, k = edges
    order = np.argsort(i, kind="stable")
    i, k = i[order], k[order]
    start = np.searchsorted(i, np.arange(N + 1))
    length = np.linalg.norm(V[i] - V[k], axis=1)
    k_l, len_l, start_l = k.tolist(), length.tolist(), start.tolist()
    label = [-1] * N
    dist = [float("inf")] * N
    heap = []
    for v in np.where(seeds >= 0)[0].tolist():
        dist[v] = 0.0
        label[v] = int(seeds[v])
        heap.append((0.0, v))
    heapq.heapify(heap)
    while heap:
        d, v = heapq.heappop(heap)
        if d > dist[v]:
            continue
        lv = label[v]
        for e in range(start_l[v], start_l[v + 1]):
            u = k_l[e]
            nd = d + len_l[e]
            if nd < dist[u]:
                dist[u] = nd
                label[u] = lv
                heapq.heappush(heap, (nd, u))
    return np.array(label), np.array(dist)


def _steps(bones):
    F = len(bones)
    adj = [set() for _ in range(F)]
    for f, b in enumerate(bones):
        if b.parent >= 0:
            adj[f].add(b.parent)
            adj[b.parent].add(f)
    out = np.full((F, F), 99, np.int16)
    for s in range(F):
        dist, todo = {s: 0}, [s]
        while todo:
            x = todo.pop(0)
            for y in adj[x]:
                if y not in dist:
                    dist[y] = dist[x] + 1
                    todo.append(y)
        for y, d in dist.items():
            out[s, y] = d
    return out


SEAM_REACH = 0.3         # sibling seams fade to the parent over this x the limb radius


def solve(V, W, bones, edges=None, h=None, max_inf=4, prune=0.01, exempt=(),
          near=1.5, far=2.6, max_steps=2, return_allow=False):
    """V (N, 3) rest points, W (N, M) bind weights, bones [Bone], edges (i, j) or None,
    h = character height, exempt = columns left exactly as they are (corrective /
    helper joints). Returns the solved (N, M) weights."""
    V = np.asarray(V, float)
    W = np.asarray(W, float)
    N, M = W.shape
    F = len(bones)
    h = h or float(V[:, 1].max() - V[:, 1].min())
    band = h * 0.005
    exempt = np.zeros(M, bool) if not len(exempt) else np.isin(np.arange(M), exempt)

    # ---- family weights (N, F) from the columns
    col_fam = np.full(M, -1)
    for f, b in enumerate(bones):
        for c, _ in b.members:
            col_fam[c] = f
        for c in b.donors:
            col_fam[c] = f
    keep_cols = exempt | (col_fam < 0)
    Wf = np.zeros((N, F))
    for f in range(F):
        cols = np.where(col_fam == f)[0]
        if len(cols):
            Wf[:, f] = W[:, cols].sum(1)
    fixed = W * keep_cols                                # untouched columns
    free = 1.0 - fixed.sum(1)                            # what the solve shares out

    # ---- 1. ownership
    D = np.full((N, F), np.inf)
    T = np.zeros((N, F))
    for f, b in enumerate(bones):
        for a, c in b.segs:
            d, t = seg_distance(V, a, c)
            better = d < D[:, f]
            D[better, f] = d[better]
            T[better, f] = t[better]
    vside = np.where(V[:, 0] > band, "l", np.where(V[:, 0] < -band, "r", "c"))
    fside = np.array([b.side for b in bones])
    wrong = ((vside[:, None] == "l") & (fside[None, :] == "r")) | \
            ((vside[:, None] == "r") & (fside[None, :] == "l"))
    Dok = np.where(wrong, np.inf, D)
    owner = np.argmin(Dok, axis=1)
    if edges is not None:
        # OWNER BY SURFACE DISTANCE. Nearest-bone-through-the-air fails where body parts
        # sit close without being connected (A-pose: the upper arm hangs right next to the
        # ribs, so the serratus went to the arm and stretched up with it). Seeds = the
        # vertices the bind AND the geometry agree on (nearest bone, >= 60% bind weight,
        # close to the bone); every other vertex takes the bone whose seeds it reaches
        # first walking over the mesh - round the armpit, not through it.
        seeds = np.full(N, -1)
        for f in range(F):
            cand = (owner == f) & (Wf[:, f] >= 0.6)
            if cand.sum() < 3:
                cand = owner == f
            if not cand.any():
                continue
            lim = 1.25 * float(np.median(D[cand, f]))
            seeds[cand & (D[:, f] <= lim)] = f
        lab, _ = surface_owner(V, edges, seeds, F)
        ok = lab >= 0
        ok[ok] &= ~wrong[np.where(ok)[0], lab[ok]]
        owner = np.where(ok, lab, owner)
    dmin = Dok[np.arange(N), owner]
    lo = near * dmin + 0.01 * h
    hi = far * dmin + 0.02 * h
    allow = 1.0 - smoothstep((Dok - lo[:, None]) / (hi - lo)[:, None])
    steps = _steps(bones)
    st = steps[owner]
    # two steps away (grandparent, sibling): only where its bone is about as close as
    # the owner's - a sliver at shared corners (armpit, crotch), never across a limb
    lo2 = 1.1 * dmin + 0.005 * h
    hi2 = 1.5 * dmin + 0.01 * h
    allow2 = 1.0 - smoothstep((Dok - lo2[:, None]) / (hi2 - lo2)[:, None])
    rule = allow.copy()
    rule = np.where(st >= 2, np.minimum(rule, allow2), rule)
    rule[st > max_steps] = 0.0
    # sibling branches of one hub never share (spine vs leg off the pelvis, finger vs
    # finger off the hand): a leg can't pull the waist, a finger can't pull its neighbour
    par = np.array([b.parent for b in bones])
    sib = (par[:, None] == par[None, :]) & (par[:, None] >= 0)
    np.fill_diagonal(sib, False)
    rule[sib[owner]] = 0.0
    allow = rule
    allow[wrong] = 0.0
    if edges is not None:
        # a bone may only share a vertex that lies within reach of its OWN region along
        # the surface (its owned area grown by about one joint radius of mesh rings):
        # bones meet at their borders, never across a gap (arm vs ribs, finger vs finger)
        i, k = edges
        elen = float(np.median(np.linalg.norm(V[i] - V[k], axis=1))) or 1.0
        r_typ = float(np.median(dmin[np.isfinite(dmin)])) if np.isfinite(dmin).any() else elen
        rings = int(np.clip(round(0.8 * r_typ / elen), 2, 12))
        near_f = np.zeros((N, F), bool)
        near_f[np.arange(N), owner] = True
        for _ in range(rings):
            acc = np.zeros((N, F), np.int32)
            np.add.at(acc, i, near_f[k].astype(np.int32))
            near_f |= acc > 0
        allow[~near_f] = 0.0
    allow[np.arange(N), owner] = 1.0

    def limit(x):
        x = x * allow
        s = x.sum(1)
        empty = s < 1e-9
        x[empty, owner[empty]] = 1.0
        return x / x.sum(1, keepdims=True)

    Wf = limit(Wf)

    # ---- 2. thickness: flesh radius of each bone, measured around its middle
    R = np.zeros(F)
    for f in range(F):
        m = (owner == f) & (T[:, f] > 0.2) & (T[:, f] < 0.8)
        if m.sum() < 8:
            m = owner == f
        R[f] = float(np.median(D[m, f])) if m.any() else 0.02 * h
    R = np.maximum(R, 1e-4 * h)

    # ---- 3. joint blends (parents first)
    kids = [[] for _ in range(F)]
    for f, b in enumerate(bones):
        if b.parent >= 0:
            kids[b.parent].append(f)
    order, todo = [], [f for f, b in enumerate(bones) if b.parent < 0]
    while todo:
        f = todo.pop(0)
        order.append(f)
        todo += kids[f]
    blend = np.zeros(N, bool)
    for j in order:
        p = bones[j].parent
        if p < 0:
            continue
        J, P = bones[j], bones[p]
        # the parent's segment that ends at this joint
        pa, pb = min(P.segs, key=lambda s: float(np.linalg.norm(s[1] - J.pos)))
        dp = pb - pa
        lp = float(np.linalg.norm(dp))
        dj = np.mean([(c - a) / max(np.linalg.norm(c - a), 1e-9) for a, c in J.segs], 0)
        lj = float(np.mean([np.linalg.norm(c - a) for a, c in J.segs]))
        if lp < 1e-6 or len(kids[p]) > 1:
            # a hub (pelvis -> both legs + spine, chest -> neck + clavicles): the parent's
            # direction says nothing about this branch - the plane sits square to the
            # child bone (a hip line level with the leg, not tipped up into the waist)
            n = dj
        else:
            n = dp / lp + dj / max(np.linalg.norm(dj), 1e-9)
        nl = np.linalg.norm(n)
        if nl < 1e-9:
            continue
        n = n / nl
        sel = (owner == p) | (owner == j)
        if not sel.any():
            continue
        s = (V[sel] - J.pos) @ n
        r = 0.5 * (R[p] + R[j])
        lengths = [x for x in (lp, lj) if x > 1e-6]
        w = min(r, 0.45 * min(lengths)) if lengths else r
        t = smoothstep((s + w) / (2 * w))
        # a much thicker child (head on a neck): what sticks out of the parent's tube
        # past the plane is the child's (jaw, skull)
        if len(kids[p]) == 1 and lp > 1e-6 and R[j] > 1.5 * R[p]:
            d_line, _ = seg_distance(V[sel], pa, pb)
            t = np.where((d_line > 1.35 * R[p]) & (s > -w), 1.0, t)
        rows = np.where(sel)[0]
        pool = Wf[rows, p] + Wf[rows, j]
        Wf[rows, p] = pool * (1 - t)
        Wf[rows, j] = pool * t
        blend[rows[(t > 0.01) & (t < 0.99)]] = True

    # ---- 3b. seams between sibling branches (the crotch between the legs, the webbing
    # between fingers, neck vs clavicle): siblings never share, so their meeting line was
    # a hard 100% / 100% seam that tore open when one side moved (lift a leg: half the
    # crotch went with it). Near the seam the flesh belongs to their PARENT (pelvis, hand,
    # chest): full at the seam, fading out over SEAM_REACH x the limb radius (wider and the
    # pelvis starts holding the inner thighs).
    if edges is not None:
        i, k = edges
        elen = float(np.median(np.linalg.norm(V[i] - V[k], axis=1))) or 1.0
        for p in range(F):
            ch = kids[p]
            if len(ch) < 2 or not bones[p].members:
                continue
            on_ch = np.isin(owner, ch)
            m = (owner[i] != owner[k]) & on_ch[i] & on_ch[k]
            if not m.any():
                continue
            rings = int(np.clip(round(SEAM_REACH * min(R[c] for c in ch) / elen), 1, 10))
            dist = np.full(N, rings + 1)
            front = np.zeros(N, bool)
            front[i[m]] = True
            dist[front] = 0
            for r in range(1, rings + 1):
                grow = np.zeros(N, bool)
                grow[i[front[k]]] = True
                front = grow & (dist > r)
                dist[front] = r
            sel = on_ch & (dist <= rings)
            if not sel.any():
                continue
            fade = 1.0 - smoothstep(dist[sel] / float(rings + 1))
            rows = np.where(sel)[0]
            for c in ch:
                move = Wf[rows, c] * fade
                Wf[rows, c] -= move
                Wf[rows, p] += move
            allow[rows, p] = 1.0                    # the parent may hold them
            blend[rows] = True

    # ---- 4. smoothing over blend vertices only (+ rogue vertices: a vertex whose
    # weights disagree with all of its neighbours' by more than half - a lone vertex that
    # would spike out in a pose - takes their average)
    if edges is not None:
        i, k = edges
        deg = np.bincount(i, minlength=N).astype(float)
        for _ in range(2):
            acc = np.zeros_like(Wf)
            np.add.at(acc, i, Wf[k])
            avg = acc / np.maximum(deg, 1)[:, None]
            rogue = (0.5 * np.abs(Wf - avg).sum(1) > 0.5) & (deg > 0)
            if not rogue.any():
                break
            Wf[rogue] = avg[rogue]
    if edges is not None:
        # ownership borders that no joint blend covers (arm vs ribs at the armpit fold,
        # bones two steps apart) are softened too: the border and 2 rings either side
        i, k = edges
        zone = np.zeros(N, bool)
        zone[i[owner[i] != owner[k]]] = True
        for _ in range(2):
            grow = np.zeros(N, bool)
            grow[i[zone[k]]] = True
            zone |= grow
        blend |= zone
    if edges is not None and blend.any():
        i, k = edges
        deg = np.bincount(i, minlength=N).astype(float)
        for _ in range(3):
            acc = np.zeros_like(Wf)
            np.add.at(acc, i, Wf[k])
            avg = acc / np.maximum(deg, 1)[:, None]
            Wf[blend] = 0.5 * Wf[blend] + 0.5 * avg[blend]
        Wf = limit(Wf)

    # ---- 5. family -> columns (twist spread along the bone)
    out = fixed.copy()
    for f, b in enumerate(bones):
        if not b.members:
            continue
        share = Wf[:, f] * free
        if len(b.members) == 1:
            out[:, b.members[0][0]] += share
            continue
        mem = sorted(b.members, key=lambda m: m[1])
        fr = np.array([m[1] for m in mem])
        a, c = b.segs[0]
        ac = c - a
        u = np.clip((V - a) @ ac / max(float(ac @ ac), 1e-12), fr[0], fr[-1])
        for k in range(len(mem) - 1):
            span = max(fr[k + 1] - fr[k], 1e-9)
            m = (u >= fr[k]) & (u <= fr[k + 1])
            if k:
                m &= u > fr[k]
            tt = (u[m] - fr[k]) / span
            out[m, mem[k][0]] += share[m] * (1 - tt)
            out[m, mem[k + 1][0]] += share[m] * tt
    # family weight with no receiver (shouldn't happen) goes back to the bind's columns
    lost = 1.0 - out.sum(1)
    bad = lost > 1e-6
    if bad.any():
        out[bad] += W[bad] * (lost[bad] / np.maximum(W[bad].sum(1), 1e-9))[:, None]

    # ---- 6. limit influences, prune, normalise
    if max_inf and M > max_inf:
        idx = np.argsort(-out, axis=1)[:, max_inf:]
        np.put_along_axis(out, idx, 0.0, axis=1)
    out[out < prune] = 0.0
    s = out.sum(1, keepdims=True)
    zero = s[:, 0] < 1e-9
    if zero.any():
        out[zero] = W[zero]
        s = out.sum(1, keepdims=True)
    out = out / s
    if return_allow:
        # which columns each vertex may use (its area-of-influence verdict), for any
        # later repair so it can't spread a bone outside its area
        col_ok = np.ones((N, M), bool)
        mapped = np.where(col_fam >= 0)[0]
        col_ok[:, mapped] = allow[:, col_fam[mapped]] > 0
        return out, col_ok
    return out
