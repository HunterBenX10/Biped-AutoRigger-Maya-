"""Corrective (volume) joints: traps, scapula, elbow, wrist, hip, thigh/butt, knee, ankle.

Data: data/rig_rules.json > "correctives" (left side, right is mirrored). One entry is a
RING of helper joints around a hinge, never on the bone itself:

  centre   a point on the bone   at = [joint_a, joint_b, t]   (+ optional "shift")
  ring     directions around it: front / back / out / in / up / down
           (front = world forward made perpendicular to the bone, out = away from the
           body, up = world up - each made perpendicular to the bone)
  place    each ring joint sits inside the flesh: centre + dir x (distance to the mesh
           surface along dir, measured with a ray) x "depth"

How a ring joint J moves (all on nodes, nothing keyed):
  * a pivot at the hinge takes `follow` of the parent->child rotation (quaternion slerp);
    J rides on it (target under the pivot -> J), so it ORBITS the bone at full radius
    when the hinge bends or twists - it holds the circumference instead of collapsing.
  * push      = the target slides outward along J's direction by
                    remap(bend, 0 -> "angle" degrees, 0 -> 1) x "slide"
                bend = the larger of two angles between rest and current, both measured
                in the parent's space: the child's bone direction (any swing) and a
                vector across the child (catches twist) -> any axis, 0-180, never flips.
  * weights   = a soft round patch, taken only from the joints the ring sits between.
Distances are fractions of character height (except depth / skin radius, see below).
"""
import math
import re

import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes

CON_SUFFIX = "_skel_correctiveConstraint"
ANCHORS = ("_pA", "_cA")          # (older builds)
PIVOT, TARGET = "_pivot", "_tgt"
MAX_PUSH = 0.33                   # max slide, as a fraction of the flesh thickness
WORLD_X, WORLD_Y, WORLD_Z = om.MVector(1, 0, 0), om.MVector(0, 1, 0), om.MVector(0, 0, 1)


def groups():
    """[(name, label, [part defs])] - one entry per option in the Correctives list. An
    entry with "parts" is several hinges under one option (Back = trap + deltoid)."""
    out = []
    for e in data.rules().get("correctives", []):
        label = e.get("label", names.base(e["name"]).capitalize())
        out.append((e["name"], label, e.get("parts") or [e]))
    return out


def defs():
    return [d for _, _, parts in groups() for d in parts]


def expand(chosen):
    """Option names -> the corrective (part) names they're made of."""
    by = {name: parts for name, _, parts in groups()}
    return [d["name"] for c in chosen for d in by.get(c, [])] + \
        [c for c in chosen if c not in by]


def opt(d, r, key, default=None):
    """A setting for one ring joint: its own override (d["per"][ring]) or the preset's."""
    return d.get("per", {}).get(r, {}).get(key, d.get(key, default))


# older builds: the knee was two presets (pit + cap) - cleaned up when the knee is redone
LEGACY = {"knee_l": ("kneepit_back_l_hlp", "kneecap_front_l_hlp", "knee_back_l_hlp"),
          "elbow_l": ("elbow_front_l_hlp",),     # elbow: back (crease) only; knee: front only
          "ankle_l": ("ankle_out_l_hlp", "ankle_in_l_hlp"),   # ankle: front + back only
          "trap_l": ("neck_out_l_hlp",),         # the neck crease became Back (trap)
          "hip_l": ("hip_out_l_hlp", "hip_in_l_hlp")}   # the hip ring is front + back now


def legacy_joints(name):
    return [j for base in LEGACY.get(name, ()) for j in (base, names.mirror(base))
            if cmds.objExists(j)]


def _f(s):
    return lambda n: names.for_side(n, s)


def sides(d):
    """A centre corrective (waist...) is built once, a limb one on both sides."""
    return ("c",) if d.get("centre") else ("l", "r")


def joint_name(d, direction, s):
    # hip_l + back -> hip_back_l_hlp (side token kept just before _hlp); waist + front ->
    # waist_front_hlp
    if s == "c":
        return "{}_{}_hlp".format(names.base(d["name"]), direction)
    return names.for_side("{}_{}_l_hlp".format(names.base(d["name"]), direction), s)


def all_joints(d):
    return [joint_name(d, r, s) for r in d["ring"] for s in sides(d)]


def _measure(d, s):
    """The two joints the bend is read between: the hinge itself, or a longer stretch
    ("measure") - a waist bend is spread over several spine joints."""
    f = _f(s)
    a, b = d.get("measure", (d["parent"], d["child"]))
    return f(a), f(b)


def joint_names():
    return [j for d in defs() for j in all_joints(d)] + \
        [j for base in sum(LEGACY.values(), ()) for j in (base, names.mirror(base))]


# ---------------------------------------------------------------- geometry
def _flat(v, *axes):
    for a in axes:
        v = v - a * (v * a)
    return v


def _frame(d, s, h):
    """centre, bone axis, and the outward direction for each ring name."""
    f, sign = _f(s), (-1 if s == "r" else 1)
    a, b, t = d["at"]
    pa, pb = mathx.pos(f(a)), mathx.pos(f(b))
    y = (pb - pa).normal()
    shift = om.MVector(*d.get("shift", (0, 0, 0))) * h
    shift.x *= sign
    centre = pa + (pb - pa) * t + shift
    fwd = _flat(WORLD_Z, y)
    fwd = (fwd if fwd.length() > 0.2 else _flat(WORLD_Y, y)).normal()
    p = (y ^ fwd).normal()                        # the other axis across the bone

    def oriented(pref, backup):
        if abs(p * pref) >= 0.3:
            return p if p * pref > 0 else -p
        return p if p * backup > 0 else -p

    out = oriented(WORLD_X * sign, WORLD_Y)
    up = oriented(WORLD_Y, WORLD_X * sign)
    dirs = {"front": fwd, "back": -fwd, "out": out, "in": -out, "up": up, "down": -up}
    if s == "c":                                  # centre: the character's left / right
        dirs["left"], dirs["right"] = out, -out
    return centre, y, dirs


# ---------------------------------------------------------------- build (Build Skeleton)
def create(h, rays=None, only=None):
    """only: build just these corrective names (e.g. the elbow / knee set)."""
    made = []
    for d in defs():
        if only is not None and d["name"] not in only:
            continue
        for s in sides(d):
            f = _f(s)
            parent, child = f(d["parent"]), f(d["child"])
            if not (cmds.objExists(parent) and cmds.objExists(child)):
                continue
            centre, _, dirs = _frame(d, s, h)
            for r in d["ring"]:
                v = dirs[r]
                dist = rays.hit(centre, v, h * 0.3) if rays else None
                dist = dist if dist else d.get("radius", 0.035) * h
                p = centre + v * (dist * opt(d, r, "depth", 0.7))
                # lives under the hinge joint itself (wrist ring under hand, knee under
                # calf...); constraints place it, so the parent only sets the hierarchy
                if cmds.objExists(joint_name(d, r, s)):
                    continue
                j = cmds.createNode("joint", name=joint_name(d, r, s), parent=child)
                cmds.xform(j, ws=True, translation=(p.x, p.y, p.z))
                cmds.setAttr(j + ".jointOrient", 0, 0, 0)
                cmds.setAttr(j + ".rotate", 0, 0, 0)
                cmds.setAttr(j + ".radius", h / 40.0)
                cmds.setAttr(j + ".overrideEnabled", 1)
                cmds.setAttr(j + ".overrideColor", config.HELPER_COLOR)
                made.append(j)
    return made


# ---------------------------------------------------------------- drivers (Skin / Rig)
def _local_vectors(child, across_world):
    """Child bone direction + a vector across the child, in the child's local space."""
    kids = [k for k in cmds.listRelatives(child, children=True, type="joint") or []
            if "twist" not in k and not k.endswith("_hlp")]
    m = om.MMatrix(cmds.getAttr(child + ".worldMatrix[0]"))
    bone = (mathx.pos(kids[0]) - mathx.pos(child)) if kids else mathx.axis(m, 1)
    inv = m.inverse()
    return bone.normal() * inv, across_world.normal() * inv


_SHARED = {}                      # (kind, parent, child, ...) -> plug, for one drive() pass


def _angle(tag, parent, child, across_world):
    """Bend angle of child vs parent (the larger of the bone swing and the twist of a
    vector across it, both in the parent's space - any axis, 0-180, never flips). Built
    ONCE per hinge and shared by every joint around it."""
    a = across_world.normal()
    key = ("angle", parent, child, round(a.x, 3), round(a.y, 3), round(a.z, 3))
    if key in _SHARED and cmds.objExists(_SHARED[key].split(".")[0]):
        return _SHARED[key]
    mm = cmds.createNode("multMatrix", name=tag + "_rel")
    cmds.connectAttr(child + ".worldMatrix[0]", mm + ".matrixIn[0]")
    cmds.connectAttr(parent + ".worldInverseMatrix[0]", mm + ".matrixIn[1]")
    rest_rel = om.MMatrix(cmds.getAttr(child + ".worldMatrix[0]")) * \
        om.MMatrix(cmds.getAttr(parent + ".worldInverseMatrix[0]"))
    angles = []
    for i, local in enumerate(_local_vectors(child, across_world)):
        rest = (local * rest_rel).normal()
        vp = cmds.createNode("vectorProduct", name="{}_vec{}".format(tag, i))
        cmds.setAttr(vp + ".operation", 3)                         # vector x matrix
        cmds.setAttr(vp + ".normalizeOutput", 1)
        cmds.setAttr(vp + ".input1", local.x, local.y, local.z)
        cmds.connectAttr(mm + ".matrixSum", vp + ".matrix")
        ab = cmds.createNode("angleBetween", name="{}_angle{}".format(tag, i))
        cmds.setAttr(ab + ".vector1", rest.x, rest.y, rest.z)
        cmds.connectAttr(vp + ".output", ab + ".vector2")
        angles.append(ab + ".angle")
    big = cmds.createNode("condition", name=tag + "_max")          # larger of the two
    cmds.setAttr(big + ".operation", 2)
    cmds.connectAttr(angles[0], big + ".firstTerm")
    cmds.connectAttr(angles[1], big + ".secondTerm")
    cmds.connectAttr(angles[0], big + ".colorIfTrueR")
    cmds.connectAttr(angles[1], big + ".colorIfFalseR")
    _SHARED[key] = big + ".outColorR"
    return _SHARED[key]


def _bend(tag, parent, child, across_world, angle, start=0.0):
    """0-1: how far the child has bent / twisted from rest relative to the parent
    (the shared angle, eased from `start` to `angle` degrees - one remap per joint)."""
    big = _angle(tag, parent, child, across_world)
    rm = cmds.createNode("remapValue", name=tag + "_amount")
    # an angle plugged into a plain number arrives in the UI unit (degrees by default) -
    # the old radians limit made every corrective reach full push after ~2 degrees (snap)
    cmds.connectAttr(big, rm + ".inputValue")
    deg = cmds.currentUnit(query=True, angle=True).startswith("deg")
    cmds.setAttr(rm + ".inputMin", start if deg else math.radians(start))
    cmds.setAttr(rm + ".inputMax", angle if deg else math.radians(angle))
    for i in (0, 1):                                  # ease in / out: gradual, no kick
        cmds.setAttr("{}.value[{}].value_Interp".format(rm, i), 2)
    return rm + ".outValue"


def _anchor(j, suffix, under, slide_world, amount):
    a = cmds.createNode("transform", name=j + suffix, parent=under)
    cmds.xform(a, ws=True, translation=tuple(mathx.pos(j)))
    slide = slide_world * om.MMatrix(cmds.getAttr(under + ".worldInverseMatrix[0]"))
    md = cmds.createNode("multiplyDivide", name="{}_{}{}_push".format(config.SKEL_UTIL, j,
                                                                      suffix))
    for ax in "XYZ":
        cmds.connectAttr(amount, md + ".input1" + ax)
    cmds.setAttr(md + ".input2", slide.x, slide.y, slide.z)
    add = cmds.createNode("plusMinusAverage", name="{}_{}{}_pos".format(config.SKEL_UTIL, j,
                                                                        suffix))
    cmds.setAttr(add + ".input3D[0]", *cmds.getAttr(a + ".translate")[0])
    cmds.connectAttr(md + ".output", add + ".input3D[1]")
    cmds.connectAttr(add + ".output3D", a + ".translate")
    return a


LIVE = (("Move_X", "how far it moves OUT (away from the body / to the character's left on "
                   "the waist) at full bend"),
        ("Move_Y", "how far it moves ALONG the bone (+ toward the joint) at full bend"),
        ("Move_Z", "how far it moves FORWARD at full bend"),
        ("Start_Angle", "bend (degrees) where it starts moving"),
        ("Full_Angle", "bend (degrees) where it has moved fully"),
        ("Skin_Size", "skin patch radius, x the flesh thickness there (Re-weight to apply)"),
        ("Skin_Strength", "how much of the skin it takes, 0-1 (Re-weight to apply)"))
MOVE = ("Move_X", "Move_Y", "Move_Z")
TOWARD_GAIN = 3.0                 # directional joints: full push from ~20 deg toward them
MOVE_UNIT = 0.2                   # editor slider step: 1 = 20% of the flesh thickness there


def frame(d, s, h):
    """The corrective's move axes (world): X out, Y along the bone, Z forward. Mirror-
    symmetric by construction, so the same numbers give the same result on both sides."""
    _, y, dirs = _frame(d, s, h)
    return dirs["out"], y, dirs["front"]


def axis_words(d, s, h):
    """What Move X / Y / Z mean for this corrective, in plain words (X / Z by the world
    direction they point: out / up / forward...; Y is always along the bone)."""
    side = -1 if s == "r" else 1
    words = []
    for k, v in enumerate(frame(d, s, h)):
        if k == 1:
            words.append("along bone")
            continue
        c = (v.x * side, v.y, v.z)
        i = max(range(3), key=lambda n: abs(c[n]))
        pos = c[i] > 0
        if i == 0:
            words.append(("left" if pos else "right") if s == "c" else
                         ("out" if pos else "in"))
        else:
            words.append(("up", "down")[not pos] if i == 1 else ("forward", "back")[not pos])
    return words


def _live_attrs(j, values):
    """Move / angle / skin settings live on the corrective joint (hidden from the Channel
    Box - edit them in the Correctives tab). Kept across rebuilds. Older joints' Push /
    Push_Along are converted once."""
    for attr, value in values:
        if not cmds.attributeQuery(attr, node=j, exists=True):
            cmds.addAttr(j, longName=attr, attributeType="double", defaultValue=value)
            cmds.setAttr(j + "." + attr, value)


def drive(h, only=None):
    """Drive every corrective joint that exists (only: these corrective names).
    Each joint: rides a pivot at the hinge that takes `follow` of the bend (it orbits the
    bone at full radius under bend and twist), and moves by
        (Move_X out + Move_Y along the bone + Move_Z forward)
          x remap(bend, Start_Angle -> Full_Angle, 0 -> 1, eased).
    The default move is `push` x the flesh thickness measured at that spot (not a
    fraction of height), so it suits any body; then it's yours to tune (Correctives
    tab)."""
    nodes.ensure_plugins("matrixNodes")
    _SHARED.clear()
    count = 0
    deg = cmds.currentUnit(query=True, angle=True).startswith("deg")
    for d in defs():
        if only is not None and d["name"] not in only:
            continue
        for s in sides(d):
            f = _f(s)
            parent, child = f(d["parent"]), f(d["child"])
            m_parent, m_child = _measure(d, s)
            joints = [(r, joint_name(d, r, s)) for r in d["ring"]]
            joints = [(r, j) for r, j in joints if cmds.objExists(j)]
            if not (joints and all(cmds.objExists(n) for n in
                                   (parent, child, m_parent, m_child))):
                continue
            centre, y, dirs = _frame(d, s, h)
            across = dirs["front"] ^ y
            follow = d.get("follow", 0.5)
            pivot = _swing_pivot("{}_{}".format(names.for_side(d["name"], s), "hlp" + PIVOT),
                                 parent, child, follow, h)
            ax_out, ax_y, ax_fwd = frame(d, s, h)
            for r, j in joints:
                offset = _flat(mathx.pos(j) - centre, y)
                out = offset.normal()
                thickness = offset.length() / opt(d, r, "depth", 0.7)
                push = thickness * opt(d, r, "push", MAX_PUSH)
                along = thickness * opt(d, r, "along", 0.0)
                if cmds.attributeQuery("Push", node=j, exists=True):     # older build
                    push = cmds.getAttr(j + ".Push")
                    if cmds.attributeQuery("Push_Along", node=j, exists=True):
                        along = cmds.getAttr(j + ".Push_Along")
                    for old in ("Push", "Push_Along"):
                        if cmds.attributeQuery(old, node=j, exists=True):
                            cmds.deleteAttr(j + "." + old)
                move = out * push + ax_y * along
                size, strength = opt(d, r, "skin", (1.3, 0.5))
                _live_attrs(j, (("Move_X", move * ax_out), ("Move_Y", move * ax_y),
                                ("Move_Z", move * ax_fwd),
                                ("Start_Angle", opt(d, r, "start", 0.0)),
                                ("Full_Angle", opt(d, r, "angle", 90.0)),
                                ("Skin_Size", size), ("Skin_Strength", strength),
                                ("Move_Unit", MOVE_UNIT * thickness)))
                for k in ("Start_Angle", "Full_Angle"):     # older joints: out of the CB
                    cmds.setAttr(j + "." + k, keyable=False, channelBox=False)
                amount = _bend("{}_{}".format(config.SKEL_UTIL, j), m_parent, m_child, across,
                               opt(d, r, "angle", 90), opt(d, r, "start", 0))
                if deg:                                  # live angles (degrees UI)
                    rm = amount.split(".")[0]
                    cmds.connectAttr(j + ".Start_Angle", rm + ".inputMin", force=True)
                    cmds.connectAttr(j + ".Full_Angle", rm + ".inputMax", force=True)
                if opt(d, r, "directional"):
                    amount = _toward(j, m_parent, m_child, out, amount)
                # extra hinges that squeeze the same spot (neck crease: the head tilting
                # AND the shoulder shrugging) - the joint moves by whichever is more
                for k, (pa, ch, st, full) in enumerate(opt(d, r, "also", [])):
                    if not (cmds.objExists(f(pa)) and cmds.objExists(f(ch))):
                        continue
                    extra = _bend("{}_{}_also{}".format(config.SKEL_UTIL, j, k), f(pa), f(ch),
                                  across, full, st)
                    amount = _larger("{}_{}_also{}".format(config.SKEL_UTIL, j, k), amount,
                                     extra)
                target = _anchor_move(j, pivot, amount, (ax_out, ax_y, ax_fwd))
                cmds.pointConstraint(target, j, maintainOffset=False,
                                     name=j + "_point" + CON_SUFFIX)
                ocj = cmds.orientConstraint(pivot, j, maintainOffset=True,
                                            name=j + "_orient" + CON_SUFFIX)[0]
                cmds.setAttr(ocj + ".interpType", 2)
                count += 1
    return count


def _swing_pivot(name, parent, child, follow, h):
    """The ring's pivot: at the hinge, turning `follow` of the way with the child's BEND
    only - never its twist (a thigh rolling under a pelvis tipped far forward used to
    roll the hip ring with it). It aims at a point `follow` of the way from where the
    child bone pointed at rest (held by the parent) to where it points now (carried by the
    child), its up axis held in the parent's frame. At rest it lines up exactly: no pop."""
    c = mathx.pos(child)
    kids = [k for k in cmds.listRelatives(child, children=True, type="joint") or []
            if "twist" not in k and not k.endswith("_hlp")]
    if kids:
        bone = om.MVector()
        for k in kids:
            bone += (mathx.pos(k) - c).normal()
        length = max(min((mathx.pos(k) - c).length() for k in kids), h * 0.02)
    else:
        bone = mathx.axis(om.MMatrix(cmds.getAttr(child + ".worldMatrix[0]")), 1)
        length = h * 0.05
    if bone.length() < 1e-6:
        bone = mathx.axis(om.MMatrix(cmds.getAttr(child + ".worldMatrix[0]")), 1)
    bone = bone.normal()
    tip = c + bone * length
    pivot = cmds.createNode("transform", name=name, parent=parent)
    cmds.xform(pivot, ws=True, translation=tuple(c))
    rest = cmds.createNode("transform", name=name + "_rest", parent=parent)
    now = cmds.createNode("transform", name=name + "_now", parent=child)
    aim = cmds.createNode("transform", name=name + "_aim", parent=parent)
    for n in (rest, now, aim):
        cmds.xform(n, ws=True, translation=tuple(tip))
    pc = cmds.pointConstraint(rest, now, aim, maintainOffset=False,
                              name=aim + CON_SUFFIX)[0]
    w0, w1 = cmds.pointConstraint(pc, q=True, weightAliasList=True)
    cmds.setAttr(pc + "." + w0, 1.0 - follow)
    cmds.setAttr(pc + "." + w1, follow)
    inv = om.MMatrix(cmds.getAttr(pivot + ".worldInverseMatrix[0]"))
    aim_v = (bone * inv).normal()                         # in the pivot's (= parent) axes
    axes = (om.MVector(1, 0, 0), om.MVector(0, 1, 0), om.MVector(0, 0, 1))
    up = min(axes, key=lambda a: abs(a * aim_v))
    up = (up - aim_v * (up * aim_v)).normal()
    cmds.aimConstraint(aim, pivot, maintainOffset=False, aimVector=tuple(aim_v),
                       upVector=tuple(up), worldUpType="objectrotation",
                       worldUpObject=parent, worldUpVector=tuple(up),
                       name=pivot + CON_SUFFIX)
    return pivot


def _larger(tag, a, b):
    big = cmds.createNode("condition", name=tag + "_larger")
    cmds.setAttr(big + ".operation", 2)                          # a > b ? a : b
    cmds.connectAttr(a, big + ".firstTerm")
    cmds.connectAttr(b, big + ".secondTerm")
    cmds.connectAttr(a, big + ".colorIfTrueR")
    cmds.connectAttr(b, big + ".colorIfFalseR")
    return big + ".outColorR"


def _swing(tag, parent, child):
    """How the child's bone direction moved from rest, in the parent's space (current -
    rest) - built once per hinge, shared by its directional joints."""
    key = ("swing", parent, child)
    if key in _SHARED and cmds.objExists(_SHARED[key].split(".")[0]):
        return _SHARED[key]
    kids = [k for k in cmds.listRelatives(child, children=True, type="joint") or []
            if "twist" not in k and not k.endswith("_hlp")]
    cm = om.MMatrix(cmds.getAttr(child + ".worldMatrix[0]"))
    pinv = om.MMatrix(cmds.getAttr(parent + ".worldInverseMatrix[0]"))
    bone = (mathx.pos(kids[0]) - mathx.pos(child)) if kids else mathx.axis(cm, 1)
    local = bone.normal() * cm.inverse()
    rest = (bone.normal() * pinv).normal()
    mm = cmds.createNode("multMatrix", name=tag + "_rel")
    cmds.connectAttr(child + ".worldMatrix[0]", mm + ".matrixIn[0]")
    cmds.connectAttr(parent + ".worldInverseMatrix[0]", mm + ".matrixIn[1]")
    v = cmds.createNode("vectorProduct", name=tag + "_dir")
    cmds.setAttr(v + ".operation", 3)
    cmds.setAttr(v + ".normalizeOutput", 1)
    cmds.setAttr(v + ".input1", local.x, local.y, local.z)
    cmds.connectAttr(mm + ".matrixSum", v + ".matrix")
    diff = cmds.createNode("plusMinusAverage", name=tag + "_swing")
    cmds.setAttr(diff + ".operation", 2)
    cmds.connectAttr(v + ".output", diff + ".input3D[0]")
    cmds.setAttr(diff + ".input3D[1]", rest.x, rest.y, rest.z)
    _SHARED[key] = diff + ".output3D"
    return _SHARED[key]


def _toward(j, parent, child, out_world, amount):
    """Rings that go all the way round (wrist, ankle...): a joint only pushes when the
    child bends TOWARD its side (that side is the one being squeezed) - bending away
    leaves it alone. amount x clamp(swing direction . the joint's direction, 0, 1)."""
    tag = "{}_{}_toward".format(config.SKEL_UTIL, j)
    swing = _swing("{}_{}_{}".format(config.SKEL_UTIL, names.short(parent),
                                     names.short(child)), parent, child)
    pinv = om.MMatrix(cmds.getAttr(parent + ".worldInverseMatrix[0]"))
    o = (out_world * pinv).normal()
    # swing . joint direction, NOT normalized: at rest the swing is a zero vector and a
    # normalizing dot product errors on every evaluation ("zero-length output vector").
    # |swing| = 2 sin(bend / 2), so x TOWARD_GAIN reaches 1 at ~20 degrees toward the
    # joint (the bend amount itself is eased separately)
    nrm = cmds.createNode("vectorProduct", name=tag + "_way")
    cmds.setAttr(nrm + ".operation", 1)
    cmds.setAttr(nrm + ".normalizeOutput", 0)
    cmds.connectAttr(swing, nrm + ".input1")
    cmds.setAttr(nrm + ".input2", o.x * TOWARD_GAIN, o.y * TOWARD_GAIN, o.z * TOWARD_GAIN)
    cl = cmds.createNode("clamp", name=tag + "_clamp")
    cmds.setAttr(cl + ".maxR", 1)
    cmds.connectAttr(nrm + ".outputX", cl + ".inputR")
    m = nodes.mult(tag + "_amount")
    cmds.connectAttr(amount, m + ".input1")
    cmds.connectAttr(cl + ".outputR", m + ".input2")
    return m + ".output"


def _anchor_move(j, under, amount, axes):
    """Target under the pivot at j's rest spot, moved by
    amount x (Move_X * out + Move_Y * along + Move_Z * forward)  - the three axes as the
    rows of one constant matrix, so the move is a single vector x matrix node."""
    a = cmds.createNode("transform", name=j + TARGET, parent=under)
    cmds.xform(a, ws=True, translation=tuple(mathx.pos(j)))
    inv = om.MMatrix(cmds.getAttr(under + ".worldInverseMatrix[0]"))
    rows = [(axis * inv).normal() for axis in axes]
    m = [rows[0].x, rows[0].y, rows[0].z, 0, rows[1].x, rows[1].y, rows[1].z, 0,
         rows[2].x, rows[2].y, rows[2].z, 0, 0, 0, 0, 1]
    vp = cmds.createNode("vectorProduct", name="{}_{}_move".format(config.SKEL_UTIL, j))
    cmds.setAttr(vp + ".operation", 3)                          # vector x matrix
    for attr, c in zip(MOVE, "XYZ"):
        cmds.connectAttr(j + "." + attr, vp + ".input1" + c)
    cmds.setAttr(vp + ".matrix", *m, type="matrix")
    md = cmds.createNode("multiplyDivide", name="{}_{}_amount".format(config.SKEL_UTIL, j))
    cmds.connectAttr(vp + ".output", md + ".input1")
    for c in "XYZ":
        cmds.connectAttr(amount, md + ".input2" + c)
    add = cmds.createNode("plusMinusAverage", name="{}_{}_pos".format(config.SKEL_UTIL, j))
    cmds.setAttr(add + ".input3D[0]", *cmds.getAttr(a + ".translate")[0])
    cmds.connectAttr(md + ".output", add + ".input3D[1]")
    cmds.connectAttr(add + ".output3D", a + ".translate")
    return a


def delete_patterns():
    return ["*" + CON_SUFFIX + "*", "*_hlp" + PIVOT, "*_hlp" + PIVOT + "_*",
            "*_hlp" + TARGET] + \
        ["*_hlp" + a for a in ANCHORS]


# ---------------------------------------------------------------- skin weights
BLEND_SIZE, BLEND_STRENGTH = 1.5, 1.0   # reach (x flesh thickness), share of the mid-blend
SMOOTH_PASSES = 4                       # relax the new weights with their neighbours


def apply_weights(sc, shape, h, only=None):
    """Corrective weights (every corrective, same method): the ring joints turn about half
    as far as the bend, so they take the MIDDLE of the parent / child blend - the band
    where linear skinning collapses - shared out by direction (front flesh to the front
    joint ...). Then the area is relaxed with its neighbours (SMOOTH_PASSES), so there's
    no hard edge where the corrective's share starts. Tested on a full body at 120
    degrees: elbow volume 73% -> 83% (worst 51% -> 76%), knee 71% -> 85% (50% -> 78%),
    no new stray vertices - the old round patch only reached 77% / 75%."""
    import numpy as np
    from .skin import _all_vertices, _dag, _edges, _skin_fn, limit_influences
    fn, dag = _skin_fn(sc), _dag(shape)
    infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
    index = {n: i for i, n in enumerate(infl)}
    mesh = om.MFnMesh(dag)
    pts = mesh.getPoints(om.MSpace.kWorld)
    comp = _all_vertices(len(pts))
    w, ninf = fn.getWeights(dag, comp)
    W = np.array(w).reshape(-1, ninf)          # SPEED: one numpy array for every corrective
    P = np.array([(p.x, p.y, p.z) for p in pts])
    given, cols = 0, set()
    for d in defs():
        if only is not None and d["name"] not in only:
            continue
        for s in sides(d):
            f = _f(s)
            bases = [f(n) for n in [d["parent"], d["child"]] + d.get("donors", [])]
            pattern = re.compile(r"^({})_twist_\d+(_[lr])?$".format(
                "|".join(re.escape(names.base(b)) for b in bases)))
            donors = [i for i, n in enumerate(infl)
                      if (n in bases or pattern.match(n)) and names.side(n) in (s, "c")]
            given += _blend_weights(d, s, h, W, P, infl, index, donors, bases)
            cols.update(index[joint_name(d, r, s)] for r in d["ring"]
                        if joint_name(d, r, s) in index)
    if cols and SMOOTH_PASSES:
        edges = _edges(mesh)
        zone = W[:, sorted(cols)].sum(1) > 1e-4
        i, k = edges
        for _ in range(2):                                  # + 2 rings around it
            grow = np.zeros_like(zone)
            grow[i[zone[k]]] = True
            zone |= grow
        deg = np.maximum(np.bincount(i, minlength=len(W)), 1).astype(float)
        # SPEED: only the zone's edges and the columns that are used around it
        e = zone[i]
        ei, ek = i[e], k[e]
        near = zone.copy()
        near[ek] = True
        used = np.where(W[near].any(0))[0]
        rows = np.where(zone)[0]
        for _ in range(SMOOTH_PASSES):
            sub = W[:, used]
            acc = np.zeros((len(W), len(used)))
            np.add.at(acc, ei, sub[ek])
            W[np.ix_(rows, used)] = 0.5 * sub[rows] + 0.5 * (acc[rows] / deg[rows, None])
        W[rows] /= np.maximum(W[rows].sum(1, keepdims=True), 1e-12)
    fn.setWeights(dag, comp, om.MIntArray(list(range(ninf))), om.MDoubleArray(W.ravel()),
                  False)
    limit_influences(sc, shape)
    return given


def _blend_weights(d, s, h, W, P, infl, index, donors, bases):
    """The ring joints turn half as far as the child, so they take the
    MIDDLE of the parent / child blend - where linear skinning collapses most (a vertex
    half on each side lands halfway between, nearer the joint). Each vertex gives
    Skin_Strength x (how mid-blend it is: 1 at 50/50, 0 fully on one side), shared between
    the ring joints by direction (front flesh to the front joint...), within Skin_Size x
    the flesh thickness of the joint."""
    import numpy as np
    centre, y, _ = _frame(d, s, h)
    c = np.array(tuple(centre))
    ya = np.array(tuple(y))
    f = _f(s)
    child_base = names.base(f(d["child"]))
    child_cols = [i for i in donors if names.base(infl[i]).startswith(child_base)]
    if not child_cols:
        return 0
    pool = W[:, donors].sum(1)
    t = W[:, child_cols].sum(1) / np.maximum(pool, 1e-9)
    mid = np.clip(1.0 - np.abs(2.0 * t - 1.0), 0.0, 1.0)
    q = P - c
    radial = q - np.outer(q @ ya, ya)
    rn = np.linalg.norm(radial, axis=1)
    unit = radial / np.maximum(rn, 1e-9)[:, None]
    rings = []
    for r in d["ring"]:
        j = joint_name(d, r, s)
        if j not in index:
            continue
        off = np.array(tuple(_flat(mathx.pos(j) - centre, y)))
        thick = np.linalg.norm(off) / opt(d, r, "depth", 0.7)
        size, strength = BLEND_SIZE, BLEND_STRENGTH
        rings.append((index[j], off / max(np.linalg.norm(off), 1e-9), thick * size, strength))
    if not rings:
        return 0
    score = np.stack([np.clip(unit @ o, 0.0, None) ** 2 for _, o, _, _ in rings], 1)
    score /= np.maximum(score.sum(1, keepdims=True), 1e-9)
    dist = np.linalg.norm(q, axis=1)
    give = np.zeros(len(P))
    takes = []
    for k, (col, _, radius, strength) in enumerate(rings):
        fall = 1.0 - np.clip((dist - 0.7 * radius) / (0.3 * radius), 0.0, 1.0)
        take = strength * mid * score[:, k] * fall * pool
        takes.append((col, take))
        give += take
    give = np.minimum(give, pool)
    keep = 1.0 - give / np.maximum(pool, 1e-9)
    for i in donors:
        W[:, i] *= keep
    tot = sum(tk for _, tk in takes)
    scale = np.where(tot > 1e-9, give / np.maximum(tot, 1e-9), 0.0)
    for col, take in takes:
        W[:, col] += take * scale              # in place - the caller's array
    return int((give > 1e-4).sum())
