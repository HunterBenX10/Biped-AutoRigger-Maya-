"""Switch Space - change a space attr WITHOUT the ctrl jumping.

Select a ctrl (the one that moves, e.g. hand_l_ik_ctrl / upperarm_l_fk_ctrl, or the ctrl
that holds the attr, e.g. hand_l_fkik_switch) and pick the new space: the ctrls under that
space's group are put back exactly where they were in the world. With auto key on (or
when the ctrl is already animated) the switch and the matched pose are keyed on this
frame, with the old values keyed one frame before so the animation doesn't drift.
"""
import maya.cmds as cmds
import maya.api.OpenMaya as om

from ..core import data, names


def _entries():
    """Every space switch in the rig: (attr host, attr, group, space names)."""
    out = []
    for sp in data.rules()["spaces"]:
        for side in ("lr" if names.is_left(sp["ctrl"]) else "c"):
            host = names.for_side(sp["ctrl"], side)
            grp = names.for_side(sp["group"], side)
            if cmds.objExists(host) and cmds.objExists(grp) and \
                    cmds.attributeQuery(sp["attr"], node=host, exists=True):
                out.append((host, sp["attr"], grp, sp["names"]))
    return out


def _ctrls_under(grp, space_groups):
    """The ctrls a space group carries (stops at ctrls and at other space groups)."""
    found, todo = [], list(cmds.listRelatives(grp, children=True, type="transform") or [])
    while todo:
        n = todo.pop(0)
        if cmds.listRelatives(n, shapes=True, type="nurbsCurve"):
            found.append(n)
        elif n not in space_groups:
            todo += cmds.listRelatives(n, children=True, type="transform") or []
    return found


def for_selection():
    """Space switches that concern the selected ctrls."""
    entries = _entries()
    groups = {e[2] for e in entries}
    sel = [names.short(s) for s in cmds.ls(selection=True) or []]
    hits = []
    for e in entries:
        host, _, grp, _ = e
        if host in sel or any(c in sel for c in _ctrls_under(grp, groups)):
            hits.append(e)
    return hits


def _set_world(node, m):
    """Put a ctrl at world matrix m through its own channels (Offset Parent Matrix and
    rotate pivot taken into account); locked channels are left alone."""
    parent = om.MMatrix(cmds.getAttr(node + ".parentMatrix[0]"))
    opm = om.MMatrix(cmds.getAttr(node + ".offsetParentMatrix"))
    local = om.MTransformationMatrix(m * (opm * parent).inverse())
    ro = cmds.getAttr(node + ".rotateOrder")
    e = local.rotation(asQuaternion=False)
    e = e.reorder(ro)
    rot = [om.MAngle(a).asDegrees() for a in (e.x, e.y, e.z)]
    # local matrix = [-rp] R [rp] [rpt] [t]  ->  t = translation - rp + rp*R - rpt
    rp = om.MVector(*cmds.getAttr(node + ".rotatePivot")[0])
    rpt = om.MVector(*cmds.getAttr(node + ".rotatePivotTranslate")[0])
    rmat = om.MEulerRotation(e).asMatrix()
    t = local.translation(om.MSpace.kTransform) - rp + rp * rmat - rpt
    for attr, values in (("rotate", rot), ("translate", (t.x, t.y, t.z))):
        for ax, v in zip("XYZ", values):
            plug = "{}.{}{}".format(node, attr, ax)
            if cmds.getAttr(plug, settable=True):
                cmds.setAttr(plug, v)


def switch(host, attr, grp, index):
    """Change host.attr to index, keeping every ctrl under grp where it is."""
    groups = {e[2] for e in _entries()}
    ctrls = _ctrls_under(grp, groups)
    keyed = cmds.autoKeyframe(q=True, state=True) or any(
        cmds.keyframe(n, q=True, keyframeCount=True) for n in ctrls + [host])
    now = cmds.currentTime(q=True)
    if keyed:                                   # hold the old space up to here
        cmds.setKeyframe(host, attribute=attr, time=now - 1)
        for c in ctrls:
            cmds.setKeyframe(c, attribute=["translate", "rotate"], time=now - 1)
    world = {c: om.MMatrix(cmds.getAttr(c + ".worldMatrix[0]")) for c in ctrls}
    cmds.setAttr("{}.{}".format(host, attr), index)
    for c in ctrls:
        _set_world(c, world[c])
    if keyed:
        cmds.setKeyframe(host, attribute=attr, time=now)
        for c in ctrls:
            cmds.setKeyframe(c, attribute=["translate", "rotate"], time=now)
    print("{}.{} -> {} ({} ctrl(s) kept in place)".format(host, attr, index, len(ctrls)))


def switch_dialog():
    """Pick the new space for the selected ctrl in a small dialog."""
    hits = for_selection()
    if not hits:
        cmds.warning("Select a ctrl that has spaces (IK hand, FK arm, pole vector, head, "
                     "FK leg) or the switch that holds them.")
        return
    for host, attr, grp, labels in hits:
        cur = cmds.getAttr("{}.{}".format(host, attr))
        buttons = [("* " if i == cur else "") + n for i, n in enumerate(labels)] + ["Cancel"]
        pick = cmds.confirmDialog(title="Switch Space",
                                  message="{} . {}  (now: {})".format(
                                      host, attr, labels[cur]),
                                  button=buttons, cancelButton="Cancel",
                                  dismissString="Cancel")
        if pick == "Cancel" or pick is None:
            continue
        index = buttons.index(pick)
        if index != cur:
            switch(host, attr, grp, index)
