"""Twist joints (same setup as the Twist Joints Creator).

upper (thigh, upperarm): twist joints counter the joint's own twist  ->  -(1 - t)
lower (calf, lowerarm):  twist joints follow the child's (foot/hand) ->  t
Their position slides with the child joint, so they spread out when the limb stretches.

The lower twist is read AROUND THE LIMB'S OWN AXIS (forearm / shin Y), from the child's
rotation relative to its rest pose in the limb's space - the axis the twist joints
actually turn on. (It used to be read round the hand's / foot's own Y, which points at the
middle finger / toes and can sit well off the forearm, so part of a hand turn never
reached the forearm twist joints and the wrist wrapped.)
"""
import maya.cmds as cmds

from .. import config
from ..core import data, mathx, nodes


def _keep_y(tag, quat_source):
    """Swing / twist split: the twist round local Y of a quaternion, as degrees."""
    qn = cmds.createNode("quatNormalize", name=tag + "_qn")           # keep Y only
    for c in "YW":
        cmds.connectAttr(quat_source + ".outputQuat" + c, qn + ".inputQuat" + c)
    qte = cmds.createNode("quatToEuler", name=tag + "_qte")
    cmds.connectAttr(qn + ".outputQuat", qte + ".inputQuat")
    return qte + ".outputRotateY"


def _twist_plug(joint):
    """Plug with the joint's Y twist relative to its current (rest) pose, measured in
    the joint's own rest frame (upper limbs: the upperarm / thigh round itself)."""
    tag = "{}_{}_twist".format(config.SKEL_UTIL, joint)
    mm = cmds.createNode("multMatrix", name=tag + "_mm")
    cmds.connectAttr(joint + ".matrix", mm + ".matrixIn[0]")
    cmds.setAttr(mm + ".matrixIn[1]", cmds.getAttr(joint + ".inverseMatrix"), type="matrix")
    dm = cmds.createNode("decomposeMatrix", name=tag + "_dm")
    cmds.connectAttr(mm + ".matrixSum", dm + ".inputMatrix")
    return _keep_y(tag, dm)


def _twist_in_parent(child):
    """Plug with the child's twist round its PARENT's Y axis (the limb bone), relative to
    rest:  Q = rest_local^-1 x current_local  is the child's rotation since rest, written
    in the parent's frame; its swing / twist split round Y is exactly the turn the
    twist joints (children of the limb, same axes) must share out."""
    tag = "{}_{}_twistInParent".format(config.SKEL_UTIL, child)
    mm = cmds.createNode("multMatrix", name=tag + "_mm")
    cmds.setAttr(mm + ".matrixIn[0]", cmds.getAttr(child + ".inverseMatrix"), type="matrix")
    cmds.connectAttr(child + ".matrix", mm + ".matrixIn[1]")
    dm = cmds.createNode("decomposeMatrix", name=tag + "_dm")
    cmds.connectAttr(mm + ".matrixSum", dm + ".inputMatrix")
    return _keep_y(tag, dm)


def style_twists():
    """Twist joints drawn BIGGER than the limb bones and light blue, so they're easy to
    see and pick (display only - radius / colour, nothing locked or connected)."""
    count = 0
    for j in cmds.ls("*twist*", type="joint") or []:
        parent = (cmds.listRelatives(j, parent=True, type="joint") or [None])[0]
        if not parent:
            continue
        cmds.setAttr(j + ".radius", cmds.getAttr(parent + ".radius") * config.TWIST_RADIUS)
        try:
            cmds.setAttr(j + ".overrideEnabled", 1)
            cmds.setAttr(j + ".overrideColor", config.TWIST_COLOR)
        except RuntimeError:                       # (attribute connected by the user)
            pass
        count += 1
    return count


def drive_twists():
    nodes.ensure_plugins("matrixNodes", "quatNodes")
    driven = []
    for base, kind in data.rules()["twist_drive"].items():
        for side in "lr":
            start = "{}_{}".format(base, side)
            if not cmds.objExists(start):
                continue
            kids = cmds.listRelatives(start, children=True, type="joint") or []
            twists = sorted(k for k in kids if "twist" in k)
            ends = [k for k in kids if "twist" not in k and not k.endswith("_hlp")]
            if not twists or not ends:
                continue
            driver = _twist_plug(start) if kind == "upper" else _twist_in_parent(ends[0])
            t_last = len(twists) / float(len(twists) + 1)
            for i, tw in enumerate(twists, 1):
                t = i / float(len(twists) + 1)
                mdl = nodes.mult("{}_{}_mdl".format(config.SKEL_UTIL, tw))
                cmds.connectAttr(driver, mdl + ".input1")
                # lower limbs: the twist joint next to the wrist / ankle turns fully with
                # the hand / foot and the turn fades toward the elbow / knee (like a real
                # forearm) - the wrist blend then has no twist left to pinch (candy wrap)
                share = -(1 - t) if kind == "upper" else t / t_last
                cmds.setAttr(mdl + ".input2", share)
                cmds.connectAttr(mdl + ".output", tw + ".rotateY", force=True)
                # stay at the same fraction along the bone when it stretches
                md = cmds.createNode("multiplyDivide", name="{}_{}_slide".format(
                    config.SKEL_UTIL, tw))
                cmds.connectAttr(ends[0] + ".translate", md + ".input1")
                cmds.setAttr(md + ".input2", t, t, t)
                cmds.connectAttr(md + ".output", tw + ".translate", force=True)
                driven.append(tw)
            _knee_slide(base, start, ends[0], twists)
    style_twists()
    return driven


def knee_slide_on():
    root = "root"
    return cmds.objExists(root) and cmds.attributeQuery("brb_knee_slide", node=root,
                                                        exists=True)


def _knee_slide(base, calf, foot, twists):
    """Deep-knee-bend stretch (the 'sliding shin' trick): past `start` degrees of knee
    bend, the calf twist joints slide down the shin - the top one most, the bottom one
    least - so the skin under the kneecap stretches instead of pinching. Eased 0-1 by
    the bend reader, scaled by root.Knee_Slide (0 = off, 1 = default)."""
    rule = data.rules().get("knee_slide")
    if not rule or base != rule["joint"] or not knee_slide_on():
        return
    from . import correctives
    thigh = cmds.listRelatives(calf, parent=True, type="joint")[0]
    if not cmds.attributeQuery("Knee_Slide", node="root", exists=True):
        cmds.addAttr("root", longName="Knee_Slide", attributeType="double", min=0, max=2,
                     defaultValue=1, keyable=True)
    tag = "{}_{}_kneeSlide".format(config.SKEL_UTIL, calf)
    across = mathx.axis(mathx.world(calf), 0)                    # the knee's bend axis
    amount = correctives._bend(tag, thigh, calf, across, rule.get("angle", 150),
                               rule.get("start", 90))
    scaled = nodes.mult(tag + "_scaled")
    cmds.connectAttr(amount, scaled + ".input1")
    cmds.connectAttr("root.Knee_Slide", scaled + ".input2")
    shin = cmds.getAttr(foot + ".translate")[0]                   # calf-local, rest
    length = sum(v * v for v in shin) ** 0.5
    if length < 1e-6:
        return
    unit = [v / length for v in shin]
    t1 = 1.0 / (len(twists) + 1)
    for i, tw in enumerate(twists, 1):
        t = i / float(len(twists) + 1)
        push = rule.get("slide", 0.08) * length * (1 - t) / (1 - t1)   # top = most
        md = cmds.createNode("multiplyDivide", name="{}_{}_push".format(tag, i))
        for ax in "XYZ":
            cmds.connectAttr(scaled + ".output", md + ".input1" + ax)
        cmds.setAttr(md + ".input2", *[u * push for u in unit])
        add = cmds.createNode("plusMinusAverage", name="{}_{}_pos".format(tag, i))
        src = cmds.listConnections(tw + ".translate", source=True, destination=False,
                                   plugs=True)[0]               # the stretch slide
        cmds.connectAttr(src, add + ".input3D[0]")
        cmds.connectAttr(md + ".output", add + ".input3D[1]")
        cmds.connectAttr(add + ".output3D", tw + ".translate", force=True)
