"""Automatic corrective shapes - pure numpy, no Maya (testable anywhere).

Linear skinning can't keep a deep bend's shape: past ~90 degrees the flesh behind a knee
or elbow passes through itself and the outside of the joint loses its volume (the "boxy"
knee goes round). For one posed sample of one hinge this works out, from the mesh itself:

  contact   the two sides of the bend meet on the joint's bisecting plane (the plane
            through the joint, between the two bones). On the inner side of the bend,
            flesh that crossed that plane is pressed back onto it, and flesh close to it
            is eased so the two sides flatten against each other like real tissue
  volume    on the outer side, every vertex is pushed back out to the distance it had
            from the bend axis at rest (LBS pulls it in): the corners stay square
  smooth    the correction is relaxed with the mesh neighbours and faded out with
            distance from the joint (measured in joint radii)

All sizes are this joint's own flesh radius, measured on the mesh.
"""
import numpy as np


def smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def skin_matrices(W, pre, world):
    """Per-vertex skinning matrices  S_v = sum_i w_vi (bindPre_i x world_i)  (row
    vectors, like Maya). W (N, M), pre / world (M, 4, 4). Only the rows needed."""
    J = np.einsum("mij,mjk->mik", pre, world)
    return np.einsum("nm,mij->nij", W, J)


def to_rest(delta, S):
    """World-space offsets of skinned vertices -> offsets before skinning (blend shape):
    d_world = d_rest x S[:3, :3]  ->  d_rest = d_world x inverse(S[:3, :3])."""
    inv = np.linalg.inv(S[:, :3, :3])
    return np.einsum("ni,nij->nj", delta, inv)


def joint_radius(V_rest, C, side, lo=0.25, hi=0.75):
    """Flesh radius at a joint: median distance from the joint of the vertices that are
    shared between its two sides (the ring the bend happens in)."""
    m = (side > lo) & (side < hi)
    if m.sum() < 8:
        m = (side > 0.05) & (side < 0.95)
    if not m.any():
        return None
    return float(np.median(np.linalg.norm(V_rest[m] - C, axis=1)))


def hinge_fix(V_rest, P, side, region, C_rest, C, axis, d1, d2, radius, edges=None,
              contact=0.12, reach=2.6):
    """Corrected posed points for one bent hinge.

    V_rest (N, 3) rest points, P (N, 3) posed (LBS) points
    side   (N,) 0 = parent side .. 1 = child side (the child limb's share of weight)
    region (N,) bool - vertices that belong to these two bones at all
    C_rest / C the joint at rest / posed     axis  the bend axis (world, unit)
    d1     parent bone direction (towards the joint), d2 child bone direction (posed)
    radius the joint's flesh radius
    Returns (P_fixed, moved) with moved = vertices that changed."""
    axis = axis / np.linalg.norm(axis)
    n = d1 + d2
    if np.linalg.norm(n) < 1e-6:
        return P.copy(), np.zeros(len(P), bool)
    n = n / np.linalg.norm(n)                       # parent side < 0 < child side
    out = P.copy()
    near = region & (np.linalg.norm(P - C, axis=1) < 1.5 * reach * radius)
    if not near.any():
        return out, np.zeros(len(P), bool)
    idx = np.where(near)[0]
    p = P[idx] - C
    sgn = np.where(side[idx] >= 0.5, 1.0, -1.0)
    own = (p @ n) * sgn                             # >0 = on its own side of the plane
    # the crease is the wedge BETWEEN the two sides of the bend (from the parent's mass,
    # -d1, round to the child, d2) plus a margin - not a whole half-space (overhead, the
    # stretched armpit would count as crease and never get its volume back)
    u = -d1 - axis * float(-d1 @ axis)
    u = u / max(np.linalg.norm(u), 1e-9)
    wv = np.cross(axis, u)
    a2 = np.arctan2(float(d2 @ wv), float(d2 @ u))
    ang = np.arctan2(p @ wv, p @ u)
    margin = np.radians(25.0)
    lo_a, hi_a = min(0.0, a2) - margin, max(0.0, a2) + margin
    crease = (ang > lo_a) & (ang < hi_a)
    # contact: below m, ease to the plane; past it (crossed) pressed onto it
    m = contact * radius
    eased = np.where(own >= m, own,
                     np.where(own > -m, 0.5 * m + 0.5 * own, 0.0))
    eased = np.maximum(eased, 0.0)
    fix = np.zeros_like(p)
    c = crease & (eased != own)
    fix[c] = (n[None, :] * ((eased - own) * sgn)[:, None])[c]
    # volume: outer side back out to its rest distance from the bend axis
    q0 = V_rest[idx] - C_rest
    r0 = np.linalg.norm(q0 - np.outer(q0 @ axis, axis), axis=1)
    radial = p - np.outer(p @ axis, axis)
    r1 = np.linalg.norm(radial, axis=1)
    lost = (~crease) & (r1 < r0) & (r1 > 1e-6)
    fix[lost] += (radial[lost] / r1[lost, None]) * (r0[lost] - r1[lost])[:, None]
    # fade out with distance from the joint
    d = np.linalg.norm(p, axis=1)
    fix *= (1.0 - smoothstep((d - reach * radius) / (0.5 * reach * radius)))[:, None]
    delta = np.zeros_like(P)
    delta[idx] = fix
    if edges is not None:
        i, k = edges
        deg = np.maximum(np.bincount(i, minlength=len(P)), 1).astype(float)
        zone = np.zeros(len(P), bool)
        zone[idx] = True
        for _ in range(3):
            acc = np.zeros_like(delta)
            np.add.at(acc, i, delta[k])
            avg = acc / deg[:, None]
            delta[zone] = 0.5 * delta[zone] + 0.5 * avg[zone]
    out = P + delta
    return out, np.linalg.norm(delta, axis=1) > 1e-6 * max(radius, 1e-6)


def breath_shapes(V, rib, belly, a, b, up=(0, 1, 0), fwd=(0, 0, 1),
                  expand=0.06, front=0.6, lift=0.05, belly_out=0.08):
    """Breathing, measured on the mesh (no posing - rest space directly).

    V      (N, 3) rest points       rib / belly  (N,) how much each vertex belongs to the
                                    ribcage / the belly (from the skin weights, 0-1)
    a, b   the ribcage's axis (lower and upper chest joints)
    Inhale (ribcage): every vertex moves out from the ribcage axis by `expand` of its own
    distance from it (so it SCALES the chest, whatever its size), the front (sternum) a
    further `front` x more, and the whole ribcage lifts by `lift` x the chest's measured
    radius. Belly: forward-facing belly flesh pushes out by `belly_out` of its distance from
    the axis. Returns (ribcage delta, belly delta), (N, 3) each."""
    V = np.asarray(V, float)
    a, b = np.asarray(a, float), np.asarray(b, float)
    up, fwd = np.asarray(up, float), np.asarray(fwd, float)
    ax = b - a
    ax = ax / max(np.linalg.norm(ax), 1e-9)
    q = V - a
    radial = q - np.outer(q @ ax, ax)
    dist = np.linalg.norm(radial, axis=1)
    unit = radial / np.maximum(dist, 1e-9)[:, None]
    facing = np.clip(unit @ fwd, 0.0, 1.0)
    m = rib > 0.5
    R = float(np.median(dist[m])) if m.any() else float(np.median(dist))
    rib_d = (radial * (expand * (1.0 + front * facing))[:, None] +
             up[None, :] * (lift * R)) * rib[:, None]
    belly_d = radial * (belly_out * facing * facing)[:, None] * belly[:, None]
    return rib_d, belly_d
