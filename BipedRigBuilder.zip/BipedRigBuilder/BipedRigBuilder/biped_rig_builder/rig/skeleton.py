"""Stage 2 - joints exactly as the guides show them."""
import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes, template
from .guides import Guides

ROOT = "root"
KNEE_SLIDE_FLAG = "brb_knee_slide"


HELPER_DEPTH = 0.85                # chest helpers sit 85% of the way to the skin


def helper_spot(helper, s, rays=None):
    """Where a chest helper goes on THIS body, and how much bigger / smaller the body is
    there than the template assumed (scales its push).
    The template offset (fraction of height from the shoulder) only gives a DIRECTION:
    from the ribcage's centre line at that height a ray finds the skin, and the helper
    sits HELPER_DEPTH of the way there - so a hulk's pec sits in a hulk's chest and a
    baby's in a baby's. Returns (position, scale)."""
    r, h = data.rules(), Skeleton.height()
    sign = 1 if s == "l" else -1
    origin = mathx.pos(names.for_side(r["helper_origin"], s))
    ox, oy, oz = helper["pos"]
    target = origin + om.MVector(ox * sign, oy, oz) * h
    axis_pt = mathx.pos(r["helper_parent"])
    axis_pt = om.MVector(0.0, target.y, axis_pt.z)
    d = target - axis_pt
    if d.length() < 1e-6:
        return target, 1.0
    if rays is None:
        meshes = Guides.meshes()
        rays = meshes.rays() if meshes else None
    hit = rays.hit(axis_pt, d.normal(), h * 0.5) if rays else None
    if not hit:
        return target, 1.0
    return axis_pt + d.normal() * (hit * HELPER_DEPTH), hit * HELPER_DEPTH / d.length()


class Skeleton(object):
    def __init__(self):
        self.tpl = template.get()

    @staticmethod
    def exists():
        return cmds.objExists(ROOT)

    @staticmethod
    def joints(long=False):
        return cmds.ls(ROOT, dag=True, type="joint", long=long) or []

    @staticmethod
    def height():
        """Character height, measured head -> root and scaled like the template mesh."""
        return (mathx.pos("head").y - mathx.pos(ROOT).y) * template.get().height / 149.383

    def build(self, helpers=True, correctives=False):
        guides = Guides()
        if not guides.exist():
            cmds.error("No guides - press Create Guides first.")
        clash = [n for n in self.tpl.names + self.helper_names() if cmds.objExists(n)]
        if clash:
            cmds.error("Already in the scene: {} ... Build in a scene with just the mesh "
                       "(or delete/rename the old skeleton).".format(", ".join(clash[:5])))
        guides.refresh_orient()                      # always the current orientation rules
        pos, axes = guides.positions(), guides.orientations()
        self._check_facing(pos)
        world = [om.MVector(1, 0, 0), om.MVector(0, 1, 0), om.MVector(0, 0, 1)]
        axes.update({n: list(world) for n in self.tpl.world})   # head, pelvis, feet...
        self._planar_limbs(pos, axes)
        ys = [p.y for p in pos.values()]
        radius = max((max(ys) - min(ys)) / 45.0, 0.1)      # readable at any scale
        with nodes.undo_chunk():
            made = {}
            for n in self.tpl.names:
                j = made[n] = cmds.createNode("joint", name=n)
                cmds.setAttr(j + ".rotateOrder", self.tpl.rotate_order(n))
                cmds.setAttr(j + ".radius", radius * (0.5 if self.tpl.is_finger(n) else 1.0))
                cmds.xform(j, ws=True, matrix=mathx.flat(mathx.compose(*axes[n] + [pos[n]])))
            for n, p, _ in self.tpl.joints:
                if p in made:
                    cmds.parent(made[n], made[p])
            cmds.makeIdentity(ROOT, apply=True, rotate=True, scale=True)  # rotate -> jointOrient
            self._straighten()
            self._twist_joints(pos, radius)
            for chain in self.tpl.mirror:
                cmds.mirrorJoint(chain, mirrorYZ=True, mirrorBehavior=True,
                                 searchReplace=("_l", "_r"))
            if helpers:
                self._helpers()
            if correctives:                          # optional, experimental
                from . import correctives as cor, muscles
                meshes = Guides.meshes()
                rays = meshes.rays() if meshes else None
                cor.create(self.height(), rays)          # wrist / ankle / kneecap
                nodes.add_string(ROOT, KNEE_SLIDE_FLAG, "1")  # calf skin slides at deep bends
                muscles.create(self.height(), rays)      # volume muscles
            self.store_rest()
            guides.show(False)
            cmds.select(ROOT)
        print("Built {} joints. Guides hidden (Show Guides to adjust).".format(
            len(self.joints())))

    def _straighten(self):
        """Head, pelvis, root (and the left foot/ball) oriented exactly like the world -
        the same as unparent / orient to world / reparent: rotate = 0 and the parent's
        rotation cancelled in jointOrient."""
        for n in self.tpl.world:
            if not cmds.objExists(n):
                continue
            pinv = om.MTransformationMatrix(
                om.MMatrix(cmds.getAttr(n + ".parentInverseMatrix[0]")))
            e = pinv.rotation()                      # jointOrient is always XYZ
            cmds.setAttr(n + ".rotate", 0, 0, 0)
            cmds.setAttr(n + ".jointOrient", *[om.MAngle(v).asDegrees() for v in (e.x, e.y, e.z)])

    REST_ATTR = "brb_rest"

    @classmethod
    def store_rest(cls):
        """Remember every joint's translate/rotate exactly as Build Skeleton made it."""
        rest = {j: [cmds.getAttr(j + ".translate")[0], cmds.getAttr(j + ".rotate")[0]]
                for j in cls.joints()}
        nodes.add_string(ROOT, cls.REST_ATTR, repr(rest))

    @classmethod
    def rest_pose(cls):
        """Back to the pose Build Skeleton made (skips channels a driver owns)."""
        import ast
        text = nodes.get_string(ROOT, cls.REST_ATTR)
        if not text:
            return
        for j, (t, r) in ast.literal_eval(text).items():
            if not cmds.objExists(j):
                continue
            for attr, value in (("translate", t), ("rotate", r), ("scale", (1, 1, 1))):
                for ax, v in zip("XYZ", value):
                    plug = "{}.{}{}".format(j, attr, ax)
                    if cmds.getAttr(plug, settable=True):
                        cmds.setAttr(plug, v)

    @staticmethod
    def helper_names():
        from . import correctives, muscles
        return [names.for_side(h["name"], s) for h in data.rules()["helpers"]
                for s in "lr"] + correctives.joint_names() + muscles.joint_names()

    def add_helpers(self):
        """Chest helpers on an existing skeleton (skips the ones already there)."""
        return self._helpers()

    def _helpers(self):
        """Chest correctives (pec, lat, chest) under the ribcage joint, oriented like it.
        They take skin weight; the drivers make pec/lat follow the arm and push all three
        out to keep the chest's volume (see Deformation._helpers)."""
        r, h = data.rules(), self.height()
        made = []
        for helper in r["helpers"]:
            for s, sign in (("l", 1), ("r", -1)):
                name = names.for_side(helper["name"], s)
                if cmds.objExists(name):
                    continue
                j = cmds.createNode("joint", name=name, parent=r["helper_parent"])
                made.append(j)
                cmds.xform(j, ws=True, translation=tuple(helper_spot(helper, s)[0]))
                cmds.setAttr(j + ".jointOrient", 0, 0, 0)
                cmds.setAttr(j + ".radius", h / 40.0)
                cmds.setAttr(j + ".overrideEnabled", 1)
                cmds.setAttr(j + ".overrideColor", config.HELPER_COLOR)
        if made:
            self.store_rest()                    # Build Rig resets to rest: include them
        return made

    def _planar_limbs(self, pos, axes):
        """Leg and arm joint orientation rule (joints stay exactly on the guides):
            Y  down the bone (toward the child joint)
            Z  secondary axis = world +Z (forward), made perpendicular to Y
            X  = Y x Z  (the bend axis)
        Right side is mirrored from the left (behaviour) afterwards."""
        fwd = om.MVector(0, 0, 1)
        for a, b, c, sign in self.tpl.limbs:
            facing = self._knee_on_foot_plane(pos, a, b, c) if sign > 0 else None
            if facing is not None:
                # legs: the knee bends the way the foot points (snapped onto that plane
                # above), so a crouch folds the knees over the toes - never inward
                self._pre_bend(pos, a, b, c, facing)
                for j, tgt in ((a, b), (b, c)):
                    y = (pos[tgt] - pos[j]).normal()
                    z = (facing - y * (facing * y)).normal()
                    axes[j] = [y ^ z, y, z]
                continue
            self._pre_bend(pos, a, b, c, fwd * sign)
            # the limb's OWN bend plane: if the model's knee / elbow is clearly bent (a
            # crouched, splayed or relaxed base pose), Z follows the real bend direction,
            # so X - the hinge - is square to how the limb actually folds and the IK
            # bends in that same plane (no pop / twist at Build Rig). Nearly straight:
            # world forward, as before.
            line = (pos[c] - pos[a]).normal()
            off = (pos[b] - pos[a]) - line * ((pos[b] - pos[a]) * line)
            limb = (pos[b] - pos[a]).length() + (pos[c] - pos[b]).length()
            ref = off.normal() * sign if off.length() > 0.02 * limb else fwd
            for j, tgt in ((a, b), (b, c)):
                y = (pos[tgt] - pos[j]).normal()
                z = ref - y * (ref * y)
                if z.length() < 1e-4:                  # bone pointing straight forward
                    z = om.MVector(0, 1, 0) - y * y.y
                z = z.normal()
                axes[j] = [y ^ z, y, z]

    def _check_facing(self, pos):
        """RULE: the character faces +Z, its left on +X (Maya / UE5 convention). Foot guides
        pointing -Z mean a character turned round - every _l / _r would come out swapped."""
        for a, b, c, sign in self.tpl.limbs:
            toe = self.tpl.first_child(c)
            if sign > 0 and toe in pos and (pos[toe] - pos[c]).z < 0:
                cmds.error(config.FACING_MSG)

    def _knee_on_foot_plane(self, pos, a, b, c):
        """The leg's bend plane = the hip->ankle line + the foot's forward direction
        (ankle -> ball, flat on the ground). The knee guide is moved onto that plane (only
        sideways - printed), so knee, foot and pole vector all agree. Returns the forward
        direction across the leg, or None if the foot has no usable direction."""
        toe = self.tpl.first_child(c)
        if toe not in pos:
            return None
        foot = pos[toe] - pos[c]
        foot = om.MVector(foot.x, 0.0, foot.z)
        line = (pos[c] - pos[a]).normal()
        facing = foot - line * (foot * line)
        if facing.length() < 1e-4 or facing.z <= 0:       # no usable / backwards foot
            return None
        facing.normalize()
        n = (line ^ facing).normal()
        side = (pos[b] - pos[a]) * n
        if abs(side) > 1e-4:
            new = pos[b] - n * side
            Guides.move(b, new)
            print("  {} moved {:.2f} units sideways onto the foot's bend plane".format(
                b, abs(side)))
            pos[b] = new
        return facing

    PRE_BEND = 0.015                 # min knee / elbow bend, fraction of limb length

    @classmethod
    def _pre_bend(cls, pos, a, b, c, toward):
        """RULE: a knee must already bend forward (an elbow back) a little at build time.
        Maya's IK solver takes its bend side from the joints; a dead straight or slightly
        hyper-extended knee lets it bend the IK chain AWAY from the pole vector - the
        'inverted pole vector'. If the guide is straighter than 1.5% of the limb length
        the knee / elbow is nudged that way (its guide moves too, and it's printed)."""
        line = (pos[c] - pos[a]).normal()
        out = toward - line * (toward * line)
        if out.length() < 1e-6:
            return
        out.normalize()
        bend = (pos[b] - pos[a]) * out
        need = cls.PRE_BEND * ((pos[b] - pos[a]).length() + (pos[c] - pos[b]).length())
        if bend < need:
            new = pos[b] + out * (need - bend)
            Guides.move(b, new)
            print("  {} nudged {:.2f} units to pre-bend the limb for IK".format(
                b, need - bend))
            pos[b] = new

    def _twist_joints(self, pos, radius):
        """Evenly spaced along the bone, oriented like their parent, drawn bigger."""
        for jn, count in self.tpl.twist.items():
            end = self.tpl.first_child(jn)
            for i in range(1, count + 1):
                p = pos[jn] + (pos[end] - pos[jn]) * (i / float(count + 1))
                sfx = "_" + names.side(jn) if names.side(jn) != "c" else ""
                tw = cmds.createNode("joint", parent=jn, name="{}_twist_{:02d}{}".format(
                    names.base(jn), i, sfx))
                cmds.setAttr(tw + ".rotateOrder", cmds.getAttr(jn + ".rotateOrder"))
                # bigger than the limb joints + own colour, so they're easy to see / pick
                cmds.setAttr(tw + ".radius", radius * config.TWIST_RADIUS)
                cmds.setAttr(tw + ".overrideEnabled", 1)
                cmds.setAttr(tw + ".overrideColor", config.TWIST_COLOR)
                cmds.xform(tw, ws=True, translation=(p.x, p.y, p.z))
                cmds.setAttr(tw + ".jointOrient", 0, 0, 0)
                cmds.setAttr(tw + ".rotate", 0, 0, 0)

    def delete(self):
        from .preview import PreviewRig          # rig and skin must go first
        from .deform import Deformation
        PreviewRig().remove()
        Deformation().unbind()
        Deformation().remove_drivers()
        if self.exists():
            cmds.delete(ROOT)
        Guides().show(True)
        print("Skeleton deleted, guides back - adjust and Build / Preview again.")
