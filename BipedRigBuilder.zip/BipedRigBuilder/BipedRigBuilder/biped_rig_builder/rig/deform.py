"""Stage 2b - skin and test it, before any controls exist.

Skin Mesh      twist joints + chest correctives start working, the mesh gets skinned
Test Poses     a range-of-motion animation on the bind joints to check the weights
Mirror Weights left -> right
Unbind         back to a clean skeleton (materials kept)
Skin data lives on the root joint, so Build Rig / Remove Rig never touch it.
"""
import json
import math

import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes
from ..core.mesh import MeshSet
from . import correctives, muscles, skin, twist
from .guides import Guides
from .skeleton import ROOT, Skeleton

HELPER_SUFFIX = "_skel_pointConstraint"
UP, DOWN, FWD, BACK = (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)
OUT = "out"                       # +X on the left, -X on the right
# range of motion: (joint, direction the bone's tip should move, degrees from the bind
# pose). Real human limits, measured from an A-pose - extreme but reachable, no
# self-intersection by design.
# shoulder rhythm: the clavicle goes with the arm (about 1 degree per 4 of the arm)
CLAV = "clavicle_l"
ROM = [("upperarm_l", UP, 115, [(CLAV, UP, 28)]), ("upperarm_l", DOWN, 25, [(CLAV, DOWN, 5)]),
       ("upperarm_l", FWD, 100, [(CLAV, FWD, 18)]), ("upperarm_l", BACK, 45, [(CLAV, BACK, 12)]),
       ("upperarm_l", "twist", 60), ("lowerarm_l", FWD, 135),
       ("hand_l", UP, 70), ("hand_l", DOWN, 75), ("hand_l", OUT, 25), ("hand_l", "twist", 70),
       ("thigh_l", FWD, 100), ("thigh_l", BACK, 25), ("thigh_l", OUT, 45),
       ("thigh_l", "twist", 35), ("calf_l", BACK, 135), ("foot_l", UP, 20),
       ("foot_l", DOWN, 45), ("foot_l", OUT, 20),
       ("spine_03", FWD, 35), ("spine_03", BACK, 20), ("spine_03", OUT, 25),
       ("spine_03", "twist", 35), ("neck_01", FWD, 40), ("neck_01", "twist", 60)]
STEP = 10                         # frames per half-pose


ARM_KEYS = {"up": (0, 1, 0), "down": (0, -1, 0), "fwd": (0, 0, 1)}


def _arm_reader(s, key, ref):
    """0 -> 1: how far the upper arm points `key` (up / down / fwd), from its rest
    direction (0) to fully that way (1), read in the chest's space (so bending the
    spine doesn't count). Eased, clamped - can't flip."""
    arm = names.for_side("upperarm_l", s)
    kids = [k for k in cmds.listRelatives(arm, children=True, type="joint") or []
            if "twist" not in k and not k.endswith("_hlp")]
    if not kids or not cmds.objExists(ref):
        return None
    tag = "{}_{}_arm_{}".format(config.SKEL_UTIL, s, key)
    bone_world = (mathx.pos(kids[0]) - mathx.pos(arm)).normal()
    bone_local = bone_world * mathx.world(arm).inverse()
    ref_inv = mathx.world(ref).inverse()
    key_local = (om.MVector(*ARM_KEYS[key]) * ref_inv).normal()
    rest = (bone_world * ref_inv).normal() * key_local
    if rest > 0.95:
        return None
    mm = cmds.createNode("multMatrix", name=tag + "_mm")
    cmds.connectAttr(arm + ".worldMatrix[0]", mm + ".matrixIn[0]")
    cmds.connectAttr(ref + ".worldInverseMatrix[0]", mm + ".matrixIn[1]")
    vp = cmds.createNode("vectorProduct", name=tag + "_dir")
    cmds.setAttr(vp + ".operation", 3)                      # vector x matrix
    cmds.setAttr(vp + ".normalizeOutput", 1)
    cmds.setAttr(vp + ".input1", bone_local.x, bone_local.y, bone_local.z)
    cmds.connectAttr(mm + ".matrixSum", vp + ".matrix")
    dot = cmds.createNode("vectorProduct", name=tag + "_dot")
    cmds.setAttr(dot + ".operation", 1)                     # dot product
    cmds.connectAttr(vp + ".output", dot + ".input1")
    cmds.setAttr(dot + ".input2", key_local.x, key_local.y, key_local.z)
    rm = cmds.createNode("remapValue", name=tag + "_amount")
    cmds.connectAttr(dot + ".outputX", rm + ".inputValue")
    cmds.setAttr(rm + ".inputMin", rest)
    cmds.setAttr(rm + ".inputMax", 1.0)
    for i in (0, 1):                                        # ease in / out
        cmds.setAttr("{}.value[{}].value_Interp".format(rm, i), 2)
    return rm + ".outValue"


HELPER_KEYS = (("up", "Arm up"), ("fwd", "Arm forward"), ("down", "Arm down"))


def helper_move_attrs(j, key, default=(0, 0, 0)):
    """<Key>_X / _Y / _Z on a chest helper: how far it moves (X out, Y up, Z forward,
    scene units) when the arm is fully up / forward / down. Hidden from the Channel Box,
    kept across rebuilds."""
    attrs = ["{}_{}".format(key.capitalize(), c) for c in "XYZ"]
    for attr, v in zip(attrs, default):
        if not cmds.attributeQuery(attr, node=j, exists=True):
            cmds.addAttr(j, longName=attr, attributeType="double", defaultValue=v)
            cmds.setAttr(j + "." + attr, v)
    return attrs


def _store(attr, value):
    nodes.add_string(ROOT, attr, value)


def _read(attr):
    return nodes.get_string(ROOT, attr)


class Deformation(object):
    # ---------------------------------------------------------------- state
    @staticmethod
    def skins():
        return [s for s in _read("skins").split(";") if s and cmds.objExists(s)]

    @staticmethod
    def bind_joints():
        return [j for j in Skeleton.joints() if "twist" not in j and not j.endswith("_hlp")]

    # ---------------------------------------------------------------- drivers
    REV_ATTR = "brb_driver_rev"

    def ensure_drivers(self):
        """Twist joints + chest helper follow (skeleton-level, needed by skin and rig).
        Drivers from an older version of the tool are rebuilt (twist measured round the
        limb, chest volume) - the skin is never touched."""
        if not Skeleton.exists():
            return
        if cmds.ls(config.SKEL_UTIL + "_*"):
            if _read(self.REV_ATTR) == config.DRIVER_REV:
                return
            print("Skeleton drivers are from an older build - rebuilding them.")
            self.remove_drivers()
        with nodes.undo_chunk():
            before = nodes.snapshot()
            print("Twist joints driven: {}".format(len(twist.drive_twists())))
            print("Chest helpers (volume) driven: {}".format(self._helpers()))
            print("Corrective joints driven: {}".format(
                correctives.drive(Skeleton.height())))
            print("Muscle (volume) joints driven: {}".format(muscles.drive()))
            _store(self.REV_ATTR, config.DRIVER_REV)
            nodes.quiet_new(before)

    @staticmethod
    def _helpers():
        """Chest volume helpers (pec / lat / chest, left + right):
          follow   pec / lat sit between a point on the ribcage and a point riding on the
                   upper arm (weights in rig_rules > helpers), so the arm pulls them
          volume   on top, each helper is PUSHED by how far the arm is raised / swung
                   forward / dropped (helpers[].push, fractions of height, left side:
                   x = out, y = up, z = forward). Arm direction is read in the chest's
                   space and eased 0 -> 1 from the rest pose to fully there, so the
                   chest / armpit keeps its volume instead of caving in.
          root.Chest_Volume scales every push (0 = off, 1 = default, 2 = double)."""
        r, made, height = data.rules(), 0, Skeleton.height()
        ref = r.get("helper_reference", "spine_05")
        if any(cmds.objExists(names.for_side(h["name"], s)) for h in r["helpers"]
               for s in "lr") and not cmds.attributeQuery("Chest_Volume", node=ROOT,
                                                          exists=True):
            cmds.addAttr(ROOT, longName="Chest_Volume", attributeType="double", min=0,
                         max=2, defaultValue=1, keyable=True)
        readers = {}
        for h in r["helpers"]:
            for s, sign in (("l", 1), ("r", -1)):
                j, arm = names.for_side(h["name"], s), names.for_side(r["helper_origin"], s)
                if not cmds.objExists(j) or not cmds.objExists(arm):
                    continue
                parent = (cmds.listRelatives(j, parent=True) or [r["helper_parent"]])[0]
                base = cmds.createNode("transform", name=j + "_base", parent=parent)
                cmds.xform(base, ws=True, translation=tuple(mathx.pos(j)))
                if "anchor" in h:
                    ax, ay, az = h["anchor"]
                    anchor = cmds.createNode("transform", name=j + "_anchor", parent=parent)
                    cmds.xform(anchor, ws=True, translation=tuple(
                        mathx.pos(arm) + om.MVector(ax * sign, ay, az) * height))
                    # arm side: a point riding on the upper arm at the helper's own spot,
                    # so arm ROTATION (raise / swing forward) pulls the pec/lat, not just
                    # the shoulder moving
                    arm_anchor = cmds.createNode("transform", name=j + "_arm_anchor",
                                                 parent=arm)
                    cmds.xform(arm_anchor, ws=True, translation=tuple(mathx.pos(j)))
                    con = cmds.pointConstraint(anchor, arm_anchor, base, maintainOffset=True,
                                               name=j + HELPER_SUFFIX)[0]
                    for alias, w in zip(cmds.pointConstraint(con, q=True,
                                                             weightAliasList=True),
                                        h["weights"]):
                        cmds.setAttr(con + "." + alias, w)
                total = cmds.createNode("plusMinusAverage", name="{}_{}_volume".format(
                    config.SKEL_UTIL, j))
                cmds.connectAttr(base + ".translate", total + ".input3D[0]")
                inv = mathx.world(parent).inverse()
                # pushes were written for the template body: scale them by how far this
                # body's skin is from its ribcage there (measured, see helper_spot)
                from .skeleton import helper_spot
                scale = helper_spot(h, s)[1]
                k = 1
                for key, vec in sorted((h.get("push") or {}).items()):
                    amount = readers.get((s, key))
                    if amount is None:
                        amount = readers[(s, key)] = _arm_reader(s, key, ref)
                    if amount is None:
                        continue
                    # the move at full pose lives on the helper (X out, Y up, Z forward -
                    # same numbers both sides), editable in the Correctives tab
                    attrs = helper_move_attrs(j, key, [c * height * scale for c in vec])
                    flip = cmds.createNode("multiplyDivide", name="{}_{}_{}_side".format(
                        config.SKEL_UTIL, j, key))
                    for c, attr in zip("XYZ", attrs):
                        cmds.connectAttr(j + "." + attr, flip + ".input1" + c)
                    cmds.setAttr(flip + ".input2", sign, 1, 1)
                    to_local = cmds.createNode("vectorProduct", name="{}_{}_{}_local".format(
                        config.SKEL_UTIL, j, key))
                    cmds.setAttr(to_local + ".operation", 3)          # vector x matrix
                    cmds.connectAttr(flip + ".output", to_local + ".input1")
                    cmds.setAttr(to_local + ".matrix", *mathx.flat(inv), type="matrix")
                    md = cmds.createNode("multiplyDivide", name="{}_{}_{}_push".format(
                        config.SKEL_UTIL, j, key))
                    for a in "XYZ":
                        cmds.connectAttr(amount, md + ".input1" + a)
                    cmds.connectAttr(to_local + ".output", md + ".input2")
                    vol = cmds.createNode("multiplyDivide", name="{}_{}_{}_vol".format(
                        config.SKEL_UTIL, j, key))
                    cmds.connectAttr(md + ".output", vol + ".input1")
                    for a in "XYZ":
                        cmds.connectAttr(ROOT + ".Chest_Volume", vol + ".input2" + a)
                    cmds.connectAttr(vol + ".output", "{}.input3D[{}]".format(total, k))
                    k += 1
                cmds.connectAttr(total + ".output3D", j + ".translate", force=True)
                made += 1
        return made

    def remove_drivers(self):
        nodes.delete(config.SKEL_UTIL + "_*", "*" + HELPER_SUFFIX + "*", "*_hlp_anchor",
                     "*_hlp_arm_anchor", "*_hlp_base",
                     *(correctives.delete_patterns() + muscles.delete_patterns()))
        muscles.reset()
        for j in Skeleton.joints():
            if "twist" in j:
                cmds.setAttr(j + ".rotate", 0, 0, 0)
        Skeleton.rest_pose()                    # helpers/twists back where they were built
        _store(self.REV_ATTR, "")

    # ---------------------------------------------------------------- upgrades
    def repair_weights(self):
        """Fix an existing skin in place (no unbind): limb ownership + twist spread, clean
        head / neck. Needs the rest pose, so not while a rig is built."""
        from .preview import PreviewRig
        if PreviewRig.exists():
            cmds.error("Remove Rig first (the skin is kept) - Repair works in the rest pose.")
        skins = self.skins()
        if not skins:
            cmds.error("Skin the mesh first.")
        self.clear_test()
        cmds.currentTime(0)
        with nodes.undo_chunk():
            skin.repair(skins)
        print("Weights repaired on {} skin(s): upper arm / thigh no longer owned by the "
              "forearm / calf, twist spread re-done, head + neck cleaned.".format(len(skins)))

    def add_chest_helpers(self):
        """Adds the chest volume helpers (pec / lat / chest, both sides) to a skeleton that
        was built without them, gives them weight on the existing skin and drives them."""
        if not Skeleton.exists():
            cmds.error("Build the skeleton first.")
        self.clear_test()
        cmds.currentTime(0)
        with nodes.undo_chunk():
            self.remove_drivers()
            made = Skeleton().add_helpers()
            for sc in self.skins():
                shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
                if not shape:
                    continue
                have = set(cmds.skinCluster(sc, q=True, influence=True) or [])
                new = [j for j in (names.for_side(h["name"], s)
                                   for h in data.rules()["helpers"] for s in "lr")
                       if cmds.objExists(j) and j not in have]
                for j in new:
                    skin.label_joint(j)
                    cmds.skinCluster(sc, edit=True, addInfluence=j, weight=0.0,
                                     lockWeights=False)
                skin.helper_patch(sc, shape)
                skin.limit_influences(sc, shape)
            self.ensure_drivers()
        print("Chest helpers: {} added and weighted. Tune the push with root.Chest_Volume "
              "(0-2).".format(len(made)))

    # ---------------------------------------------------------------- skin
    def skin(self, method="heat", shapes=True):
        """One click, finished: bind + the adaptive solve (see skin.py / weightmath.py)
        + corrective shapes for knees, elbows, hips and shoulders (autoshapes.py)."""
        if not Skeleton.exists():
            cmds.error("Build the skeleton first.")
        if self.skins():
            cmds.warning("Already skinned - Unbind first to skin again.")
            return
        meshes = Guides.meshes()
        if not meshes:
            cmds.error("No mesh - create the guides with the character selected.")
        self.clear_test()
        self.ensure_drivers()
        with nodes.undo_chunk():
            for j in Skeleton.joints(long=True):
                skin.label_joint(j)
            _store("mesh", meshes.to_string())
            _store("materials", json.dumps(meshes.materials()))
            meshes.see_through(False)
            made = skin.bind(meshes, method)
            _store("skins", ";".join(made))
        print("Skinned: {}".format(", ".join(made)))
        if shapes and made:
            self.corrective_shapes(made)

    @staticmethod
    def corrective_shapes(skins=None):
        """(Re)build the automatic corrective shapes (rest pose, no rig)."""
        from . import autoshapes
        skins = skins or Deformation.skins()
        try:
            with nodes.undo_chunk():
                before = nodes.snapshot()
                import time
                t0 = time.time()
                n = autoshapes.build(skins, Skeleton.height())
                print("Corrective shapes took {:.1f}s".format(time.time() - t0))
                nodes.quiet_new(before)
            print("Corrective + breathing shapes: {} (knees, elbows, hips, shoulders by "
                  "their bend; Breath / Belly_Breath on root and the chest ctrls).".format(n))
        except Exception as e:
            import traceback
            traceback.print_exc()                  # full trace in the Script Editor
            cmds.warning("Corrective shapes skipped ({})".format(e))

    def unbind(self):
        if not Skeleton.exists():
            return
        self.clear_test()
        with nodes.undo_chunk():
            from . import autoshapes
            autoshapes.remove()
            skin.unbind(self.skins())
            MeshSet.restore_materials(json.loads(_read("materials") or "[]"))
            _store("skins", "")
        print("Unbound - materials restored.")

    def mirror_weights(self):
        """Left -> right, matching joints by their side labels."""
        for sc in self.skins():
            cmds.copySkinWeights(sourceSkin=sc, destinationSkin=sc, mirrorMode="YZ",
                                 mirrorInverse=False, surfaceAssociation="closestPoint",
                                 influenceAssociation=["label", "closestJoint"])
        skin.weld(self.skins(), Skeleton.height())
        print("Weights mirrored left -> right on {} skins.".format(len(self.skins())))
        from . import autoshapes
        if autoshapes.exists():
            from .preview import PreviewRig
            if not PreviewRig.exists():
                self.corrective_shapes()           # the shapes follow the new weights

    # ---------------------------------------------------------------- range of motion
    @staticmethod
    def _axis_for(joint, direction, degrees, side):
        """Which local axis (and sign) moves the bone's tip the requested way."""
        m = mathx.world(joint)
        kids = [k for k in cmds.listRelatives(joint, children=True, type="joint") or []
                if "twist" not in k and not k.endswith("_hlp")]
        tip = (mathx.pos(kids[0]) - mathx.pos(joint)) if kids else mathx.axis(m, 1)
        if direction == OUT:
            direction = (1 if side != "r" else -1, 0, 0)
        want = om.MVector(*direction)
        best = None
        for i, ax in ((0, "X"), (2, "Z")):
            for sign in (1, -1):
                q = om.MQuaternion(math.radians(degrees * sign), mathx.axis(m, i))
                score = (tip.rotateBy(q) - tip) * want
                if best is None or score > best[0]:
                    best = (score, "rotate" + ax, degrees * sign)
        return best[1], best[2]

    @staticmethod
    def test_frames():
        """The extreme frame of every test pose (empty if no test poses are keyed)."""
        joints = Deformation.bind_joints()
        if not any(cmds.keyframe(j, q=True, keyframeCount=True) for j in joints):
            return []
        return [STEP + 2 * STEP * i for i in range(len(ROM))]

    def test_poses(self, report=True):
        from .preview import PreviewRig
        if PreviewRig.exists():
            cmds.warning("Remove Rig first (or pose the controls) - the joints are driven "
                         "by the rig.")
            return
        self.clear_test()
        frame, peaks = 0, []
        with nodes.undo_chunk():
            for pose in ROM:
                joint, direction, degrees = pose[:3]
                moves = [(joint, direction, degrees)] + (list(pose[3]) if len(pose) > 3 else [])
                sides = ("l", "r") if names.side(joint) == "l" else ("c",)
                keys = []
                for s in sides:
                    for jn, dr, deg in moves:
                        j = names.for_side(jn, s)
                        if not cmds.objExists(j):
                            continue
                        if dr == "twist":
                            keys.append((j, "rotateY", deg))
                        else:
                            keys.append((j, ) + self._axis_for(j, dr, deg, s))
                peaks.append((frame + STEP, "{} {} {}".format(
                    joint, direction if isinstance(direction, str) else
                    {UP: "up", DOWN: "down", FWD: "forward", BACK: "back"}[direction],
                    degrees)))
                for j, attr, value in keys:
                    cmds.setKeyframe(j, attribute=attr, time=frame, value=0)
                    cmds.setKeyframe(j, attribute=attr, time=frame + STEP, value=value)
                    cmds.setKeyframe(j, attribute=attr, time=frame + 2 * STEP, value=0)
                frame += 2 * STEP
            cmds.playbackOptions(minTime=0, maxTime=frame)
            cmds.currentTime(0)
        print("Test poses keyed on frames 0-{} - scrub the timeline. Clear Test Poses "
              "when done.".format(frame))
        try:
            if report:
                self.report(peaks)
        except Exception as e:
            cmds.warning("Pose report skipped ({})".format(e))
        cmds.currentTime(0)

    def report(self, peaks):
        """Measures every test pose at its extreme:
          pinched  triangles squashed below 15% of their rest area (folds / collapse)
          volume   for each corrective joint: mean distance from the vertices it owns
                   (weight >= 0.25) to the joint, posed / rest - 100% = volume kept."""
        from .skin import _all_vertices, _dag, _skin_fn
        lines, worst = [], {}
        for sc in self.skins():
            shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
            if not shape:
                continue
            fn, dag = _skin_fn(sc), _dag(shape)
            mesh = om.MFnMesh(dag)
            tris = list(mesh.getTriangles()[1])
            infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
            cmds.currentTime(0)
            rest = mesh.getPoints(om.MSpace.kWorld)
            w, ninf = fn.getWeights(dag, _all_vertices(len(rest)))
            owned = {}
            for i, n in enumerate(infl):
                if n.endswith("_hlp"):
                    vs = [v for v in range(len(rest)) if w[v * ninf + i] >= 0.25]
                    if vs:
                        owned[n] = vs

            def areas(pts):
                return [((om.MVector(pts[tris[k + 1]]) - om.MVector(pts[tris[k]])) ^
                         (om.MVector(pts[tris[k + 2]]) - om.MVector(pts[tris[k]]))).length()
                        for k in range(0, len(tris), 3)]

            def spread(pts, joint, vs):
                c = om.MPoint(mathx.pos(joint))
                return sum(pts[v].distanceTo(c) for v in vs) / len(vs)

            a0 = areas(rest)
            base = {j: spread(rest, j, vs) for j, vs in owned.items()}
            for frame, label in peaks:
                cmds.currentTime(frame)
                pts = mesh.getPoints(om.MSpace.kWorld)
                pinched = sum(1 for x, y in zip(a0, areas(pts)) if x > 1e-8 and y < 0.15 * x)
                lines.append("  {:<28} pinched triangles: {}".format(label, pinched))
                for j, vs in owned.items():
                    r = spread(pts, j, vs) / base[j] if base[j] > 1e-6 else 1.0
                    if j not in worst or abs(1 - r) > abs(1 - worst[j][0]):
                        worst[j] = (r, label)
        cmds.currentTime(0)
        print("\n=== Test pose report ===")
        print("\n".join(lines))
        print("Corrective volume kept at each joint's worst pose (100% = perfect):")
        for j in sorted(worst):
            r, label = worst[j]
            flag = "   <-- check" if abs(1 - r) > 0.15 else ""
            print("  {:<22} {:>4.0f}%  ({}){}".format(j, r * 100, label, flag))

    def clear_test(self):
        joints = self.bind_joints()
        if not joints:
            return
        keyed = [j for j in joints if cmds.keyframe(j, q=True, keyframeCount=True)]
        if keyed:
            cmds.cutKey(keyed, attribute=("rotateX", "rotateY", "rotateZ"), clear=True)
            for j in keyed:
                cmds.setAttr(j + ".rotate", 0, 0, 0)
