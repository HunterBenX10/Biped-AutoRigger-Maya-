"""Skinning: 4 influences, any mesh. Linear weights; the legs / pelvis play back with
dual quaternion (dq_blend) so they keep their volume.

Skin Mesh = one bind (heat map; voxel where heat map can't) + one adaptive solve
(weightmath.solve): ownership by nearest bone, blends across every joint sized by the
flesh measured there, twist spread, smoothing, influence limit. Nothing body-part
specific and no stored reference data: it's all measured on the mesh and the skeleton.
"""

import maya.cmds as cmds
import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

from .. import config
from ..core import data, names
from .skeleton import Skeleton


END = "brbTmpEnd_"                # temporary tip joints, only during the bind


def _dag(node):
    sel = om.MSelectionList()
    sel.add(node)
    return sel.getDagPath(0)


def _skin_fn(sc):
    sel = om.MSelectionList()
    sel.add(sc)
    return oma.MFnSkinCluster(sel.getDependNode(0))


def _all_vertices(count):
    fc = om.MFnSingleIndexedComponent()
    comp = fc.create(om.MFn.kMeshVertComponent)
    fc.setCompleteData(count)
    return comp


def label_joint(j):
    """Side + name labels, so weights can be matched by name between skeletons."""
    n = names.short(j)
    cmds.setAttr(j + ".side", {"c": 0, "l": 1, "r": 2}[names.side(n)])
    cmds.setAttr(j + ".type", 18)
    cmds.setAttr(j + ".otherType", names.base(n), type="string")


def _np_weights(sc, shape):
    """(fn, dag, mesh, comp, W (N, M) numpy, influence names)."""
    import numpy as np
    fn, dag = _skin_fn(sc), _dag(shape)
    mesh = om.MFnMesh(dag)
    comp = _all_vertices(mesh.numVertices)
    w, ninf = fn.getWeights(dag, comp)
    infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
    return fn, dag, mesh, comp, np.array(w).reshape(-1, ninf), infl


def _np_set(fn, dag, comp, W):
    fn.setWeights(dag, comp, om.MIntArray(list(range(W.shape[1]))),
                  om.MDoubleArray(W.ravel().tolist()), False)


def _np_limit(W, max_inf=config.MAX_INFLUENCES, prune=0.01):
    import numpy as np
    W = W.copy()
    if W.shape[1] > max_inf:
        idx = np.argsort(-W, axis=1)[:, max_inf:]
        np.put_along_axis(W, idx, 0.0, axis=1)
    top = W.argmax(1)
    keep_top = W[np.arange(len(W)), top].copy()
    W[W < prune] = 0.0
    W[np.arange(len(W)), top] = keep_top
    return W / np.maximum(W.sum(1, keepdims=True), 1e-12)


def limit_influences(sc, shape, max_inf=config.MAX_INFLUENCES, prune=0.01):
    """Keep the strongest max_inf weights per vertex (>= prune), renormalised."""
    fn, dag, mesh, comp, W, infl = _np_weights(sc, shape)
    _np_set(fn, dag, comp, _np_limit(W, max_inf, prune))


def _shape(transform):
    return (cmds.listRelatives(transform, shapes=True, type="mesh", fullPath=True,
                               noIntermediate=True) or [None])[0]


def _sc_shape(sc):
    return (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]


def _temp_ends(meshes):
    """Heat map / voxel binds treat a leaf joint as a POINT, so everything around it
    (the whole head, finger and toe tips) is under-weighted and bleeds into the parent.
    For the bind only, each leaf gets a temporary child at its tip: the head's reaches
    the top of the skull (ray to the mesh), fingers / toes continue their bone. After
    the bind their weight goes to the leaf joint and they're deleted - the exported
    skeleton is unchanged."""
    from .skeleton import Skeleton as Sk
    rays = meshes.rays() if meshes else None
    h = Sk.height()
    made = []
    for j in Sk.joints(long=True):
        n = names.short(j)
        if n.endswith("_hlp") or "twist" in n:
            continue
        kids = [k for k in cmds.listRelatives(j, children=True, type="joint") or []
                if not k.endswith("_hlp") and "twist" not in k]
        if kids:
            continue
        parent = (cmds.listRelatives(j, parent=True, type="joint") or [None])[0]
        if not parent or n == "root":
            continue
        p, pp = _pos(n), _pos(parent)
        if n == "head":
            up = om.MVector(0, 1, 0)
            d = rays.hit(p, up, h * 0.4) if rays else None
            tip = p + up * ((d or h * 0.11) * 0.9)
        else:
            tip = p + (p - pp) * 0.8
        e = cmds.createNode("joint", name=END + n, parent=j)
        cmds.xform(e, ws=True, translation=(tip.x, tip.y, tip.z))
        made.append(cmds.ls(e, long=True)[0])
    return made


def _drop_ends(skin_clusters, ends):
    if not ends:
        return
    short = [names.short(e) for e in ends]
    for sc in skin_clusters:
        shape = _sc_shape(sc)
        if not shape:
            continue
        fn, dag, mesh, comp, w, ninf, infl = _weights(sc, shape)
        index = {n: i for i, n in enumerate(infl)}
        for e in short:
            if e not in index:
                continue
            leaf = index.get(e[len(END):])
            if leaf is None:
                continue
            ei = index[e]
            for v in range(len(w) // ninf):
                w[v * ninf + leaf] += w[v * ninf + ei]
                w[v * ninf + ei] = 0.0
        _set(fn, dag, comp, w, ninf)
        present = [e for e in short if e in index]
        if present:
            cmds.skinCluster(sc, edit=True, removeInfluence=present)
    cmds.delete([e for e in ends if cmds.objExists(e)])


def _main_pieces(transforms):
    """The body (the piece spanning the character's height) + any piece that isn't ON
    the body (a separate head, a helmet). Clothes, boots, hair on the head copy later."""
    if len(transforms) < 2:
        return list(transforms)

    def score(t):
        bb = cmds.exactWorldBoundingBox(t)
        return (round(bb[4] - bb[1], 1), cmds.polyEvaluate(t, vertex=True))
    body = max(transforms, key=score)
    return [body] + [t for t in transforms if t != body and not _on_body(t, body)]


PROXY_VERTS = 12000        # bodies denser than this bind on a lighter copy (speed)
PROXY_TARGET = 8000


def is_clean(mesh):
    """Manifold, no lamina faces. Maya's heat map bind and polyReduce can CRASH Maya on
    anything else - clothes, shoes and kitbashed meshes are often non-manifold."""
    try:
        bad = (cmds.polyInfo(mesh, nonManifoldEdges=True) or []) + \
            (cmds.polyInfo(mesh, nonManifoldVertices=True) or []) + \
            (cmds.polyInfo(mesh, laminaFaces=True) or [])
    except RuntimeError:
        return False
    return not bad


def _closest_bind(joints, mesh, name):
    return cmds.skinCluster(joints, mesh, toSelectedBones=True, bindMethod=0, skinMethod=0,
                            normalizeWeights=1, maximumInfluences=config.MAX_INFLUENCES,
                            obeyMaxInfluences=True, dropoffRate=4, name=name)[0]


def _heat_or_voxel(mesh, joints, method, name):
    """Heat map bind on clean meshes. A non-manifold mesh (or a heat map failure) gets
    a closest-joint bind instead - never heat map / polyReduce / GPU voxel on it (those
    can crash Maya) - the adaptive solve rebuilds every blend from the geometry anyway.
    Voxel only when asked for (method "smart") and the mesh is clean."""
    if not is_clean(mesh):
        cmds.warning("{} is non-manifold - bound to the closest joints (safe); the solve "
                     "builds its blends.".format(names.short(mesh)))
        return _closest_bind(joints, mesh, name)
    voxel = method == "smart"
    try:
        sc = cmds.skinCluster(joints, mesh, toSelectedBones=True,
                              bindMethod=1 if voxel else 2, skinMethod=0,
                              normalizeWeights=1, maximumInfluences=config.MAX_INFLUENCES,
                              obeyMaxInfluences=True, dropoffRate=4, name=name)[0]
    except RuntimeError as e:                          # heat map refuses the mesh
        cmds.warning("Heat map can't bind {} ({}) - closest joints instead; the solve "
                     "builds its blends.".format(names.short(mesh), e))
        if cmds.ls(cmds.listHistory(mesh) or [], type="skinCluster"):
            cmds.skinCluster(mesh, edit=True, unbind=True)
        return _closest_bind(joints, mesh, name)
    if voxel:
        try:
            cmds.select(mesh)
            cmds.geomBind(sc, bindMethod=3, falloff=0.25,
                          maxInfluences=config.MAX_INFLUENCES,
                          geodesicVoxelParams=(512, True))
        except Exception as e:                           # GPU / mesh issues
            cmds.warning("Voxel bind failed on {} ({}) - closest joint used, the solve "
                         "still runs.".format(mesh, e))
        cmds.select(clear=True)
    return sc


def _bind_main(mesh, joints, method):
    """The body's bind. A dense body is bound on a reduced copy (PROXY_TARGET vertices)
    and the weights copied over by closest point: the bind only has to say roughly which
    bone owns what - the solve then rebuilds every blend on the full-resolution mesh, so
    the result is the same at a fraction of the time (heat map cost grows with vertices)."""
    name = names.short(mesh) + "_preview_skinCluster"
    if cmds.polyEvaluate(mesh, vertex=True) <= PROXY_VERTS or not is_clean(mesh):
        return _heat_or_voxel(mesh, joints, method, name)
    proxy = psc = None
    try:
        proxy = cmds.duplicate(mesh, name=names.short(mesh) + "_brbBindProxy")[0]
        for sh in cmds.listRelatives(proxy, shapes=True, fullPath=True) or []:
            if cmds.getAttr(sh + ".intermediateObject"):
                cmds.delete(sh)
        cmds.polyReduce(proxy, version=1, termination=1, vertexCount=PROXY_TARGET,
                        keepBorder=True, keepQuadsWeight=1.0, replaceOriginal=True,
                        constructionHistory=False)
        psc = _heat_or_voxel(proxy, joints, method, "brbBindProxy_skinCluster")
        sc = cmds.skinCluster(joints, mesh, toSelectedBones=True, bindMethod=0,
                              skinMethod=0, normalizeWeights=1,
                              maximumInfluences=config.MAX_INFLUENCES,
                              obeyMaxInfluences=True, name=name)[0]
        cmds.copySkinWeights(sourceSkin=psc, destinationSkin=sc, noMirror=True,
                             surfaceAssociation="closestPoint",
                             influenceAssociation=["oneToOne"], normalize=True)
        return sc
    except Exception as e:
        cmds.warning("Fast bind on a reduced copy didn't work ({}) - binding the full "
                     "mesh.".format(e))
        if cmds.ls(cmds.listHistory(mesh) or [], type="skinCluster"):
            cmds.skinCluster(mesh, edit=True, unbind=True)
        return _heat_or_voxel(mesh, joints, method, name)
    finally:
        poses = []
        if psc and cmds.objExists(psc):            # its bind pose, unless shared
            poses = [p for p in cmds.listConnections(psc + ".bindPose", source=True,
                                                     destination=False) or []
                     if set(cmds.listConnections(p, type="skinCluster") or []) <= {psc}]
            cmds.delete(psc)
        if proxy and cmds.objExists(proxy):
            cmds.delete(proxy)
        poses = [p for p in poses if cmds.objExists(p)]
        if poses:
            cmds.delete(poses)


def _on_body(piece, body, samples=200, tolerance=0.03):
    """True if the piece (transform) sits on / around the body (clothes, boots, hair on
    a head that is part of the body): most of its vertices are within a few % of the
    character's height of the body surface."""
    shapes = [_shape(piece), _shape(body)]
    if None in shapes:
        return False
    a, b_ = om.MFnMesh(_dag(shapes[0])), om.MFnMesh(_dag(shapes[1]))
    pts = a.getPoints(om.MSpace.kWorld)
    step = max(1, len(pts) // samples)
    limit = Skeleton.height() * tolerance
    near = total = 0
    for p in pts[::step]:
        total += 1
        q = b_.getClosestPoint(p, om.MSpace.kWorld)[0]
        near += p.distanceTo(q) <= limit
    return bool(total) and near >= 0.7 * total


def _weights(sc, shape):
    fn, dag = _skin_fn(sc), _dag(shape)
    mesh = om.MFnMesh(dag)
    comp = _all_vertices(mesh.numVertices)
    w, ninf = fn.getWeights(dag, comp)
    infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
    return fn, dag, mesh, comp, list(w), ninf, infl


def _set(fn, dag, comp, w, ninf):
    """Rows renormalised to sum to exactly 1 first (no 'weights required modification
    for normalization' warnings from Maya afterwards)."""
    for v in range(0, len(w), ninf):
        tot = sum(w[v:v + ninf])
        if tot > 1e-9 and abs(tot - 1.0) > 1e-12:
            w[v:v + ninf] = [x / tot for x in w[v:v + ninf]]
    fn.setWeights(dag, comp, om.MIntArray(list(range(ninf))), om.MDoubleArray(w), False)


def _pos(n):
    return om.MVector(*cmds.xform(n, q=True, ws=True, translation=True))


def helpers_from_scratch(sc, shape):
    """Helper joints never take bind weight (any they have goes back to the bone they
    hang from); then the chest helpers get a clean soft patch each."""
    fn, dag, mesh, comp, W, infl = _np_weights(sc, shape)
    index = {n: i for i, n in enumerate(infl)}
    for i, n in enumerate(infl):
        if n.endswith("_hlp"):
            pi = index.get((cmds.listRelatives(n, parent=True) or [None])[0])
            if pi is not None:
                W[:, pi] += W[:, i]
                W[:, i] = 0.0
    _helper_patches(W, infl, mesh)
    _np_set(fn, dag, comp, W)


def helper_patch(sc, shape):
    """Chest helpers (pec / lat / chest) on an existing skin: a soft patch each."""
    fn, dag, mesh, comp, W, infl = _np_weights(sc, shape)
    _helper_patches(W, infl, mesh)
    _np_set(fn, dag, comp, W)


HELPER_REACH = 0.08       # chest helper patch radius, x height (x the body's size there)
HELPER_SHARE = 0.7        # how much of the weight at its centre it takes


def _helper_patches(W, infl, mesh):
    """Each chest helper takes a soft round patch (size measured on this body) from the
    spine / clavicle / upper arm weights around it. In place on W (numpy)."""
    import numpy as np
    from .skeleton import helper_spot
    index = {n: i for i, n in enumerate(infl)}
    V = None
    h = Skeleton.height()
    for helper in data.rules()["helpers"]:
        for s in "lr":
            j = names.for_side(helper["name"], s)
            if j not in index:
                continue
            if V is None:
                V = np.array([(p.x, p.y, p.z) for p in mesh.getPoints(om.MSpace.kWorld)])
            donors = [i for i, n in enumerate(infl) if not n.endswith("_hlp") and
                      names.side(n) in (s, "c") and
                      (n.startswith("spine_0") or n.startswith("clavicle") or
                       n.startswith("upperarm"))]
            radius = h * HELPER_REACH * helper_spot(helper, s)[1]
            d = np.linalg.norm(V - np.array(_xyz(_pos(j))), axis=1)
            m = d < radius
            if not m.any() or not donors:
                continue
            fall = HELPER_SHARE * (1.0 - (d[m] / radius) ** 2) ** 2
            moved = W[np.ix_(m, donors)] * fall[:, None]
            W[np.ix_(m, donors)] -= moved
            W[m, index[j]] += moved.sum(1)


def weld(skin_clusters, height, tolerance=0.0001):
    """Watertight: vertices that sit on top of each other (split seams, separate pieces
    touching - across ALL skinned meshes) get exactly the same weights, so nothing can
    open up between them in any pose. Vectorised: positions snapped to a tolerance grid,
    every group of coincident vertices gets its average."""
    import numpy as np
    eps = max(height * tolerance, 1e-4)
    items, all_names = [], []
    for sc in skin_clusters:
        shape = _sc_shape(sc)
        if not shape:
            continue
        fn, dag, mesh, comp, W, infl = _np_weights(sc, shape)
        P = np.array([(p.x, p.y, p.z) for p in mesh.getPoints(om.MSpace.kWorld)])
        items.append([fn, dag, comp, W, infl, P])
        all_names += [n for n in infl if n not in all_names]
    if not items:
        return 0
    col = {n: i for i, n in enumerate(all_names)}
    keys = np.concatenate([np.round(it[5] / eps).astype(np.int64) for it in items])
    G = np.zeros((len(keys), len(all_names)))
    start = 0
    for it in items:
        W, infl = it[3], it[4]
        G[start:start + len(W), [col[n] for n in infl]] = W
        it.append(start)
        start += len(W)
    _, group, count = np.unique(keys, axis=0, return_inverse=True, return_counts=True)
    group = group.ravel()
    shared = count[group] > 1
    if not shared.any():
        return 0
    acc = np.zeros((len(count), len(all_names)))
    np.add.at(acc, group[shared], G[shared])
    G[shared] = acc[group[shared]] / count[group[shared], None]
    for fn, dag, comp, W, infl, P, off in items:
        rows = G[off:off + len(W)][:, [col[n] for n in infl]]
        rows /= np.maximum(rows.sum(1, keepdims=True), 1e-12)
        _np_set(fn, dag, comp, rows)
    print("Watertight: {} touching vertices share identical weights.".format(int(shared.sum())))
    return int(shared.sum())


def _corrective_weights(skin_clusters):
    from . import correctives
    for sc in skin_clusters:
        shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
        if not shape:
            continue
        try:
            n = correctives.apply_weights(sc, shape, Skeleton.height())
            from . import muscles
            n += muscles.apply_weights(sc, shape, Skeleton.height())
            print("Corrective joints weighted on {} verts of {}".format(n, names.short(shape)))
        except Exception as e:
            cmds.warning("Corrective weights skipped on {} ({})".format(shape, e))


def unbind(skin_clusters):
    for sc in skin_clusters:
        if not cmds.objExists(sc):
            continue
        geo = cmds.skinCluster(sc, q=True, geometry=True) or []
        if geo:
            cmds.skinCluster(geo[0], edit=True, unbind=True)
        elif cmds.objExists(sc):
            cmds.delete(sc)


def _xyz(v):
    return (v.x, v.y, v.z)


def _is_bone(n):
    return not ("twist" in n or n.endswith("_hlp") or n.startswith(END) or n == "root")


def _head_tip(pj, h):
    """Top of the skull straight above the head joint (ray to the mesh)."""
    from .guides import Guides
    meshes = Guides.meshes()
    hit = meshes.rays().hit(pj, om.MVector(0, 1, 0), h * 0.6) if meshes else None
    return pj + om.MVector(0, (hit * 0.9) if hit else h * 0.12, 0)


def _bones(infl):
    """The skeleton as weightmath.Bone families, read from the scene (rest pose):
    a joint + its twist joints, the segments it owns, its parent family, which columns
    receive weight (twist joints at their place along the bone; a bone in skin_exclude
    only gives) and which only give (the root, temporary tips)."""
    from . import weightmath as wm
    from .twist import knee_slide_on
    rules = data.rules()
    exclude = set(rules["skin_exclude"])
    kinds = {"{}_{}".format(b, s): k for b, k in rules["twist_drive"].items() for s in "lr"}
    slide_bone = (rules.get("knee_slide") or {}).get("joint")
    index = {n: i for i, n in enumerate(infl)}
    skel = [names.short(j) for j in Skeleton.joints()]
    heads = [j for j in skel if _is_bone(j)]
    fi = {j: i for i, j in enumerate(heads)}
    h = Skeleton.height()

    def parent_bone(j):
        p = (cmds.listRelatives(j, parent=True, type="joint") or [None])[0]
        while p and p not in fi:
            p = (cmds.listRelatives(p, parent=True, type="joint") or [None])[0]
        return p

    bones = []
    for j in heads:
        kids = cmds.listRelatives(j, children=True, type="joint") or []
        pj = _pos(j)
        ends = [k for k in kids if _is_bone(k)]
        if ends:
            segs = [(_xyz(pj), _xyz(_pos(k))) for k in ends]
        else:                                   # leaf: continue the bone (head: upward)
            par = parent_bone(j)
            tip = _head_tip(pj, h) if j == "head" else \
                pj + (pj - _pos(par)) * 0.6 if par else pj + om.MVector(0, h * 0.02, 0)
            segs = [(_xyz(pj), _xyz(tip))]
        a, b = om.MVector(*segs[0][0]), om.MVector(*segs[0][1])
        ab = b - a
        l2 = max(ab * ab, 1e-12)
        slide = slide_bone and j.startswith(slide_bone + "_") and knee_slide_on()
        members, donors = [], []
        if j in index:
            if j in exclude or slide:
                donors.append(index[j])
            else:
                members.append((index[j], 1.0 if kinds.get(j) == "upper" else 0.0))
        for k in sorted(kids):
            if "twist" in k and k in index:
                members.append((index[k], ((_pos(k) - a) * ab) / l2))
        if j in index and END + j in index:
            donors.append(index[END + j])
        if not members and donors:              # nothing to receive: keep the joint
            members, donors = [(donors[0], 0.0)], donors[1:]
        par = parent_bone(j)
        bones.append(wm.Bone(_xyz(pj), fi.get(par, -1), segs, names.side(j), members,
                             donors))
    if "root" in index and "pelvis" in fi:          # the root only gives (to the pelvis)
        bones[fi["pelvis"]].donors.append(index["root"])
    return bones


def _edges(mesh):
    from . import weightmath as wm
    counts, connects = mesh.getVertices()
    return wm.neighbour_lists(list(counts), list(connects), mesh.numVertices)


def solve(sc, shape):
    """The adaptive solve on one skinCluster (skeleton in its rest pose)."""
    import numpy as np
    from . import weightmath as wm
    fn, dag, mesh, comp, w, ninf, infl = _weights(sc, shape)
    pts = mesh.getPoints(om.MSpace.kWorld)
    V = np.array([(p.x, p.y, p.z) for p in pts])
    W = np.array(w).reshape(-1, ninf)
    exempt = [i for i, n in enumerate(infl) if n.endswith("_hlp")]
    edges = _edges(mesh)
    out, allowed = wm.solve(V, W, _bones(infl), edges, Skeleton.height(),
                            max_inf=config.MAX_INFLUENCES, exempt=exempt,
                            return_allow=True)
    try:
        out = _repair_strays(sc, fn, V, out, infl, edges, allowed)
    except Exception as e:                     # never lose the solve over the extra pass
        import traceback
        traceback.print_exc()
        cmds.warning("Extreme-pose repair skipped ({})".format(e))
    w[:] = out.ravel().tolist()
    _set(fn, dag, comp, w, ninf)
    return len(V)


def _test_poses():
    """Extreme poses the skin is checked in (joint, world axis, degrees) - arms up /
    forward / back, elbows, wrists, hips forward / out, knees, spine, neck. Axes come
    from the skeleton (bone direction x the way it swings), so they suit any rig pose."""
    from ..core import template
    tpl = template.get()
    up, fwd, back = om.MVector(0, 1, 0), om.MVector(0, 0, 1), om.MVector(0, 0, -1)
    out = []

    def ball(j, tip, way, deg):
        bone = _pos(tip) - _pos(j)
        ax = bone ^ way
        if ax.length() > 1e-6:
            out.append((j, ax.normal(), deg))

    def hinge(a, b, c, deg):
        ax = om.MVector(*cmds.xform(b, q=True, ws=True, matrix=True)[0:3]).normal()
        line = _pos(c) - _pos(a)
        off = (_pos(b) - _pos(a)) - line * (((_pos(b) - _pos(a)) * line) / (line * line))
        if (ax ^ (_pos(c) - _pos(b))) * off > 0:
            ax = -ax
        out.append((b, ax, deg))
    for a, b, c, sign in tpl.limbs:
        for sd in "lr":
            A, B, C = (names.for_side(n, sd) for n in (a, b, c))
            if not all(cmds.objExists(n) for n in (A, B, C)):
                continue
            outv = om.MVector(1 if sd == "l" else -1, 0, 0)
            if sign < 0:                                   # arm
                ball(A, B, up, 110)
                ball(A, B, fwd, 90)
                ball(A, B, back, 40)
                hinge(A, B, C, 130)
            else:                                          # leg
                ball(A, B, fwd, 100)
                ball(A, B, outv, 45)
                # no knee bend here: the knee crease folding on itself is normal (the
                # Knee corrective / knee shape handle it) and "repairing" it smeared the
                # knee blend over a third of the thigh - the knee lost its volume
    chain = data.rules()["spine"]["chain"]
    mid = chain[len(chain) // 2] if chain else None
    for j, ax, deg in ((mid, (1, 0, 0), 30), (mid, (1, 0, 0), -20), (mid, (0, 0, 1), 25),
                       ("neck_01", (1, 0, 0), 40), ("neck_01", (0, 0, 1), 30)):
        if j and cmds.objExists(j):
            out.append((j, om.MVector(*ax), deg))
    return out


def _repair_strays(sc, fn, V, W, infl, edges, allowed, passes=3):
    """Skin Mesh, last step: the skin is posed in every test pose (in memory - nothing in
    the scene moves) and vertices that break out of line with their neighbours (stray
    vertices, torn seams) are found; their patch is rebuilt from the ring around it
    (weightmath / stretchmath), keeping every bone inside its own area - except right
    at a seam between two bones, which may blend. Repeated until clean (max `passes`)."""
    import numpy as np
    from . import stretchmath as st
    h = Skeleton.height()
    paths = fn.influenceObjects()
    pre = np.array([np.array(cmds.getAttr("{}.bindPreMatrix[{}]".format(
        sc, fn.indexForInfluenceObject(p)))).reshape(4, 4) for p in paths])
    rest = np.linalg.inv(pre)
    long_names = [p.fullPathName() for p in paths]
    poses = []
    for j, ax, deg in _test_poses():
        jl = cmds.ls(j, long=True)[0]
        moving = np.array([n == jl or n.startswith(jl + "|") for n in long_names])
        if moving.any():
            c = np.array(_xyz(_pos(j)))
            poses.append((moving, st.rot_about(c, np.array(_xyz(ax)), deg)))
    if not poses:
        return W

    def worst(Wx):
        b = np.zeros(len(V))
        for moving, M in poses:
            P = st.pose_points(V, Wx, pre, rest, moving, M)
            b = np.maximum(b, st.strays(V, P, edges, h))
        return b
    allow = st.seam_allowed(allowed, W, edges, rings=2)
    b = worst(W)
    first = int((b > 1).sum())
    for _ in range(passes):
        bad = b > 1
        if not bad.any():
            break
        W = st.heal(W, st.grow(bad, edges, 2), edges, allowed=allow,
                    max_inf=config.MAX_INFLUENCES)
        b = worst(W)
    print("Extreme poses ({}): {} stray vertices found and repaired, {} left (worst {:.1f})."
          .format(len(poses), first, int((b > 1).sum()), float(b.max()) if len(b) else 0))
    return W


class _Clock(object):
    """Skin Mesh's time per step, printed in the Script Editor (to see what's slow)."""

    def __init__(self):
        import time
        self.time, self.steps = time.time, []
        self.last = self.start = time.time()

    def __call__(self, label):
        now = self.time()
        self.steps.append((label, now - self.last))
        self.last = now

    def report(self):
        print("Skin Mesh times: " + ", ".join("{} {:.1f}s".format(k, v) for k, v in
                                               self.steps) +
              "  (total {:.1f}s)".format(self.time() - self.start))


def bind(meshes, method="heat"):
    """Skin every mesh; returns the new skinClusters.
      body (+ any piece not ON the body, e.g. a separate head): heat map bind (voxel if
      the mesh isn't closed), helper weights reset, then the adaptive solve, then the
      corrective / helper patches
      clothes, boots, hair ON the body: copy the body's weights, closest point
      everything: max influences, touching vertices welded"""
    try:
        import numpy  # noqa: F401  (ships with Maya 2022+)
        del numpy
    except ImportError:
        cmds.error("Skin Mesh needs numpy (it ships with Maya 2022 and later).")
    exclude = set(data.rules()["skin_exclude"])
    # excluded limb bones still go INTO the bind: heat map / voxel weight by bone
    # segments, and a joint left out hands its segment to the next bone down
    twist_bones = {"{}_{}".format(b, s) for b in data.rules()["twist_drive"] for s in "lr"}
    joints = [j for j in Skeleton.joints(long=True)
              if names.short(j) not in exclude - twist_bones]
    # SPEED: only the bones go into the (slow) heat map / voxel bind. Twist and helper
    # joints join afterwards with no weight - the solve shares each bone's weight out to
    # its twist joints, the helpers get their patches - so the result is the same
    late = [j for j in joints if not _is_bone(names.short(j))]
    joints = [j for j in joints if _is_bone(names.short(j))]
    ends = _temp_ends(meshes)                        # head / finger / toe tips for the bind
    joints += ends
    clock = _Clock()
    todo = [m for m in meshes.transforms
            if not cmds.ls(cmds.listHistory(m) or [], type="skinCluster")]
    skipped = [names.short(m) for m in meshes.transforms if m not in todo]
    main_t = _main_pieces(todo)
    made, main = [], []
    for m in todo:
        if m == main_t[0]:                          # the body
            sc = _bind_main(m, joints, method)
        elif m in main_t:                           # a separate piece (head, helmet):
            sc = _closest_bind(joints, m, names.short(m) + "_preview_skinCluster")
        else:                                       # copies the body's weights later
            sc = _closest_bind(joints, m, names.short(m) + "_preview_skinCluster")
        for j in late:
            cmds.skinCluster(sc, edit=True, addInfluence=j, weight=0.0, lockWeights=False)
        made.append(sc)
        if m in main_t:
            main.append(sc)
    cmds.select(clear=True)
    clock("bind")
    if not made:
        _drop_ends(made, ends)
        return made
    for sc in main:                       # solve while the tip joints still exist
        shape = _sc_shape(sc)
        if shape:
            helpers_from_scratch(sc, shape)
            solve(sc, shape)
    clock("solve + extreme-pose repair")
    _drop_ends(made, ends)
    if skipped:
        cmds.warning("Already skinned, left alone: " + ", ".join(skipped))
    _corrective_weights(main)
    clock("corrective weights")
    body = main[0]
    for sc in made:
        if sc in main:
            continue
        cmds.copySkinWeights(sourceSkin=body, destinationSkin=sc, noMirror=True,
                             surfaceAssociation="closestPoint",
                             influenceAssociation=["oneToOne", "closestJoint"],
                             normalize=True)
        shape = _sc_shape(sc)
        if shape:
            limit_influences(sc, shape)
    if len(made) > 1:
        print("Body: {} - {} piece(s) copied their weights from it, {} weighted on their "
              "own.".format(body, len(made) - len(main), len(main) - 1))
    clock("clothes / pieces")
    weld(made, Skeleton.height())
    dq_blend(made)                                   # clothes too, or the body pokes through
    clock("weld + dual quaternion")
    clock.report()
    return made


def dq_blend(skin_clusters):
    """Legs + pelvis keep their volume with Maya's dual quaternion skinning - no tuning,
    any proportions. The skin is set to "weight blended": each vertex mixes linear and
    dual quaternion by how much of it belongs to the joints in rule dq_skin (pelvis,
    spine_01, legs), so the arms / upper body stay linear and the change is smooth up the
    waist. The weights themselves don't change (FBX exports them as usual)."""
    import re
    import numpy as np
    pat = data.rules().get("dq_skin")
    if not pat:
        return
    rx = re.compile(pat)
    for sc in skin_clusters:
        shape = _sc_shape(sc)
        if not shape:
            continue
        fn, dag, mesh, comp, W, infl = _np_weights(sc, shape)
        leg = [i for i, n in enumerate(infl) if rx.match(n)]
        body = [i for i, n in enumerate(infl) if not n.endswith("_hlp")]
        if not leg:
            continue
        share = W[:, leg].sum(1) / np.maximum(W[:, body].sum(1), 1e-9)
        share = np.clip((share - 0.1) / 0.8, 0.0, 1.0)            # 10% -> 0, 90% -> 1
        share = share * share * (3 - 2 * share)
        cmds.setAttr(sc + ".skinningMethod", 2)                     # weight blended
        try:
            fn.setBlendWeights(dag, comp, om.MDoubleArray(share.tolist()))
        except Exception:                                           # older API: one call
            cmds.setAttr("{}.blendWeights[0:{}]".format(sc, len(share) - 1),
                         *[float(v) for v in share])


def repair(skin_clusters, meshes=None):
    """Re-run the solve on an existing skin (skeleton in its rest pose)."""
    for sc in skin_clusters:
        shape = _sc_shape(sc)
        if shape:
            solve(sc, shape)
    _corrective_weights(skin_clusters)
    weld(skin_clusters, Skeleton.height())
    dq_blend(skin_clusters)


def rigid_rules(skin_clusters, meshes=None):
    """(kept for fixmesh.auto_smooth) re-solve after smoothing."""
    for sc in skin_clusters:
        shape = _sc_shape(sc)
        if shape:
            solve(sc, shape)
