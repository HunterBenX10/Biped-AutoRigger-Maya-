"""The reference control layout rebuilt on any skeleton.

Every node in data/control_layout.json is stored relative to a joint ("joint" mode: in
the joint's frame) or at a joint's position, world-aligned ("world" mode), as a fraction
of character height - so it scales and follows any skeleton. Only the left side and centre
are stored; the right side is a behaviour mirror of the left.
"""
import re

import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes

IDENTITY = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]


class Controls(object):
    def __init__(self, height):
        self.h = height                    # character height (scene units)
        self.rules = data.rules()
        self.made = {}                     # rig name -> node
        self.records = []                  # (node, layout entry, side)

    # ---------------------------------------------------------------- layout
    def layout(self):
        """Captured layout + the rig's grouping rules (rename / regroup / drop)."""
        r, out = self.rules, []
        for o in data.layout()["nodes"]:
            if o["n"] in r["drop"]:
                continue
            o = dict(o, n=r["rename"].get(o["n"], o["n"]), p=r["rename"].get(o["p"], o["p"]))
            o["p"] = r["reparent"].get(o["n"], o["p"])
            o["p"] = None if o["p"] in r["drop"] else o["p"]
            o["tg"] = [] if o["n"] in r["no_follow"] else o["tg"]
            out.append(o)
            out += [dict(n=g["n"], p=g["p"], a="root", m="world", rel=IDENTITY, sh=[], tg=[])
                    for g in r["add_groups"] if g["p"] == o["n"]]
        return out

    def frame(self, o, s):
        """World matrix of a layout node for side s ('c', 'l' or 'r')."""
        rel = om.MMatrix(o["rel"])
        t = mathx.origin(rel) * self.h
        anchor = names.for_side(o["a"], s)
        if o["m"] == "joint":
            t = -t if s == "r" else t                  # behaviour mirror flips the frame
            base = mathx.world(anchor)
        else:
            if s == "r":
                rel = mathx.MIRROR_X * rel * mathx.MIRROR_X
                t = om.MVector(-t.x, t.y, t.z)
            base = mathx.at(mathx.pos(anchor))
        for i in range(3):
            rel.setElement(3, i, t[i])
        ground = self.rules["ground"]
        if o["n"] in ground["nodes"]:                  # floor pivots share one height
            floor = mathx.pos(names.for_side(ground["joint"], s)).y + ground["offset"] * self.h
            rel.setElement(3, 1, floor - base.getElement(3, 1))
        pv = self.rules["pole_vectors"].get(o["n"])
        if pv:
            return mathx.at(self.pole_position(pv, s))
        return rel * base

    def pole_position(self, pv, s):
        """Pole vector rule (same on both sides, no mirroring maths involved):
            line    = hip->ankle (shoulder->wrist)
            ahead   = world +Z made perpendicular to the line, times the limb's sign
                      (+1 legs: in front of the knee, -1 arms: behind the elbow)
            pole    = knee/elbow + direction * distance
        direction = the knee / elbow's offset from the line (on the 'ahead' side) - the
        plane the limb bends in (legs: the plane of the foot, set at Build Skeleton), so
        the knee can't drift sideways as it bends."""
        j, sign, dist = pv
        mid = names.for_side(j, s)
        top = cmds.listRelatives(mid, parent=True, type="joint")[0]
        end = next(c for c in cmds.listRelatives(mid, children=True, type="joint")
                   if "twist" not in c and not c.endswith("_hlp"))
        a, b, c = mathx.pos(top), mathx.pos(mid), mathx.pos(end)
        line = (c - a).normal()
        fwd = om.MVector(0, 0, 1)
        ahead = (fwd - line * (fwd * line)).normal() * sign
        # the pole sits IN the plane the chain bends in: along the knee / elbow's own
        # offset from the line (positions only - never a joint axis, which differs per
        # side). Build Skeleton puts that offset in the bend plane (legs: the foot's
        # plane) and pre-bends it, so even a straight-looking limb has one. A pole off
        # that plane makes the knee drift sideways as it bends.
        bend = (b - a) - line * ((b - a) * line)
        if bend.length() > 1e-4 * (b - a).length():
            direction = bend.normal()
            if direction * ahead < 0:                  # hyper-extended guide: flip
                direction = -direction
        else:
            direction = ahead
        limb = (b - a).length() + (c - b).length()
        # distance = a fraction of the limb's own length (not body height): far enough
        # that a deep crouch / bent elbow never brings the knee/elbow past the pole
        return b + direction * (dist * limb)

    def shapes(self, node, o, s):
        flip = (-1, -1, -1) if o["m"] == "joint" else (-1, 1, 1)
        on_top = any(re.search(p, names.short(node)) for p in self.rules["draw_on_top"])
        for deg, form, knots, cvs, col in o["sh"]:
            pts = [tuple(v * self.h * (f if s == "r" else 1) for v, f in zip(cv, flip))
                   for cv in cvs]
            color = config.MIRROR_COLOR.get(col, col) if s == "r" else col
            look = {"color": color} if color is not None else {}
            if on_top:
                look["on_top"] = True
            nodes.add_curve(node, pts, degree=deg, knots=knots, periodic=form == 2,
                            name=names.short(node) + "Shape#", **look)

    # ---------------------------------------------------------------- build
    def build(self, top):
        driven = {sp["group"] for sp in self.rules["spaces"]}     # constrained later: use TRS
        for side in "clr":
            for o in self.layout():
                if names.is_left(o["n"]) != (side != "c"):
                    continue
                name, pname = names.for_side(o["n"], side), names.for_side(o["p"], side)
                parent = self.made.get(pname, top) if o["p"] else top
                node = nodes.place(name, parent, self.frame(o, side),
                                   use_trs=bool(o["tg"]) or o["n"] in driven)
                self.shapes(node, o, side)
                self._pivot_on_joint(node)
                self.made[name] = node
                self.records.append((node, o, side))
        return self.made

    def driven_joint(self, name):
        """The joint a ctrl moves: special hooks (hip_ctrl -> pelvis), else its own name
        (thigh_l_ctrl / thigh_l_fk_ctrl -> thigh_l, hand_l_ik_ctrl -> hand_l)."""
        j = self.rules["special_hooks"].get(names.short(name)) or \
            re.sub(r"(_fk|_ik)?_ctrl$", "", names.short(name))
        return j if j != names.short(name) and cmds.objExists(j) and \
            cmds.nodeType(j) == "joint" else None

    def _pivot_on_joint(self, node):
        """RULE: every ctrl rotates and scales around the joint it drives, wherever its
        shape sits (the shape can float above/around the body; the pivot can't)."""
        if not cmds.listRelatives(node, shapes=True, type="nurbsCurve"):
            return
        j = self.rules.get("pivot_overrides", {}).get(names.short(node)) or \
            self.driven_joint(node)
        if not j or not cmds.objExists(j):
            return
        m = om.MMatrix(cmds.getAttr(node + ".worldMatrix[0]"))
        local = om.MPoint(mathx.pos(j)) * m.inverse()
        for attr in ("rotatePivot", "scalePivot"):
            cmds.setAttr(node + "." + attr, local.x, local.y, local.z)

    def ctrls(self):
        return [(n, node) for n, node in self.made.items()
                if cmds.listRelatives(node, shapes=True, type="nurbsCurve")]

    # ---------------------------------------------------------------- fit shapes
    def fit_to(self, meshes):
        """Resize wrap-around ctrls so they hug this body with the same gap as on
        the reference rig - per side (+X, -X, +Z, -Z measured separately)."""
        rays, report = meshes.rays(), []
        for node, o, side in self.records:
            ref = self.rules["wrap_fit"].get(o["n"])
            if not ref:
                continue
            my, xp, xn, zp, zn, mode = ref
            if side == "r":
                xp, xn = xn, xp
                if o["m"] == "joint":
                    zp, zn, my = zn, zp, -my
            m = om.MMatrix(cmds.getAttr(node + ".worldMatrix[0]"))
            x, y, z = (mathx.axis(m, i) for i in range(3))
            shapes = cmds.listRelatives(node, shapes=True, type="nurbsCurve", fullPath=True)
            cvs = {s: cmds.xform(s + ".cv[*]", q=True, objectSpace=True, translation=True)
                   for s in shapes}
            allp = [v for pts in cvs.values() for v in pts]
            xs, zs = allp[0::3], allp[2::3]
            ext = [max(xs), -min(xs), max(zs), -min(zs)]            # shape reach per side
            new = rays.four_sides(mathx.origin(m) + y * (my * self.h), x, z,
                                  max(abs(v) for v in allp) * 1.6)
            if None in new or min(ext) <= 1e-4:
                continue
            ref = [v * self.h for v in (xp, xn, zp, zn)]
            if mode == "sym":
                new, ref = [min(new)] * 4, [min(ref)] * 4
            k = [min(max((n + e - r) / e, 0.4), 2.5) for e, n, r in zip(ext, new, ref)]
            for s, pts in cvs.items():
                for i in range(len(pts) // 3):
                    px, py, pz = pts[i * 3:i * 3 + 3]
                    cmds.xform("{}.cv[{}]".format(s, i), objectSpace=True, translation=(
                        px * (k[0] if px > 0 else k[1]), py, pz * (k[2] if pz > 0 else k[3])))
            report.append("{:<22} +X {:.2f}  -X {:.2f}  +Z {:.2f}  -Z {:.2f}".format(
                names.short(node), *k))
        return report

    # ---------------------------------------------------------------- wiring
    def follow(self):
        """Groups that follow a joint / ctrl (clavicles, neck, head, hands, switches...)."""
        for node, o, side in self.records:
            joints = [names.for_side(re.sub(r"_ctrl$", "", t), side) for t in o["tg"]]
            joints = [j for j in joints if cmds.objExists(j) and cmds.nodeType(j) == "joint"]
            ctrls = [names.for_side(t, side) for t in o["tg"]]
            ctrls = [c for c in ctrls if cmds.objExists(c) and cmds.nodeType(c) == "transform"]
            if joints or ctrls:            # a bind joint first: works in FK and IK alike
                tgt = joints[0] if joints else nodes.follower(ctrls[0])
                cmds.parentConstraint(tgt, node, maintainOffset=True)

    def switches(self):
        """IK_FK_Switch: 1 shows the FK ctrls, 0 the IK ctrls (like the reference rig)."""
        for sw, (default, fk, ik) in self.rules["switches"].items():
            for side in ("lr" if names.is_left(sw) else "c"):
                s_node, fk, ik = (names.for_side(n, side) for n in (sw, fk, ik))
                if not all(cmds.objExists(n) for n in (s_node, fk, ik)):
                    continue
                cmds.addAttr(s_node, longName="IK_FK_Switch", attributeType="double", min=0,
                             max=1, defaultValue=default, keyable=True)
                rev = cmds.createNode("reverse", name="{}_{}_rev".format(config.RIG_UTIL,
                                                                          s_node))
                cmds.connectAttr(s_node + ".IK_FK_Switch", fk + ".lodVisibility")
                cmds.connectAttr(s_node + ".IK_FK_Switch", rev + ".inputX")
                cmds.connectAttr(rev + ".outputX", ik + ".lodVisibility")

    def hook_fk(self):
        """Every ctrl named after a joint drives it (thigh_l_ctrl -> thigh_l), or its FK
        driver joint when the IK/FK system made one (thigh_l_fk)."""
        count = 0
        for name, node in self.ctrls():
            joint = self.rules["special_hooks"].get(name) or re.sub(r"(_fk)?_ctrl$", "", name)
            if joint.endswith("_ik"):              # IK ctrls drive IK handles, never joints
                continue
            joint = joint + "_fk" if cmds.objExists(joint + "_fk") else joint
            if joint != name and cmds.objExists(joint) and cmds.nodeType(joint) == "joint":
                cmds.parentConstraint(nodes.follower(node), joint, maintainOffset=True,
                                      name=joint + config.HOOK_SUFFIX)
                count += 1
        return count

    def finger_attrs(self):
        """Fist / Spread / <Digit>_Curl on the hand's switch ctrl, both sides.

        Each finger ctrl's placement (Offset Parent Matrix) gets an extra rotation in
        front of it:  offsetParentMatrix = rotate(curl about Z, spread about X) x rest.
        The ctrls are behaviour-mirrored like the joints, so the SAME values curl / spread
        both hands the same way (curl = Z on both sides, like rotating the ctrls by hand),
        and the ctrls' own channels stay at 0, free for animation on top."""
        cfg = self.rules.get("fingers")
        if not cfg:
            return 0
        nodes.ensure_plugins("matrixNodes")
        axis = {"rx": "X", "ry": "Y", "rz": "Z"}
        curl_ax, spread_ax = axis[cfg["curl_axis"]], axis[cfg["spread_axis"]]
        made = 0
        for side in "lr":
            host = names.for_side(cfg["host"], side)
            if not cmds.objExists(host):
                continue
            digits = [(d, v) for d, v in sorted(cfg["digits"].items())
                      if any(cmds.objExists(names.for_side(j, side) + "_ctrl")
                             for j in v["joints"])]
            if not digits:
                continue
            if not cmds.attributeQuery("FINGERS", node=host, exists=True):
                cmds.addAttr(host, longName="FINGERS", attributeType="enum",
                             enumName="--------")
                cmds.setAttr(host + ".FINGERS", channelBox=True, lock=True)
            for attr, lo, hi in [("Fist", 0, 10), ("Spread", -10, 10)] + \
                    [(d.capitalize() + "_Curl", -10, 10) for d, _ in digits]:
                if not cmds.attributeQuery(attr, node=host, exists=True):
                    cmds.addAttr(host, longName=attr, attributeType="double", min=lo,
                                 max=hi, defaultValue=0, keyable=True)
            for d, v in digits:
                for k, jn in enumerate(v["joints"]):
                    ctrl = names.for_side(jn, side) + "_ctrl"
                    if not cmds.objExists(ctrl):
                        continue
                    tag = "{}_{}_finger".format(config.RIG_UTIL, names.short(ctrl))
                    curl = cmds.createNode("plusMinusAverage", name=tag + "_curl")
                    cmds.connectAttr(host + ".Fist", curl + ".input1D[0]")
                    cmds.connectAttr("{}.{}_Curl".format(host, d.capitalize()),
                                     curl + ".input1D[1]")
                    deg = nodes.mult(tag + "_curlDeg")
                    cmds.connectAttr(curl + ".output1D", deg + ".input1")
                    scales = v.get("curl_scales") or [v.get("curl_scale", 1.0)] * len(
                        v["joints"])
                    cmds.setAttr(deg + ".input2",
                                 cfg["curl_deg"] * scales[min(k, len(scales) - 1)])
                    cm = cmds.createNode("composeMatrix", name=tag + "_rot")
                    cmds.connectAttr(deg + ".output", cm + ".inputRotate" + curl_ax)
                    if k == 0 and v.get("spread"):
                        sp = nodes.mult(tag + "_spreadDeg")
                        cmds.connectAttr(host + ".Spread", sp + ".input1")
                        cmds.setAttr(sp + ".input2", cfg["spread_deg"] * v["spread"])
                        cmds.connectAttr(sp + ".output", cm + ".inputRotate" + spread_ax)
                    mm = cmds.createNode("multMatrix", name=tag + "_opm")
                    cmds.connectAttr(cm + ".outputMatrix", mm + ".matrixIn[0]")
                    cmds.setAttr(mm + ".matrixIn[1]", cmds.getAttr(ctrl + ".offsetParentMatrix"),
                                 type="matrix")
                    cmds.connectAttr(mm + ".matrixSum", ctrl + ".offsetParentMatrix",
                                     force=True)
                    made += 1
        return made

    def auto_clavicle(self):
        """Clavicle ctrl .Auto_Clavicle (0-1, default 0 = off): raising the arm lifts the
        clavicle with it (up to max_angle when the arm points straight up), so the
        shoulder and the top of the chest rise instead of the arm just rotating under
        them. Reads the arm's ELEVATION without going through the clavicle (no loop):
          FK: the upperarm FK ctrl's own rotate channels (in its rest frame)
          IK: the hand IK ctrl's position from the shoulder, in the chest's space
        blended by IK_FK_Switch; the lift goes into the clavicle ctrl's Offset Parent
        Matrix, so its channels stay free and it shows the automatic part."""
        cfg = self.rules.get("auto_clavicle")
        if not cfg:
            return 0
        nodes.ensure_plugins("matrixNodes", "quatNodes")
        made = 0
        up_w = om.MVector(0, 1, 0)
        for side in "lr":
            f = lambda n: names.for_side(n, side)
            cc, fk, ik, sw = (f(cfg[k]) for k in ("clavicle_ctrl", "fk_ctrl", "ik_ctrl",
                                                   "switch"))
            arm, elbow, chest = f(cfg["arm"]), f(cfg["elbow"]), cfg["chest"]
            if not all(cmds.objExists(n) for n in (cc, fk, ik, sw, arm, elbow, chest)):
                continue
            tag = "{}_{}_autoClav".format(config.RIG_UTIL, names.short(cc))
            bone_w = (mathx.pos(elbow) - mathx.pos(arm)).normal()
            # ---- FK elevation: rest bone dir / world up in the FK ctrl's rest frame
            fk_inv = mathx.world(fk).inverse()
            d0, u0 = (bone_w * fk_inv).normal(), (up_w * fk_inv).normal()
            cm = cmds.createNode("composeMatrix", name=tag + "_fkRot")
            cmds.connectAttr(fk + ".rotate", cm + ".inputRotate")
            cmds.connectAttr(fk + ".rotateOrder", cm + ".inputRotateOrder")
            vfk = cmds.createNode("vectorProduct", name=tag + "_fkDir")
            cmds.setAttr(vfk + ".operation", 3)
            cmds.setAttr(vfk + ".normalizeOutput", 1)
            cmds.setAttr(vfk + ".input1", d0.x, d0.y, d0.z)
            cmds.connectAttr(cm + ".outputMatrix", vfk + ".matrix")
            efk = self._elevation(tag + "_fk", vfk + ".output", u0, d0 * u0)
            # ---- IK elevation: hand position from the shoulder, in the chest's space
            ch_inv = mathx.world(chest).inverse()
            sh = om.MPoint(mathx.pos(arm)) * om.MMatrix(
                cmds.getAttr(chest + ".worldInverseMatrix[0]"))
            hand0 = om.MPoint(mathx.pos(ik)) * om.MMatrix(
                cmds.getAttr(chest + ".worldInverseMatrix[0]"))
            uc = (up_w * ch_inv).normal()
            mm = cmds.createNode("multMatrix", name=tag + "_ikRel")
            cmds.connectAttr(ik + ".worldMatrix[0]", mm + ".matrixIn[0]")
            cmds.connectAttr(chest + ".worldInverseMatrix[0]", mm + ".matrixIn[1]")
            dm = cmds.createNode("decomposeMatrix", name=tag + "_ikPos")
            cmds.connectAttr(mm + ".matrixSum", dm + ".inputMatrix")
            rel = cmds.createNode("plusMinusAverage", name=tag + "_ikFromShoulder")
            cmds.setAttr(rel + ".operation", 2)
            cmds.connectAttr(dm + ".outputTranslate", rel + ".input3D[0]")
            cmds.setAttr(rel + ".input3D[1]", sh.x, sh.y, sh.z)
            nrm = cmds.createNode("vectorProduct", name=tag + "_ikDir")
            cmds.setAttr(nrm + ".operation", 0)
            cmds.setAttr(nrm + ".normalizeOutput", 1)
            cmds.connectAttr(rel + ".output3D", nrm + ".input1")
            rest_ik = (om.MVector(hand0) - om.MVector(sh)).normal() * uc
            eik = self._elevation(tag + "_ik", nrm + ".output", uc, rest_ik)
            # ---- blend by the switch (1 = FK), x max angle x Auto_Clavicle
            bl = cmds.createNode("blendColors", name=tag + "_fkik")
            cmds.connectAttr(efk, bl + ".color1R")
            cmds.connectAttr(eik, bl + ".color2R")
            cmds.connectAttr(sw + ".IK_FK_Switch", bl + ".blender")
            if not cmds.attributeQuery("Auto_Clavicle", node=cc, exists=True):
                cmds.addAttr(cc, longName="Auto_Clavicle", attributeType="double", min=0,
                             max=1, defaultValue=cfg.get("default", 1.0), keyable=True)
            amt = nodes.mult(tag + "_amount")
            cmds.connectAttr(bl + ".outputR", amt + ".input1")
            cmds.connectAttr(cc + ".Auto_Clavicle", amt + ".input2")
            deg = nodes.mult(tag + "_degrees")
            cmds.connectAttr(amt + ".output", deg + ".input1")
            cmds.setAttr(deg + ".input2", cfg.get("max_angle", 30.0))
            # ---- lift axis in the clavicle ctrl's frame: (clavicle bone x up)
            cdir = (mathx.pos(arm) - mathx.pos(names.for_side("clavicle_l", side))).normal()
            axis_w = (cdir ^ up_w).normal()
            cc_inv = om.MMatrix(cmds.getAttr(cc + ".worldInverseMatrix[0]"))
            axis_l = (axis_w * cc_inv).normal()
            aq = cmds.createNode("axisAngleToQuat", name=tag + "_quat")
            cmds.setAttr(aq + ".inputAxis", axis_l.x, axis_l.y, axis_l.z)
            cmds.connectAttr(deg + ".output", aq + ".inputAngle")
            rot = cmds.createNode("composeMatrix", name=tag + "_lift")
            cmds.setAttr(rot + ".useEulerRotation", 0)
            cmds.connectAttr(aq + ".outputQuat", rot + ".inputQuat")
            mmo = cmds.createNode("multMatrix", name=tag + "_opm")
            cmds.connectAttr(rot + ".outputMatrix", mmo + ".matrixIn[0]")
            cmds.setAttr(mmo + ".matrixIn[1]", cmds.getAttr(cc + ".offsetParentMatrix"),
                         type="matrix")
            cmds.connectAttr(mmo + ".matrixSum", cc + ".offsetParentMatrix", force=True)
            made += 1
        return made

    @staticmethod
    def _elevation(tag, dir_plug, up, rest):
        """0 at the rest elevation -> 1 pointing straight up (eased)."""
        dot = cmds.createNode("vectorProduct", name=tag + "_up")
        cmds.setAttr(dot + ".operation", 1)
        cmds.connectAttr(dir_plug, dot + ".input1")
        cmds.setAttr(dot + ".input2", up.x, up.y, up.z)
        rm = cmds.createNode("remapValue", name=tag + "_elev")
        cmds.connectAttr(dot + ".outputX", rm + ".inputValue")
        cmds.setAttr(rm + ".inputMin", rest)
        cmds.setAttr(rm + ".inputMax", 1.0)
        for i in (0, 1):
            cmds.setAttr("{}.value[{}].value_Interp".format(rm, i), 2)
        return rm + ".outValue"

    def neck_follow(self):
        """Turning the head ctrl bends the whole neck, not just a band at the jaw line.
        neck joint: position from the neck ctrl; rotation = blend(neck ctrl, head ctrl)
                    by head_ctrl.Neck_Follow (parentConstraint, rotation only - one offset
                    per target, so changing the amount never pops the rest pose)
        head joint: rotation from the head ctrl only (its position comes down the neck),
                    so the head still points exactly where the ctrl does.
        The head's spaces follow the neck CTRL (not the joint), so nothing loops."""
        cfg = self.rules.get("neck_follow")
        if not cfg or not all(cmds.objExists(cfg[k]) for k in
                              ("neck", "head", "neck_ctrl", "head_ctrl")):
            return False
        neck, head = cfg["neck"], cfg["head"]
        hc = cfg["head_ctrl"]
        nd, hd = nodes.follower(cfg["neck_ctrl"]), nodes.follower(hc)
        for j in (neck, head):
            nodes.delete(j + config.HOOK_SUFFIX)
        if not cmds.attributeQuery("Neck_Follow", node=hc, exists=True):
            cmds.addAttr(hc, longName="Neck_Follow", attributeType="double", min=0, max=1,
                         defaultValue=cfg.get("default", 0.4), keyable=True)
        cmds.pointConstraint(nd, neck, maintainOffset=True,
                             name=neck + config.HOOK_SUFFIX + "_point")
        con = cmds.parentConstraint(nd, hd, neck, maintainOffset=True,
                                    skipTranslate=("x", "y", "z"),
                                    name=neck + config.HOOK_SUFFIX)[0]
        cmds.setAttr(con + ".interpType", 2)
        w_neck, w_head = cmds.parentConstraint(con, q=True, weightAliasList=True)
        rev = cmds.createNode("reverse", name="{}_{}_neckFollow_rev".format(
            config.RIG_UTIL, names.short(hc)))
        cmds.connectAttr(hc + ".Neck_Follow", rev + ".inputX")
        cmds.connectAttr(rev + ".outputX", con + "." + w_neck)
        cmds.connectAttr(hc + ".Neck_Follow", con + "." + w_head)
        cmds.parentConstraint(hd, head, maintainOffset=True, skipTranslate=("x", "y", "z"),
                              name=head + config.HOOK_SUFFIX)
        return True

    BREATH_CTRLS = ("spine_upper_ctrl", "spine_05_ctrl")      # IK and FK chest

    def breath_attrs(self):
        """Breath / Belly_Breath on the chest ctrls (IK and FK), as proxies of the root's
        attrs that drive the breathing shapes - key them on whichever ctrl you animate."""
        from .autoshapes import BREATH
        made = 0
        for ctrl in self.BREATH_CTRLS:
            if not cmds.objExists(ctrl):
                continue
            attrs = [a for a, _, _ in BREATH
                     if cmds.attributeQuery(a, node="root", exists=True)]
            if not attrs:
                return 0
            if not cmds.attributeQuery("BREATHING", node=ctrl, exists=True):
                cmds.addAttr(ctrl, longName="BREATHING", attributeType="enum",
                             enumName="--------")
                cmds.setAttr(ctrl + ".BREATHING", channelBox=True, lock=True)
            for a in attrs:
                if not cmds.attributeQuery(a, node=ctrl, exists=True):
                    cmds.addAttr(ctrl, longName=a, proxy="root." + a)
                    made += 1
        return made

    CHEST_SCALE = ("spine_05", "spine_05_ctrl", "spine_upper_ctrl", "cog_ctrl")

    def chest_scale(self):
        """Scale the chest ctrl (FK spine_05_ctrl or IK spine_upper_ctrl, whichever the
        spine switch uses) to scale the ribcage for breathing: drives spine_05's scale.
        Joints compensate their parent's scale (segment scale compensate), so the neck,
        head, clavicles and arms ride outward with the chest without growing."""
        joint, fk, ik, switch = self.CHEST_SCALE
        if not all(cmds.objExists(n) for n in (joint, fk, ik)):
            return 0
        bc = cmds.createNode("blendColors", name="chest_scale_blend")
        cmds.connectAttr(fk + ".scale", bc + ".color1")          # switch 1 = FK
        cmds.connectAttr(ik + ".scale", bc + ".color2")
        if cmds.attributeQuery("IK_FK_Switch", node=switch, exists=True):
            cmds.connectAttr(switch + ".IK_FK_Switch", bc + ".blender")
        cmds.connectAttr(bc + ".output", joint + ".scale", force=True)
        for kid in cmds.listRelatives(joint, children=True, type="joint") or []:
            cmds.setAttr(kid + ".segmentScaleCompensate", 1)
        return 1

    def lock(self):
        """Hide visibility everywhere, lock what animators shouldn't touch."""
        rules = [(re.compile(p), c) for p, c in self.rules["locks"]]
        for name, node in self.ctrls():
            chans = next(c for p, c in rules if p.search(name))
            nodes.lock(node, [a + ax for a in chans for ax in "xyz"])   # v stays free
