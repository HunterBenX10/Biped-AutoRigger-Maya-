"""Stage 3 - the rig: controls, IK/FK systems, spaces, display toggles (skin is stage 2).

    Biped_Rig
      Controls     World_ctrl > cog_ctrl, leg_*_grp, arm_*_grp  (everything animators touch)
      Skeleton     the bind joints
      Geometry     the character's meshes (moved in at Build Rig, back out at Remove Rig,
                   never moved in space); set to Reference
                   so it can't be clicked: World_ctrl > Geo_Display)
      Rig_Systems  hidden machinery: FK/IK driver chains, IK handles, spine curve...
"""
import ast

import maya.cmds as cmds

from .. import config
from ..core import nodes
from ..core.mesh import MeshSet
from .controls import Controls
from .guides import Guides
from .skeleton import ROOT, Skeleton
from .systems import Systems
from .deform import Deformation

def names_short(path):
    return path.split("|")[-1]


GROUPS = ("Controls", "Skeleton", "Geometry", "Rig_Systems")


def _safe(label, fn):
    """An optional build step: if it fails, say so (full trace in the Script Editor) and
    carry on - the core rig (ctrls, IK/FK, switches, display toggles) always completes."""
    try:
        return fn()
    except Exception as e:
        import traceback
        traceback.print_exc()
        cmds.warning("{} skipped ({}) - the rest of the rig is fine.".format(label, e))
        return None


class PreviewRig(object):
    top = config.RIG_TOP

    @classmethod
    def exists(cls):
        return cmds.objExists(cls.top)

    def build(self, fit_shapes=True):
        if not Skeleton.exists():
            Skeleton().build()
        self.remove()
        deform = Deformation()
        deform.clear_test()
        Skeleton.rest_pose()               # build on the skeleton exactly as it was built
        deform.ensure_drivers()
        meshes = Guides.meshes()
        rest = {j: (cmds.getAttr(j + ".translate")[0], cmds.getAttr(j + ".rotate")[0])
                for j in Skeleton.joints()}
        with nodes.undo_chunk():
            before = nodes.snapshot()
            top = cmds.createNode("transform", name=self.top)
            grp = {g: cmds.createNode("transform", name=g, parent=top) for g in GROUPS}
            nodes.add_string(top, "rest", repr(rest))
            nodes.add_string(top, "mesh", meshes.to_string())
            cmds.parent(ROOT, grp["Skeleton"])
            meshes.see_through(False)
            self._layer(meshes)
            # the meshes move into Geometry: carry on with their NEW paths (the old ones
            # made the next step fail and the build stop half way - everything visible)
            meshes = _safe("Geometry group", lambda: self._to_geometry(
                meshes, grp["Geometry"])) or MeshSet.from_string(meshes.to_string())

            ctrls = Controls(Skeleton.height())
            ctrls.build(grp["Controls"])
            if meshes and fit_shapes:
                print("Ctrl shapes fitted to the mesh (scale per side, 1 = unchanged):\n  "
                      + "\n  ".join(ctrls.fit_to(meshes)))
            self._world_scale(grp)
            ctrls.follow()
            ctrls.switches()
            sysm = Systems(grp["Rig_Systems"])
            limbs, spine = sysm.limbs(), sysm.spine()
            sysm.foot_proxies()
            _safe("Heel bank", sysm.heel_bank)            # heel tilt rolls on the foot edge
            nodes.settle()                 # hooks measure their offsets on the evaluated rig
            hooked = ctrls.hook_fk()
            nodes.settle()
            _safe("Neck follow", ctrls.neck_follow)        # head ctrl bends the whole neck
            _safe("Auto clavicle", ctrls.auto_clavicle)    # the arm lifts the shoulder
            _safe("Finger attrs", ctrls.finger_attrs)      # Fist / Spread / Curl
            _safe("Breathing attrs", ctrls.breath_attrs)   # Breath on the chest ctrls
            _safe("Chest scale", ctrls.chest_scale)        # scale the chest ctrl: ribcage
            nodes.settle()                 # spaces last, on a fully evaluated rig, so their
            spaces = _safe("Spaces", sysm.spaces) or []    # offsets match the rest pose
            self._display("World_ctrl", grp, meshes)
            ctrls.lock()
            _safe("Clean Channel Box", lambda: nodes.quiet_new(before))
            Guides().show(False)
            cmds.select("World_ctrl")
        print("Rig built: {} ctrls/groups, IK/FK on {} limbs{}, {} space switches, {} FK "
              "hooks. Display toggles are on World_ctrl.".format(
                  len(ctrls.made), len(limbs), " + spine" if spine else "", len(spaces),
                  hooked))

    @staticmethod
    def _world_scale(grp):
        """RULE: everything that deforms or solves scales with World_ctrl. The skeleton
        and Rig_Systems (IK chains, spine curve joints) aren't under World_ctrl, so they
        follow it (parent + scale). Without this the ctrls scaled but the joints / IK
        didn't, the stretch maths saw the arm 'too long' and the mesh stayed small."""
        drv = nodes.follower("World_ctrl")
        for g in ("Skeleton", "Rig_Systems"):
            cmds.parentConstraint(drv, grp[g], maintainOffset=True,
                                  name=g + "_world" + config.HOOK_SUFFIX)
            cmds.scaleConstraint(drv, grp[g], maintainOffset=True,
                                 name=g + "_worldScale" + config.HOOK_SUFFIX)

    # ---------------------------------------------------------------- Geometry group
    @staticmethod
    def _reparent(node, parent):
        """Move a node under `parent` (None = world) keeping it exactly where it is in
        space. Locked transform channels are unlocked for the move and locked again."""
        chans = [node + "." + a + x for a in "trs" for x in "xyz"]
        locked = [c for c in chans if cmds.getAttr(c, lock=True)]
        for c in locked:
            cmds.setAttr(c, lock=False)
        try:
            if parent:
                node = cmds.parent(node, parent)[0]
            else:
                node = cmds.parent(node, world=True)[0]
        finally:
            for c in locked:
                c = cmds.ls(node, long=True)[0] + "." + c.split(".")[-1]
                cmds.setAttr(c, lock=True)
        return node

    def _to_geometry(self, meshes, geo_grp):
        """The character's meshes go into Biped_Rig|Geometry (same place in space; their
        old parents are remembered for Remove Rig)."""
        back = {}
        for t in meshes.transforms:
            if not cmds.objExists(t):
                continue
            old = (cmds.listRelatives(t, parent=True, fullPath=True) or [""])[0]
            new = self._reparent(t, geo_grp)
            back[cmds.ls(new, long=True)[0]] = old
        nodes.add_string(self.top, "mesh_parents", repr(back))
        moved = MeshSet([n for n in back])
        nodes.add_string(self.top, "mesh", moved.to_string())
        from .guides import Guides
        if Guides.exist():
            nodes.add_string(config.GUIDE_GRP, "mesh", moved.to_string())
        if cmds.objExists("root"):
            nodes.add_string("root", "mesh", moved.to_string())
        return moved

    def _from_geometry(self):
        back = ast.literal_eval(nodes.get_string(self.top, "mesh_parents") or "{}")
        moved = []
        for t, old in back.items():
            if not cmds.objExists(t):
                continue
            new = self._reparent(t, old if old and cmds.objExists(old) else None)
            moved.append(cmds.ls(new, long=True)[0])
        if moved:
            text = MeshSet(moved).to_string()
            nodes.add_string(self.top, "mesh", text)
            from .guides import Guides
            if Guides.exist():
                nodes.add_string(config.GUIDE_GRP, "mesh", text)
            if cmds.objExists("root"):
                nodes.add_string("root", "mesh", text)

    LAYER = "Geometry_layer"

    def _layer(self, meshes):
        """Mesh on a Reference display layer (can't be clicked while animating).
        The mesh itself is never moved or reparented."""
        if cmds.objExists(self.LAYER):
            cmds.delete(self.LAYER)
        layer = cmds.createDisplayLayer(name=self.LAYER, empty=True)
        if meshes:
            cmds.editDisplayLayerMembers(layer, meshes.transforms, noRecurse=True)
        cmds.setAttr(layer + ".displayType", 2)

    @staticmethod
    def _display(world, grp, meshes):
        """Visibility / display-type toggles on World_ctrl."""
        def add(attr, kind, default, targets, plug):
            kw = (dict(attributeType="enum", enumName=config.DISPLAY_ENUM) if kind == "enum"
                  else dict(attributeType="bool"))
            cmds.addAttr(world, longName=attr, defaultValue=default, **kw)
            cmds.setAttr(world + "." + attr, channelBox=True)
            for t in targets:
                try:
                    if kind == "enum" and cmds.nodeType(t) != "displayLayer":
                        cmds.setAttr(t + ".overrideEnabled", 1)
                    cmds.connectAttr(world + "." + attr, t + plug, force=True)
                except RuntimeError:
                    pass

        body = [c for c in cmds.listRelatives(world, children=True, type="transform") or []
                if not c.endswith("_drv")]
        hands = [h for h in ("hand_l_grp", "hand_r_grp") if cmds.objExists(h)]
        cmds.addAttr(world, longName="DISPLAY", attributeType="enum", enumName="--------")
        cmds.setAttr(world + ".DISPLAY", channelBox=True, lock=True)
        for attr, kind, default, targets in (
                ("Body_Ctrls", "bool", 1, body), ("Finger_Ctrls", "bool", 1, hands),
                ("Skeleton_Vis", "bool", 1, [grp["Skeleton"]]),
                ("Rig_Systems_Vis", "bool", 1, [grp["Rig_Systems"]])):
            # RULE: nothing you can see or edit elsewhere is connected or locked.
            # These toggles drive lodVisibility only, so Outliner hide / unhide, the
            # Layer Editor (geometry: Geometry_layer, starts as R) and the Drawing
            # Overrides in the Attribute Editor all stay free.
            add(attr, kind, default, targets, ".lodVisibility")
        cmds.setAttr(grp["Rig_Systems"] + ".visibility", 0)   # hidden until you unhide it
        cmds.setAttr(grp["Skeleton"] + ".visibility", 0)      # same - Outliner H / Show

    # ---------------------------------------------------------------- finalize
    def finalize(self):
        """Hand-off clean-up. Nothing that drives the rig is deleted:
          1. history: test animation cleared, construction history baked away on the
             meshes but every deformer (skin) kept (= Delete Non-Deformer History),
             leftover template nodes removed
          2. skin: weights pruned below 0.01, max 4 per vertex, renormalised, touching
             vertices welded, unused influences dropped from each skinCluster
             (joints stay), max-influence lock turned on
          3. Outliner: display toggles moved off .visibility (and Rig_Systems unhidden
             from its drawing override), so H / Show work on every group
        """
        if not self.exists():
            cmds.error("Build Rig first.")
        from . import skin as skin_mod
        from .deform import Deformation
        deform = Deformation()
        with nodes.undo_chunk():
            deform.clear_test()
            cmds.currentTime(0)
            meshes = Guides.meshes()
            for t in meshes.transforms:
                cmds.bakePartialHistory(t, prePostDeformers=True)
            skins = deform.skins()
            for sc in skins:
                shape = (cmds.skinCluster(sc, q=True, geometry=True) or [None])[0]
                if not shape:
                    continue
                skin_mod.limit_influences(sc, shape)
                cmds.skinCluster(sc, edit=True, maximumInfluences=config.MAX_INFLUENCES,
                                 obeyMaxInfluences=True)
                cmds.setAttr(sc + ".maintainMaxInfluences", 1)
                cmds.setAttr(sc + ".normalizeWeights", 1)
            skin_mod.weld(skins, Skeleton.height())
            removed = 0
            for sc in skins:
                infl = cmds.skinCluster(sc, q=True, influence=True) or []
                used = set(cmds.skinCluster(sc, q=True, weightedInfluence=True) or [])
                unused = [i for i in infl if i not in used]
                if unused and len(unused) < len(infl):
                    cmds.skinCluster(sc, edit=True, removeInfluence=unused)
                    removed += len(unused)
            freed = self._free_outliner()
            Guides().show(False)
            nodes.add_string(self.top, "finalized", "1")
            cmds.select("World_ctrl")
        print("Finalized: history cleaned on {} meshes, {} skins optimised ({} unused "
              "influences dropped), {} display toggles moved off visibility - Outliner "
              "hide / unhide works everywhere.".format(len(meshes.transforms), len(skins),
                                                      removed, freed))

    def _free_outliner(self):
        """Anything still driving .visibility / overrideVisibility from World_ctrl (older
        builds) moves to lodVisibility; overrides that only hid things are switched off."""
        moved = 0
        pairs = cmds.listConnections("World_ctrl", source=False, destination=True,
                                     plugs=True, connections=True) or []
        for src, dst in zip(pairs[0::2], pairs[1::2]):
            node, attr = dst.split(".", 1)
            if attr not in ("visibility", "overrideVisibility") or \
                    cmds.nodeType(node) == "displayLayer":
                continue
            cmds.disconnectAttr(src, dst)
            cmds.setAttr(dst, 1)
            cmds.connectAttr(src, node + ".lodVisibility", force=True)
            moved += 1
        for g in cmds.listRelatives(self.top, children=True, fullPath=True) or []:
            if True:                                   # full paths: names may not be unique
                plug = g + ".visibility"
                if cmds.getAttr(plug, lock=True):
                    cmds.setAttr(plug, lock=False)
                if not cmds.listConnections(g + ".overrideVisibility", source=True,
                                            destination=False):
                    cmds.setAttr(g + ".overrideVisibility", 1)
        return moved

    def remove(self):
        """Delete the rig and put the skeleton back in its rest pose (skin is kept)."""
        if not self.exists():
            return
        from ..core.mesh import MeshSet
        rest = ast.literal_eval(nodes.get_string(self.top, "rest") or "{}")
        mesh_text = nodes.get_string(self.top, "mesh")

        def rest_pose():
            for j, (t, r) in rest.items():
                if not cmds.objExists(j):
                    continue
                for attr, value in (("translate", t), ("rotate", r)):
                    for ax, v in zip("XYZ", value):     # skip driven channels (twist slide...)
                        plug = "{}.{}{}".format(j, attr, ax)
                        if cmds.getAttr(plug, settable=True):
                            cmds.setAttr(plug, v)

        with nodes.undo_chunk():
            nodes.delete("*" + config.HOOK_SUFFIX + "*", config.RIG_UTIL + "_*")
            rest_pose()
            if cmds.objExists(self.LAYER):
                cmds.delete(self.LAYER)
            if cmds.objExists(ROOT):
                cmds.parent(ROOT, world=True)
            self._from_geometry()                  # the meshes go back where they were
            cmds.delete(self.top)
            meshes = MeshSet.from_string(mesh_text)
            for shp in meshes.shapes():                    # undo the display hookup
                for attr, value in (("overrideDisplayType", 0), ("overrideEnabled", 0),
                                    ("visibility", 1), ("lodVisibility", 1)):
                    plug = shp + "." + attr
                    src = cmds.listConnections(plug, source=True, destination=False, plugs=True)
                    if src:
                        cmds.disconnectAttr(src[0], plug)
                    try:
                        cmds.setAttr(plug, value)
                    except RuntimeError:
                        pass
            rest_pose()
        print("Rig removed, skeleton back in its rest pose.")
