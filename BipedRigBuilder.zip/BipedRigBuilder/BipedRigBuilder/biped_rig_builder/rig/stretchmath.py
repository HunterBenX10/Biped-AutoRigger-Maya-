"""Stretch finding + weight repair - pure numpy, no Maya (testable anywhere).

pose_points     skin the rest mesh in a test pose (one joint swung round an axis, its
                whole branch following) - linear skinning, exactly like the skinCluster
edge_badness    how far each vertex's edges stretch / squash vs rest, worst over poses
heal            rebuild the weights of a patch from the ring of vertices around it
                (harmonic: every vertex = the average of its neighbours, the ring held
                fixed) - the patch then blends evenly from one side to the other, so the
                stretch spreads out instead of piling up on a few vertices
"""
import numpy as np


def rot_about(C, axis, degrees):
    """4x4 row-vector matrix: rotate round `axis` through point C."""
    a = np.radians(degrees)
    axis = np.asarray(axis, float)
    axis = axis / np.linalg.norm(axis)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    R = np.eye(3) + np.sin(a) * K + (1 - np.cos(a)) * K @ K
    M = np.eye(4)
    M[:3, :3] = R.T
    M[3, :3] = C - C @ R.T
    return M


def pose_points(V, W, pre, rest_world, moving, M):
    """Posed points: influences flagged `moving` get rest_world @ M, the rest stay."""
    world = np.where(moving[:, None, None], rest_world @ M, rest_world)
    J = np.einsum("mij,mjk->mik", pre, world)
    S = np.einsum("nm,mij->nij", W, J)
    V4 = np.c_[V, np.ones(len(V))]
    return np.einsum("ni,nij->nj", V4, S)[:, :3]


def edge_badness(V, P, edges, stretch=2.0, squash=0.45):
    """Per vertex: worst edge ratio beyond the limits (>1 = bad), and the edge ratios."""
    i, k = edges
    r0 = np.linalg.norm(V[i] - V[k], axis=1)
    r1 = np.linalg.norm(P[i] - P[k], axis=1)
    ratio = r1 / np.maximum(r0, 1e-9)
    bad = np.maximum(ratio / stretch, squash / np.maximum(ratio, 1e-9))
    out = np.zeros(len(V))
    np.maximum.at(out, i, bad)
    return out


def grow(mask, edges, rings):
    i, k = edges
    mask = mask.copy()
    for _ in range(rings):
        g = np.zeros_like(mask)
        g[i[mask[k]]] = True
        mask |= g
    return mask


def heal(W, region, edges, iters=400, tol=1e-5, max_inf=4, prune=0.01, allowed=None):
    """Harmonic re-weighting of `region` (bool, N) from its border ring. allowed (N, M)
    bool: columns each vertex may use - a bone never spreads outside its own area."""
    W = W.copy()
    if not region.any():
        return W
    i, k = edges
    use = region[i]                       # edges whose start vertex is being solved
    ii, kk = i[use], k[use]
    deg = np.bincount(ii, minlength=len(W)).astype(float)
    rows = np.where(region & (deg > 0))[0]
    if not len(rows):
        return W
    for _ in range(iters):
        acc = np.zeros((len(W), W.shape[1]))
        np.add.at(acc, ii, W[kk])
        new = acc[rows] / deg[rows, None]
        if allowed is not None:
            new = new * allowed[rows]
            tot = new.sum(1, keepdims=True)
            new = np.where(tot > 1e-9, new / np.maximum(tot, 1e-12), W[rows])
        change = np.abs(new - W[rows]).max()
        W[rows] = new
        if change < tol:
            break
    R = W[rows]
    if max_inf and R.shape[1] > max_inf:
        idx = np.argsort(-R, axis=1)[:, max_inf:]
        np.put_along_axis(R, idx, 0.0, axis=1)
    R[R < prune] = 0.0
    R /= np.maximum(R.sum(1, keepdims=True), 1e-12)
    W[rows] = R
    return W


def strays(V, P, edges, h, factor=3.0, floor=0.004):
    """Vertices that break out of line with their neighbours in a pose: how far a vertex
    sits from the average of its neighbours (its local bump), posed vs rest. A smooth
    bend keeps that bump about the same; a stray vertex / torn flap makes it jump.
    Returns the jump per vertex in units of `floor` x height (>1 = stray)."""
    i, k = edges
    deg = np.maximum(np.bincount(i, minlength=len(V)), 1).astype(float)

    def bump(X):
        acc = np.zeros_like(X)
        np.add.at(acc, i, X[k])
        return X - acc / deg[:, None]
    b0, b1 = bump(V), bump(P)
    grew = np.linalg.norm(b1 - b0, axis=1)
    rest = np.linalg.norm(b0, axis=1)
    return grew / np.maximum(factor * rest, floor * h)


def seam_allowed(allowed, W, edges, rings=2):
    """Where two bones' areas meet on the surface (a vertex's strongest bone differs from
    a neighbour's), a repair may blend the bones from BOTH sides within `rings` of the
    seam - so the armpit can soften between arm and ribs - but nowhere else."""
    i, k = edges
    top = W.argmax(1)
    seam = np.zeros(len(W), bool)
    seam[i[top[i] != top[k]]] = True
    zone = grow(seam, edges, rings)
    reach = allowed.copy()
    for _ in range(rings):
        acc = np.zeros(reach.shape, np.int32)
        np.add.at(acc, i, reach[k].astype(np.int32))
        reach |= acc > 0
    out = allowed.copy()
    out[zone] = reach[zone]
    return out
