"""Corrective shapes made automatically for THIS character (Skin Mesh, last step).

For every knee, elbow, hip and shoulder (from the skeleton's limb definitions, both
sides) the joint is bent to two sample angles; at each, shapemath.hinge_fix works out
from the mesh what the skin should look like (no flesh through the crease, outer corners
kept square) and the difference is stored as a blend shape target (in-between + full),
in the mesh's rest space, in front of the skin. A small node network reads the joint's
bend (angle in its bend plane, measured in the parent's space, 0 when bent the other way)
and dials the target in - so it works the same with or without the rig, and exports as
an ordinary morph target.

Motion ranges below are about how joints MOVE, not about the body - any body size or
build gets its own shapes, measured on its own mesh.
"""
import math

import maya.cmds as cmds
import maya.api.OpenMaya as om

from ..core import mathx, names, nodes, template

BS = "brb_corrective_shapes"
UTIL = "brb_shape_util"
TAG = "_fixShape"
# (start = shape off, in-between angle, full angle) in degrees from the rest pose
HINGE = (75.0, 110.0, 145.0)          # knee / elbow bend
HIP = (30.0, 75.0, 120.0)             # hip flexion forward (a high knee lift)
SHOULDER = (30.0, 85.0, 140.0)        # shoulder raise up (from the A-pose, to overhead)
FINGER = (30.0, 60.0, 95.0)           # finger joint curl (knuckles keep their volume)


def remove():
    nodes.delete(BS + "*", UTIL + "_*", "*" + TAG, "*" + TAG + "_ib")


def exists():
    return bool(cmds.ls(BS + "*", type="blendShape"))


def _np():
    import numpy as np
    from . import shapemath as sm
    return np, sm


def _rotate_about(joint, centre, axis, degrees):
    """Bend a joint by `degrees` round a world axis through `centre` (keeps its
    jointOrient; only its rotate / translate channels change)."""
    q = om.MQuaternion(om.MAngle(degrees, om.MAngle.kDegrees).asRadians(), axis)
    rot = q.asMatrix()
    to = om.MMatrix()
    back = om.MMatrix()
    for i in range(3):
        to.setElement(3, i, -centre[i])
        back.setElement(3, i, centre[i])
    m = om.MMatrix(cmds.xform(joint, q=True, ws=True, matrix=True))
    cmds.xform(joint, ws=True, matrix=mathx.flat(m * to * rot * back))


def _joints_under(j):
    return set(names.short(x) for x in
               [j] + (cmds.listRelatives(j, allDescendents=True, type="joint") or []))


def _samples():
    """(child joint, parent-side joints, tip joint, bend axis fn, ranges, label)."""
    tpl = template.get()
    out = []
    from ..core import data
    fingers = data.rules().get("fingers") or {}
    for digit in (fingers.get("digits") or {}).values():
        for jn in digit["joints"]:
            for s in "lr":
                j = names.for_side(jn, s)
                if not cmds.objExists(j):
                    continue
                parent = (cmds.listRelatives(j, parent=True, type="joint") or [None])[0]
                kids = [k for k in cmds.listRelatives(j, children=True, type="joint") or []
                        if not k.endswith("_hlp")]
                if parent and kids:
                    out.append((j, parent, kids[0], "finger", FINGER,
                                names.base(j) + "_" + s))
    dq = data.rules().get("dq_skin")
    for a, b, c, sign in tpl.limbs:
        if dq and sign > 0:             # legs: dual quaternion keeps their volume already
            continue
        for s in "lr":
            A, B, C = (names.for_side(n, s) for n in (a, b, c))
            if not all(cmds.objExists(n) for n in (A, B, C)):
                continue
            out.append((B, A, C, "hinge", HINGE, names.base(B) + "_" + s))
            parent = (cmds.listRelatives(A, parent=True, type="joint") or [None])[0]
            if parent:
                way = om.MVector(0, 0, 1) if sign > 0 else om.MVector(0, 1, 0)
                out.append((A, parent, B, way, HIP if sign > 0 else SHOULDER,
                            names.base(A) + "_" + s))
    return out


def _bend_axis(child, parent, tip, way):
    """World bend axis. Hinges: the joint's own X (the limb bend axis), turned so the
    tip swings away from the pre-bend (knee forward -> foot goes back, elbow back ->
    hand comes forward). Ball joints: the axis that swings the bone toward `way`."""
    pc, pt = mathx.pos(child), mathx.pos(tip)
    bone = (pt - pc).normal()
    if way == "finger":
        # the way the rig curls it: Fist turns each finger ctrl round its own curl axis
        # by curl_deg per unit (behaviour-mirrored joints: the same on both hands)
        from ..core import data
        cfg = data.rules().get("fingers") or {}
        k = "XYZ".index(cfg.get("curl_axis", "rz")[-1].upper())
        sign = -1.0 if cfg.get("curl_deg", -9.0) < 0 else 1.0
        return (mathx.axis(mathx.world(child), k) * sign).normal()
    if isinstance(way, str):                      # "hinge" (ball joints pass an MVector)
        axis = mathx.axis(mathx.world(child), 0)
        pp = mathx.pos(parent)
        line = pt - pp
        off = (pc - pp) - line * (((pc - pp) * line) / (line * line))
        if (axis ^ (pt - pc)) * off > 0:
            axis = -axis
        return axis.normal()
    axis = bone ^ way
    if axis.length() < 1e-4:
        axis = bone ^ om.MVector(1, 0, 0)
    return axis.normal()


def build(skin_clusters, height):
    """Make and wire the corrective shapes on every skinned mesh. Returns targets made.
    Each sample pose is set ONCE and read for every mesh; only the vertices that change
    are converted and stored (sparse targets written straight into the blend shape)."""
    np, sm = _np()
    from .skin import _dag, _skin_fn, _all_vertices, _sc_shape, _edges
    remove()
    samples = _samples()
    if not samples:
        return 0
    meshes = []                         # per skinned mesh: everything read once at rest
    for sc in skin_clusters:
        shape = _sc_shape(sc)
        if not shape:
            continue
        fn, dag = _skin_fn(sc), _dag(shape)
        mesh = om.MFnMesh(dag)
        w, ninf = fn.getWeights(dag, _all_vertices(mesh.numVertices))
        paths = fn.influenceObjects()
        meshes.append(dict(
            sc=sc, shape=shape, mesh=mesh, paths=paths,
            W=np.array(w).reshape(-1, ninf),
            infl=[names.short(p.partialPathName()) for p in paths],
            pre=np.array([np.array(cmds.getAttr("{}.bindPreMatrix[{}]".format(
                sc, fn.indexForInfluenceObject(p)))).reshape(4, 4) for p in paths]),
            V=np.array([(p.x, p.y, p.z) for p in mesh.getPoints(om.MSpace.kWorld)]),
            to_obj=np.linalg.inv(np.array(cmds.getAttr(
                shape + ".worldMatrix[0]")).reshape(4, 4)[:3, :3]),
            edges=_edges(mesh), targets=[], cols_sub={}))
        meshes[-1]["rest"] = np.linalg.inv(meshes[-1]["pre"])
    for child, parent, tip, way, ranges, label in samples:
        sub = _joints_under(child)
        side_tag = names.side(child)
        # the other side of the bend = EVERY joint on this side / the centre that isn't
        # part of the bending limb (torso, lats and their helpers too - a shoulder's
        # lats are mostly mid-spine weight, which a near-joints-only list missed)
        near_p = [n for n in (names.short(j) for j in cmds.ls("root", dag=True,
                                                              type="joint") or [])
                  if n not in sub and names.side(n) in (side_tag, "c")]
        C0 = np.array(cmds.xform(child, q=True, ws=True, translation=True))
        work = []
        for m in meshes:
            index = {n: i for i, n in enumerate(m["infl"])}
            cols_c = [index[n] for n in sub if n in index]
            cols_p = [index[n] for n in near_p if n in index]
            if not cols_c or not cols_p:
                continue
            a = m["W"][:, cols_c].sum(1)
            b = m["W"][:, cols_p].sum(1)
            region = (a + b) > 0.5
            side = a / np.maximum(a + b, 1e-9)
            radius = sm.joint_radius(m["V"], C0, np.where(region, side, -1.0))
            if radius:
                m["cols_sub"][child] = cols_c
                work.append((m, side, region, radius, []))
        if not work:
            continue
        axis = _bend_axis(child, parent, tip, way)
        rest_dir = (mathx.pos(tip) - mathx.pos(child)).normal()
        d1 = np.array([rest_dir.x, rest_dir.y, rest_dir.z])
        ax = np.array([axis.x, axis.y, axis.z])
        keep = (cmds.getAttr(child + ".rotate")[0], cmds.getAttr(child + ".translate")[0])
        moving = {names.short(p.fullPathName()): p.fullPathName()
                  for m, *_ in work for p in m["paths"]
                  if names.short(p.fullPathName()) in sub}
        for angle in ranges[1:]:
            try:
                # SPEED: no viewport refresh / mesh read per sample - only the bent
                # joints' matrices are read and the skin is posed here in numpy
                # (linear, like the arms / fingers it's used for)
                _rotate_about(child, mathx.pos(child), axis, angle)
                C = np.array(cmds.xform(child, q=True, ws=True, translation=True))
                tipw = np.array(cmds.xform(tip, q=True, ws=True, translation=True))
                d2 = (tipw - C) / max(np.linalg.norm(tipw - C), 1e-9)
                posed = {n: np.array(cmds.getAttr(k + ".worldMatrix[0]")).reshape(4, 4)
                         for n, k in moving.items()}
                for m, side, region, radius, got in work:
                    world = np.array([posed.get(n, m["rest"][i])
                                      for i, n in enumerate(m["infl"])])
                    rows_m = np.where(m["W"][:, m["cols_sub"][child]].sum(1) > 1e-6)[0]
                    P = m["V"].copy()
                    if len(rows_m):
                        S = sm.skin_matrices(m["W"][rows_m], m["pre"], world)
                        V4 = np.c_[m["V"][rows_m], np.ones(len(rows_m))]
                        P[rows_m] = np.einsum("ni,nij->nj", V4, S)[:, :3]
                    F, moved = sm.hinge_fix(m["V"], P, side, region, C0, C, ax, d1, d2,
                                            radius, m["edges"])
                    rows = np.where(moved)[0]
                    if not len(rows):
                        continue
                    S = sm.skin_matrices(m["W"][rows], m["pre"], world)
                    delta = sm.to_rest(F[rows] - P[rows], S) @ m["to_obj"]
                    big = np.abs(delta).max(1) > 1e-5 * height
                    if big.any():
                        got.append((angle, rows[big], delta[big]))
            finally:
                for attr, vals in (("rotate", keep[0]), ("translate", keep[1])):
                    for axn, v in zip("XYZ", vals):
                        plug = "{}.{}{}".format(child, attr, axn)
                        if cmds.getAttr(plug, settable=True):
                            cmds.setAttr(plug, v)
        for m, side, region, radius, got in work:
            if got:
                m["targets"].append((label, child, tip, axis, ranges, got))
    for m in meshes:
        m["extra"] = _breath(m, np, sm, height)
    made, drivers = 0, {}
    for m in meshes:
        made += _make_shapes(m["shape"], m["targets"], drivers, m["extra"])
    return made


BREATH = (("Breath", -0.5, 1.0), ("Belly_Breath", -0.5, 1.0))   # attr, min, max


def _breath(m, np, sm, height):
    """Breathing targets (rest space, no posing), driven by root.Breath / root.Belly_Breath
    (the rig adds them to the chest ctrls). Ribcage = the top two spine joints + the chest
    helpers (+ part of the clavicles and the third spine joint); belly = the bottom two."""
    from ..core import data
    chain = [j for j in data.rules()["spine"]["chain"] if cmds.objExists(j)]
    if len(chain) < 4:
        return []
    index = {n: i for i, n in enumerate(m["infl"])}
    helpers = [names.for_side(h["name"], s) for h in data.rules()["helpers"] for s in "lr"]
    part = {chain[-1]: 1.0, chain[-2]: 1.0, chain[-3]: 0.5}
    part.update({h: 1.0 for h in helpers})
    part.update({names.for_side("clavicle_l", s): 0.3 for s in "lr"})
    rib = sum((m["W"][:, index[n]] * f for n, f in part.items() if n in index),
              np.zeros(len(m["V"])))
    belly = sum((m["W"][:, index[n]] for n in chain[:2] if n in index),
                np.zeros(len(m["V"])))
    if rib.max() <= 0:
        return []
    A = np.array(cmds.xform(chain[-3], q=True, ws=True, translation=True))
    B = np.array(cmds.xform(chain[-1], q=True, ws=True, translation=True))
    rib_d, belly_d = sm.breath_shapes(m["V"], rib, belly, A, B)
    out = []
    for (attr, lo, hi), d in zip(BREATH, (rib_d, belly_d)):
        d = d @ m["to_obj"]
        rows = np.where(np.abs(d).max(1) > 1e-5 * height)[0]
        if len(rows):
            if not cmds.attributeQuery(attr, node="root", exists=True):
                cmds.addAttr("root", longName=attr, attributeType="double", min=lo,
                             max=hi, defaultValue=0, keyable=True)
            out.append((attr, rows, d[rows]))
    return out


def _ranges(ids):
    """[3, 4, 5, 9] -> ['vtx[3:5]', 'vtx[9]'] (a componentList)."""
    out, start, prev = [], None, None
    for i in ids:
        if start is None:
            start = prev = i
        elif i == prev + 1:
            prev = i
        else:
            out.append("vtx[{}]".format(start) if start == prev else
                       "vtx[{}:{}]".format(start, prev))
            start = prev = i
    if start is not None:
        out.append("vtx[{}]".format(start) if start == prev else
                   "vtx[{}:{}]".format(start, prev))
    return out


def _free_index(bs):
    used = cmds.getAttr(bs + ".weight", multiIndices=True) or []
    return (max(used) + 1) if used else 0


def _set_target(bs, idx, item, rows, delta):
    """Write a sparse target (only the vertices that move) into the blend shape."""
    plug = "{}.inputTarget[0].inputTargetGroup[{}].inputTargetItem[{}]".format(bs, idx, item)
    order = sorted(range(len(rows)), key=lambda k: rows[k])
    ids = [int(rows[k]) for k in order]
    pts = [(float(delta[k][0]), float(delta[k][1]), float(delta[k][2]), 1.0) for k in order]
    cmds.setAttr(plug + ".inputPointsTarget", len(pts), *pts, type="pointArray")
    comps = _ranges(ids)
    cmds.setAttr(plug + ".inputComponentsTarget", len(comps), *comps, type="componentList")


def _make_shapes(shape, targets, drivers, extra=()):
    if not targets and not extra:
        return 0
    base = cmds.listRelatives(shape, parent=True, fullPath=True)[0]
    name = "{}_{}".format(BS, names.short(base))
    try:                                      # an empty blend shape, in front of the skin
        bs = cmds.blendShape(base, frontOfChain=True, name=name)[0]
    except RuntimeError:                      # (older Maya wants a target to start with)
        dup = cmds.duplicate(base)[0]
        bs = cmds.blendShape(dup, base, frontOfChain=True, name=name)[0]
        cmds.delete(dup)
        for alias in (cmds.aliasAttr(bs, q=True) or [])[0::2]:
            cmds.aliasAttr(bs + "." + alias, remove=True)
    count = 0
    for idx, (label, child, tip, axis, ranges, got) in enumerate(targets):
        start, mid, full = ranges
        cmds.setAttr("{}.weight[{}]".format(bs, idx), 0)
        try:
            cmds.aliasAttr(label + TAG, "{}.weight[{}]".format(bs, idx))
        except RuntimeError:
            pass
        last = max(angle for angle, _, _ in got)
        for angle, rows, delta in got:
            w = (angle - start) / (full - start)
            # the furthest sample is the full target; earlier ones are in-betweens
            item = 6000 if angle == last else int(round(5000 + 1000 * w))
            _set_target(bs, idx, item, rows, delta)
        if label not in drivers:
            drivers[label] = _drive(child, tip, axis, start, full, label)
        cmds.connectAttr(drivers[label], "{}.weight[{}]".format(bs, idx), force=True)
        count += 1
    for attr, rows, delta in extra:                 # breathing: driven by root attrs
        idx = _free_index(bs)
        cmds.setAttr("{}.weight[{}]".format(bs, idx), 0)
        try:
            cmds.aliasAttr(attr, "{}.weight[{}]".format(bs, idx))
        except RuntimeError:
            pass
        _set_target(bs, idx, 6000, rows, delta)
        cmds.connectAttr("root." + attr, "{}.weight[{}]".format(bs, idx), force=True)
        count += 1
    return count


def _drive(child, tip, axis, start, full, label):
    """Plug = remap(bend angle, start -> full, 0 -> 1). The bend angle is the
    child bone's swing in the bend plane (round `axis`), in the parent's space, from rest;
    0 when it bends the other way."""
    tag = "{}_{}".format(UTIL, label)
    parent = (cmds.listRelatives(child, parent=True, type="joint") or [None])[0]
    pinv = mathx.world(parent).inverse() if parent else om.MMatrix()
    bone_local = (mathx.pos(tip) - mathx.pos(child)).normal() * \
        mathx.world(child).inverse()
    rest = ((mathx.pos(tip) - mathx.pos(child)).normal() * pinv).normal()
    a = (axis * pinv).normal()
    mm = cmds.createNode("multMatrix", name=tag + "_mm")
    cmds.connectAttr(child + ".worldMatrix[0]", mm + ".matrixIn[0]")
    if parent:
        cmds.connectAttr(parent + ".worldInverseMatrix[0]", mm + ".matrixIn[1]")
    v = cmds.createNode("vectorProduct", name=tag + "_dir")
    cmds.setAttr(v + ".operation", 3)
    cmds.setAttr(v + ".normalizeOutput", 1)
    cmds.setAttr(v + ".input1", bone_local.x, bone_local.y, bone_local.z)
    cmds.connectAttr(mm + ".matrixSum", v + ".matrix")
    dot = cmds.createNode("vectorProduct", name=tag + "_onAxis")      # v . a
    cmds.setAttr(dot + ".operation", 1)
    cmds.connectAttr(v + ".output", dot + ".input1")
    cmds.setAttr(dot + ".input2", a.x, a.y, a.z)
    along = cmds.createNode("multiplyDivide", name=tag + "_along")   # a * (v . a)
    for ax in "XYZ":
        cmds.connectAttr(dot + ".outputX", along + ".input1" + ax)
    cmds.setAttr(along + ".input2", a.x, a.y, a.z)
    proj = cmds.createNode("plusMinusAverage", name=tag + "_inPlane")
    cmds.setAttr(proj + ".operation", 2)
    cmds.connectAttr(v + ".output", proj + ".input3D[0]")
    cmds.connectAttr(along + ".output", proj + ".input3D[1]")
    ang = cmds.createNode("angleBetween", name=tag + "_angle")
    cmds.setAttr(ang + ".vector1", rest.x, rest.y, rest.z)
    cmds.connectAttr(proj + ".output3D", ang + ".vector2")
    cross = cmds.createNode("vectorProduct", name=tag + "_turn")     # (rest x v) . a
    cmds.setAttr(cross + ".operation", 2)
    cmds.setAttr(cross + ".input1", rest.x, rest.y, rest.z)
    cmds.connectAttr(proj + ".output3D", cross + ".input2")
    way = cmds.createNode("vectorProduct", name=tag + "_way")
    cmds.setAttr(way + ".operation", 1)
    cmds.connectAttr(cross + ".output", way + ".input1")
    cmds.setAttr(way + ".input2", a.x, a.y, a.z)
    gate = cmds.createNode("condition", name=tag + "_gate")          # bent our way only
    cmds.setAttr(gate + ".operation", 2)
    cmds.connectAttr(way + ".outputX", gate + ".firstTerm")
    cmds.connectAttr(ang + ".angle", gate + ".colorIfTrueR")
    cmds.setAttr(gate + ".colorIfFalseR", 0)
    rm = cmds.createNode("remapValue", name=tag + "_amount")
    cmds.connectAttr(gate + ".outColorR", rm + ".inputValue")
    deg = cmds.currentUnit(query=True, angle=True).startswith("deg")
    cmds.setAttr(rm + ".inputMin", start if deg else math.radians(start))
    cmds.setAttr(rm + ".inputMax", full if deg else math.radians(full))
    return rm + ".outValue"

