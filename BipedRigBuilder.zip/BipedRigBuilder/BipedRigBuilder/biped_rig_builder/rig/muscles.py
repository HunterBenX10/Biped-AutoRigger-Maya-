"""Muscle (volume) joints - same idea as the reference mannequin's deltoid / backdelt /
traps / quad / hamstrings / butt / tensor / achilles joints.

Data: data/rig_rules.json > "muscles" (left side; right is mirrored). Each muscle is a
line from an ORIGIN point (riding one bone) to an INSERTION point (riding the next), both
placed on the body with a ray to the mesh surface x depth:

    origin / insertion = {"follow": joint it rides, "at": [joint_a, joint_b, t],
                          "dir": [x, y, z] world direction out to the skin, "depth": 0-1}

The muscle joint (<name>_l_hlp, child of the origin's bone):
  * sits at `follow` (0-1) between origin and insertion   (pointConstraint)
  * aims down the muscle line, up = the origin bone's Z    (aimConstraint, no flips:
                                                            the line never collapses)
  * VOLUME: length ratio r = current / rest length (world scale removed)
        scale across the muscle (X, Z) = blend(1, clamp(1 / sqrt(r)), .volume)
    shorter muscle -> fatter, longer -> thinner; the same volume either way.
    Only distances are used, so it can't flip or snap, and it eases with the pose.
  * weights: a soft capsule around the muscle line, taken only from the bones it spans.
"""
import math
import re

import maya.cmds as cmds
import maya.api.OpenMaya as om

from .. import config
from ..core import data, mathx, names, nodes

CON = "_skel_muscleConstraint"
ENDS = ("_origin", "_insert")
LIMITS = (0.7, 1.45)               # min / max cross-section scale


def defs():
    return data.rules().get("muscles", [])


def _f(s):
    return lambda n: names.for_side(n, s)


def joint_name(d, s):
    return names.for_side("{}_l_hlp".format(d["name"]), s)


def joint_names():
    return [joint_name(d, s) for d in defs() for s in "lr"]


def _point(spec, s, h, rays):
    """World position of an origin / insertion spec."""
    f, sign = _f(s), (1 if s == "l" else -1)
    a, b, t = spec["at"]
    pa, pb = mathx.pos(f(a)), mathx.pos(f(b))
    p = pa + (pb - pa) * t
    d = om.MVector(*spec.get("dir", (0, 0, 0)))
    d.x *= sign
    if d.length() < 1e-6:
        return p
    d.normalize()
    dist = rays.hit(p, d, h * 0.3) if rays else None
    dist = dist if dist else spec.get("radius", 0.04) * h
    return p + d * (dist * spec.get("depth", 0.6))


# ---------------------------------------------------------------- build (Build Skeleton)
def create(h, rays=None):
    made = []
    for d in defs():
        for s in "lr":
            f = _f(s)
            parent = f(d["origin"]["follow"])
            if not all(cmds.objExists(f(n)) for n in
                       (d["origin"]["follow"], d["insert"]["follow"])):
                continue
            o, i = _point(d["origin"], s, h, rays), _point(d["insert"], s, h, rays)
            p = o + (i - o) * d.get("follow", 0.5)
            j = cmds.createNode("joint", name=joint_name(d, s), parent=parent)
            # oriented down the muscle (Y), Z from the parent bone - rest = driven pose
            y = (i - o).normal()
            z = mathx.axis(mathx.world(parent), 2)
            z = (z - y * (z * y))
            z = (z if z.length() > 1e-3 else om.MVector(0, 0, 1)).normal()
            cmds.xform(j, ws=True, matrix=mathx.flat(mathx.compose(y ^ z, y, z, p)))
            cmds.makeIdentity(j, apply=True, rotate=True)
            cmds.setAttr(j + ".radius", h / 40.0)
            cmds.setAttr(j + ".overrideEnabled", 1)
            cmds.setAttr(j + ".overrideColor", config.HELPER_COLOR)
            for attr, val in (("origin", o), ("insert", i)):
                cmds.addAttr(j, longName="brb_" + attr, attributeType="double3")
                for ax in "XYZ":
                    cmds.addAttr(j, longName="brb_{}{}".format(attr, ax),
                                 attributeType="double", parent="brb_" + attr)
                cmds.setAttr("{}.brb_{}".format(j, attr), val.x, val.y, val.z)
            cmds.addAttr(j, longName="volume", attributeType="double", min=0, max=2,
                         defaultValue=d.get("volume", 1.0), keyable=True)
            made.append(j)
    return made


# ---------------------------------------------------------------- drivers (Skin / Rig)
def drive():
    nodes.ensure_plugins("matrixNodes")
    count = 0
    for d in defs():
        for s in "lr":
            f = _f(s)
            j = joint_name(d, s)
            if not cmds.objExists(j):
                continue
            ends = []
            for key, suffix in (("origin", ENDS[0]), ("insert", ENDS[1])):
                follow = f(d[key]["follow"])
                loc = cmds.createNode("transform", name=j + suffix, parent=follow)
                cmds.xform(loc, ws=True,
                           translation=cmds.getAttr("{}.brb_{}".format(j, key))[0])
                ends.append(loc)
            o, i = ends
            pc = cmds.pointConstraint(o, i, j, maintainOffset=False, name=j + "_point" + CON)[0]
            w0, w1 = cmds.pointConstraint(pc, q=True, weightAliasList=True)
            cmds.setAttr(pc + "." + w0, 1.0 - d.get("follow", 0.5))
            cmds.setAttr(pc + "." + w1, d.get("follow", 0.5))
            parent = cmds.listRelatives(j, parent=True)[0]
            cmds.aimConstraint(i, j, maintainOffset=True, aimVector=(0, 1, 0),
                               upVector=(0, 0, 1), worldUpType="objectrotation",
                               worldUpVector=(0, 0, 1), worldUpObject=parent,
                               name=j + "_aim" + CON)
            _volume(j, o, i, parent)
            count += 1
    return count


def _volume(j, o, i, parent):
    tag = "{}_{}".format(config.SKEL_UTIL, j)
    dist = cmds.createNode("distanceBetween", name=tag + "_length")
    cmds.connectAttr(o + ".worldMatrix[0]", dist + ".inMatrix1")
    cmds.connectAttr(i + ".worldMatrix[0]", dist + ".inMatrix2")
    rest = cmds.getAttr(dist + ".distance")
    scale = cmds.createNode("decomposeMatrix", name=tag + "_scale")      # rig scale
    cmds.connectAttr(parent + ".worldMatrix[0]", scale + ".inputMatrix")
    rest_now = nodes.mult(tag + "_rest")
    cmds.setAttr(rest_now + ".input1", max(rest, 1e-6))
    cmds.connectAttr(scale + ".outputScaleY", rest_now + ".input2")
    ratio = cmds.createNode("multiplyDivide", name=tag + "_ratio")
    cmds.setAttr(ratio + ".operation", 2)
    cmds.connectAttr(dist + ".distance", ratio + ".input1X")
    cmds.connectAttr(rest_now + ".output", ratio + ".input2X")
    inv = cmds.createNode("multiplyDivide", name=tag + "_invSqrt")         # r ^ -0.5
    cmds.setAttr(inv + ".operation", 3)
    cmds.connectAttr(ratio + ".outputX", inv + ".input1X")
    cmds.setAttr(inv + ".input2X", -0.5)
    clamp = cmds.createNode("clamp", name=tag + "_limit")
    cmds.setAttr(clamp + ".minR", LIMITS[0])
    cmds.setAttr(clamp + ".maxR", LIMITS[1])
    cmds.connectAttr(inv + ".outputX", clamp + ".inputR")
    mix = cmds.createNode("blendTwoAttr", name=tag + "_amount")
    cmds.setAttr(mix + ".input[0]", 1.0)
    cmds.connectAttr(clamp + ".outputR", mix + ".input[1]")
    cmds.connectAttr(j + ".volume", mix + ".attributesBlender")
    for ax in "XZ":
        cmds.connectAttr(mix + ".output", "{}.scale{}".format(j, ax), force=True)


def delete_patterns():
    return ["*" + CON + "*"] + ["*_hlp" + e for e in ENDS]


def reset():
    """After the drivers are deleted: muscles back to scale 1."""
    for j in joint_names():
        if cmds.objExists(j):
            for ax in "XYZ":
                plug = "{}.scale{}".format(j, ax)
                if cmds.getAttr(plug, settable=True):
                    cmds.setAttr(plug, 1)


# ---------------------------------------------------------------- skin weights
def _seg_dist(p, a, b):
    ab = b - a
    t = min(max(((p - a) * ab) / max(ab * ab, 1e-9), 0.0), 1.0)
    return (p - (a + ab * t)).length()


def apply_weights(sc, shape, h):
    from .skin import _all_vertices, _dag, _skin_fn, limit_influences
    if not defs():
        return 0
    fn, dag = _skin_fn(sc), _dag(shape)
    infl = [names.short(p.partialPathName()) for p in fn.influenceObjects()]
    index = {n: i for i, n in enumerate(infl)}
    pts = om.MFnMesh(dag).getPoints(om.MSpace.kWorld)
    comp = _all_vertices(len(pts))
    import numpy as np                      # SPEED: vectorised (was a loop per vertex)
    w, ninf = fn.getWeights(dag, comp)
    W = np.array(w).reshape(-1, ninf)
    P = np.array([(p.x, p.y, p.z) for p in pts])
    given = 0
    for d in defs():
        scale, strength = d.get("skin", (1.0, 0.45))
        for s in "lr":
            f = _f(s)
            j = joint_name(d, s)
            if j not in index:
                continue
            o = np.array(cmds.getAttr(j + ".brb_origin")[0])
            i = np.array(cmds.getAttr(j + ".brb_insert")[0])
            bases = [f(d["origin"]["follow"]), f(d["insert"]["follow"])] + \
                [f(n) for n in d.get("donors", [])]
            pattern = re.compile(r"^({})_twist_\d+(_[lr])?$".format(
                "|".join(re.escape(names.base(b)) for b in bases)))
            donors = [k for k, n in enumerate(infl)
                      if (n in bases or pattern.match(n)) and names.side(n) in (s, "c")]
            # capsule radius: the muscle's own depth below the skin, scaled
            radius = max(scale * 0.25 * float(np.linalg.norm(i - o)), h * 0.012)
            ji = index[j]
            ab = i - o
            t = np.clip((P - o) @ ab / max(float(ab @ ab), 1e-9), 0.0, 1.0)
            dist = np.linalg.norm(P - (o + np.outer(t, ab)), axis=1)
            rows = np.where(dist < radius)[0]
            if not len(rows) or not donors:
                continue
            fall = strength * (1.0 - (dist[rows] / radius) ** 2) ** 2
            moved = W[np.ix_(rows, donors)] * fall[:, None]
            W[np.ix_(rows, donors)] -= moved
            take = moved.sum(1)
            W[rows, ji] += take
            given += int((take > 1e-4).sum())
    fn.setWeights(dag, comp, om.MIntArray(list(range(ninf))), om.MDoubleArray(W.ravel()),
                  False)
    limit_influences(sc, shape)
    return given
