"""The character's geometry (one or many objects) and ray casting against it."""
import math

import maya.cmds as cmds
import maya.api.OpenMaya as om


class MeshSet(object):
    """The meshes that make up the character."""

    def __init__(self, transforms=()):
        self.transforms = []
        for t in transforms:
            if t and not cmds.objExists(t):        # moved (e.g. into Geometry): find by name
                hits = cmds.ls(t.split("|")[-1], long=True) or []
                t = hits[0] if len(hits) == 1 else None
            if t and t not in self.transforms:
                self.transforms.append(t)

    def __bool__(self):
        return bool(self.transforms)
    __nonzero__ = __bool__

    @classmethod
    def from_selection(cls):
        """Every mesh in the selection - several objects or a whole group."""
        found = []
        for s in cmds.ls(selection=True, long=True) or []:
            shapes = cmds.listRelatives(s, allDescendents=True, type="mesh", fullPath=True) or []
            if cmds.nodeType(s) == "mesh":
                shapes.append(s)
            for shp in shapes:
                if not cmds.getAttr(shp + ".intermediateObject"):
                    t = cmds.listRelatives(shp, parent=True, fullPath=True)[0]
                    if t not in found:
                        found.append(t)
        return cls(found)

    @classmethod
    def from_string(cls, text):
        return cls([t for t in (text or "").split(";") if t])

    def to_string(self):
        return ";".join(self.transforms)

    def shapes(self):
        return [s for t in self.transforms
                for s in cmds.listRelatives(t, shapes=True, type="mesh", fullPath=True) or []
                if not cmds.getAttr(s + ".intermediateObject")]

    def bbox(self):
        return cmds.exactWorldBoundingBox(self.transforms)

    def height(self):
        bb = self.bbox()
        return bb[4] - bb[1]

    def facing(self):
        """+1 if the character faces +Z (Maya's front view, what the tool expects), -1 if it
        faces -Z, 0 if it can't tell. Measured from the mesh: the feet (lowest 4%) stick out
        in front of the waist band."""
        pts = []
        for s in self.shapes():
            dag = om.MSelectionList().add(s).getDagPath(0)
            pts += [(p.y, p.z) for p in om.MFnMesh(dag).getPoints(om.MSpace.kWorld)]
        if len(pts) < 50:
            return 0
        lo = min(p[0] for p in pts)
        h = max(p[0] for p in pts) - lo
        feet = [z for y, z in pts if y < lo + 0.04 * h]
        waist = [z for y, z in pts if lo + 0.45 * h < y < lo + 0.6 * h]
        if not feet or not waist or h <= 0:
            return 0
        ahead = sum(feet) / len(feet) - sum(waist) / len(waist)
        if abs(ahead) < 0.01 * h:
            return 0
        return 1 if ahead > 0 else -1

    def see_through(self, on):
        """X-ray + unselectable, so guides inside the body can be seen and clicked."""
        for s in self.shapes():
            try:
                cmds.setAttr(s + ".overrideEnabled", int(on))
                cmds.setAttr(s + ".overrideDisplayType", 2 if on else 0)
            except RuntimeError:
                pass
        for t in self.transforms:
            try:
                cmds.displaySurface(t, xRay=on)
            except RuntimeError:
                pass

    def is_see_through(self):
        shapes = self.shapes()
        return bool(shapes) and cmds.getAttr(shapes[0] + ".overrideDisplayType") == 2

    def materials(self):
        """Shading assignments (whole object or per face), so they survive unbinding."""
        out = []
        for t in self.transforms:
            shapes = set(cmds.listRelatives(t, shapes=True, fullPath=True) or [])
            for sg in set(cmds.listConnections(list(shapes), type="shadingEngine") or []):
                mine = []
                for m in cmds.ls(cmds.sets(sg, q=True) or [], long=True) or []:
                    node, _, comp = m.partition(".")
                    if node == t or node in shapes:
                        mine.append(t + ("." + comp if comp else ""))
                if mine:
                    out.append([sg, mine])
        return out

    @staticmethod
    def restore_materials(items):
        for sg, members in items or []:
            members = [m for m in members if cmds.objExists(m.split(".")[0])]
            if members and cmds.objExists(sg):
                cmds.sets(members, edit=True, forceElement=sg)

    def rays(self):
        return Raycaster(self.shapes())


class Raycaster(object):
    """Ray casts against one or many meshes."""

    def __init__(self, shapes):
        self.fns = []
        for shp in shapes:
            sel = om.MSelectionList()
            sel.add(shp)
            fn = om.MFnMesh(sel.getDagPath(0))
            self.fns.append((fn, fn.autoUniformGridParams()))

    @staticmethod
    def _cast(fn, accel, p, v, reach):
        try:
            res = fn.closestIntersection(om.MFloatPoint(p.x, p.y, p.z),
                                         om.MFloatVector(v.x, v.y, v.z),
                                         om.MSpace.kWorld, reach, False, accelParams=accel)
        except RuntimeError:
            return None
        return res[1] if res and res[2] != -1 and res[1] > 1e-5 else None

    def hit(self, p, v, reach):
        """Distance to the surface along v, or None. Several meshes: the outermost layer
        among the meshes that wrap around p (clothes over body, head over eyes); a mesh
        that doesn't surround p (the other leg, a prop) only counts if nothing else does."""
        if len(self.fns) == 1:
            return self._cast(self.fns[0][0], self.fns[0][1], p, v, reach)
        around, nearest = [], None
        for fn, acc in self.fns:
            t = self._cast(fn, acc, p, v, reach)
            if t is None:
                continue
            nearest = t if nearest is None else min(nearest, t)
            if self._cast(fn, acc, p, -v, reach) is not None:
                around.append(t)
        return max(around) if around else nearest

    @staticmethod
    def _plane(d):
        d = d.normal()
        u = (d ^ om.MVector(0, 0, 1)) if abs(d.z) < 0.9 else (d ^ om.MVector(1, 0, 0))
        u.normalize()
        return u, d ^ u

    def centre_across(self, p, d, reach, rays=8, passes=4):
        """Move p to the middle of the cross-section perpendicular to d (chord midpoints)."""
        u, w = self._plane(d)
        for _ in range(passes):
            offs = []
            for k in range(rays):
                a = math.pi * k / rays
                v = u * math.cos(a) + w * math.sin(a)
                tp, tm = self.hit(p, v, reach), self.hit(p, -v, reach)
                if tp is not None and tm is not None:
                    offs.append(v * ((tp - tm) * 0.5))
            if len(offs) < rays // 2:
                return None
            p = p + sum(offs, om.MVector()) / len(offs)
        return p

    def four_sides(self, o, x, z, reach):
        """Distance to the surface along +X, -X, +Z, -Z (median of a 3-ray fan each;
        a side that misses borrows the opposite side)."""
        out = []
        for a, b in ((x, z), (-x, z), (z, x), (-z, x)):
            hits = sorted(t * math.cos(r) for r in (math.radians(-15), 0.0, math.radians(15))
                          for t in [self.hit(o, (a * math.cos(r) + b * math.sin(r)).normal(),
                                             reach)] if t is not None)
            out.append(hits[len(hits) // 2] if hits else None)
        for i, j in ((0, 1), (1, 0), (2, 3), (3, 2)):
            out[i] = out[j] if out[i] is None else out[i]
        return out
