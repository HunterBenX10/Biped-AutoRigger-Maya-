"""Small node helpers: undo chunks, curve shapes, placement, locking."""
from contextlib import contextmanager

import maya.cmds as cmds
import maya.api.OpenMaya as om

from . import mathx

TRS = ("tx", "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz")


@contextmanager
def undo_chunk():
    """Everything inside is one Ctrl+Z."""
    cmds.undoInfo(openChunk=True)
    try:
        yield
    finally:
        cmds.undoInfo(closeChunk=True)


def settle():
    """Force the whole DG to evaluate (so maintain-offset constraints read final values)."""
    cmds.dgdirty(allPlugs=True)
    try:
        cmds.refresh(force=True)
    except RuntimeError:
        pass


def delete(*patterns):
    found = [n for p in patterns for n in (cmds.ls(p) or [])]
    if found:
        cmds.delete(found)


def ensure_plugins(*names):
    for p in names:
        if not cmds.pluginInfo(p, q=True, loaded=True):
            cmds.loadPlugin(p, quiet=True)


def style(shape, color=None, width=1, on_top=False, reference=False, template=False):
    cmds.setAttr(shape + ".overrideEnabled", 1)
    if template:
        cmds.setAttr(shape + ".overrideDisplayType", 1)
    if color is not None:
        cmds.setAttr(shape + ".overrideColor", color)
    if reference:
        cmds.setAttr(shape + ".overrideDisplayType", 2)
    for attr, value, wanted in (("lineWidth", width, width > 1),
                                ("alwaysDrawOnTop", 1, on_top)):
        if wanted and cmds.attributeQuery(attr, node=shape, exists=True):
            cmds.setAttr("{}.{}".format(shape, attr), value)
    return shape


def add_curve(parent, points, degree=1, knots=None, periodic=False, name=None, **look):
    """Curve shape under parent, CVs given in parent space."""
    kw = {"knot": knots} if knots else {}
    tmp = cmds.curve(degree=degree, point=points, periodic=periodic, **kw)
    shp = cmds.parent(cmds.listRelatives(tmp, shapes=True)[0], parent, shape=True,
                      relative=True)[0]
    cmds.delete(tmp)
    if name:
        shp = cmds.rename(shp, name)
    return style(shp, **look) if look else shp


def add_circle(parent, normal, radius, **look):
    tmp = cmds.circle(normal=normal, radius=radius, sections=12, constructionHistory=False)[0]
    shp = cmds.parent(cmds.listRelatives(tmp, shapes=True)[0], parent, shape=True,
                      relative=True)[0]
    cmds.delete(tmp)
    return style(shp, **look)


def place(name, parent, frame, use_trs=False):
    """Transform at a world frame. Default: channels at 0, placement in Offset Parent
    Matrix. use_trs: placement in translate/rotate (for constraint-driven groups -
    constraints ignore Offset Parent Matrix)."""
    if cmds.objExists(name):
        cmds.error("'{}' already exists - Remove Preview / clean the scene first.".format(name))
    n = cmds.createNode("transform", name=name, parent=parent)
    if use_trs:
        cmds.xform(n, ws=True, matrix=mathx.flat(frame))
    else:
        pm = om.MMatrix(cmds.getAttr(parent + ".worldMatrix[0]")) if parent else om.MMatrix()
        cmds.setAttr(n + ".offsetParentMatrix", mathx.flat(frame * pm.inverse()),
                     type="matrix")
    return n


def follower(node):
    """Hidden plain child: a constraint target whose parentMatrix is the node's full
    world matrix (constraints ignore a target's own Offset Parent Matrix)."""
    d = node + "_drv"
    if not cmds.objExists(d):
        d = cmds.createNode("transform", name=d, parent=node)
        cmds.setAttr(d + ".visibility", 0)
    return d


def lock(node, attrs):
    for a in attrs:
        plug = "{}.{}".format(node, a)
        if cmds.objExists(plug):
            cmds.setAttr(plug, lock=True, keyable=False, channelBox=False)


def mult(name):
    try:
        return cmds.createNode("multDL", name=name)            # Maya 2026+
    except RuntimeError:
        return cmds.createNode("multDoubleLinear", name=name)


def add_string(node, attr, value):
    if not cmds.attributeQuery(attr, node=node, exists=True):
        cmds.addAttr(node, longName=attr, dataType="string")
    cmds.setAttr("{}.{}".format(node, attr), value, type="string")


def get_string(node, attr):
    if cmds.objExists(node) and cmds.attributeQuery(attr, node=node, exists=True):
        return cmds.getAttr("{}.{}".format(node, attr)) or ""
    return ""


# ---------------------------------------------------------------- tidy Channel Box
KEEP_VISIBLE = {"transform", "joint", "mesh", "skinCluster", "blendShape", "tweak",
                "dagPose", "displayLayer", "shadingEngine", "groupId", "groupParts"}


def snapshot():
    """Every node in the scene now (to find what a build step creates)."""
    return set(cmds.ls())


def quiet_new(before):
    """Hide everything created since `before` from the Channel Box INPUTS / OUTPUTS
    (isHistoricallyInteresting = 0): constraints, maths / utility nodes, IK handles,
    ctrl curve shapes. Nothing changes how the rig works; animators just see the ctrl's
    own channels. Skin clusters and blend shapes stay listed for riggers."""
    count = 0
    for n in set(cmds.ls()) - before:
        try:
            if cmds.nodeType(n) in KEEP_VISIBLE:
                continue
            if cmds.attributeQuery("isHistoricallyInteresting", node=n, exists=True):
                cmds.setAttr(n + ".isHistoricallyInteresting", 0)
                count += 1
        except (RuntimeError, ValueError):
            pass
    return count
