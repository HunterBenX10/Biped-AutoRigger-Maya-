"""Loads the JSON tables in data/ (cached - read once per session)."""
import json
import os
from functools import lru_cache

from .. import config


@lru_cache(maxsize=None)
def load(name):
    with open(os.path.join(config.DATA_DIR, name + ".json")) as f:
        return json.load(f)


def skeleton():
    return load("skeleton")


def guide_fit():
    return load("guide_fit")


def layout():
    return load("control_layout")


def rules():
    return load("rig_rules")
