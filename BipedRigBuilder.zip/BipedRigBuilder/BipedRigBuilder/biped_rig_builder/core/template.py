"""The skeleton template (data/skeleton.json): joint list + orientation rules."""
from . import data


class SkeletonTemplate(object):
    """Joints (left + centre only) and how each one is oriented.

    world     world-aligned joints (no aim)        aim       aim target overrides
    snap      joints with no guide (sit on another) limbs     [a, b, c, sign] bend chains
    up_from   joints whose children use their Z     twist     twist joints per joint
    mirror    chains mirrored to the right side     rotate_order  per joint ("*" default)
    """

    def __init__(self, table=None):
        t = table or data.skeleton()
        self.height = float(t["height"])
        self.joints = [tuple(j) for j in t["joints"]]          # (name, parent, position)
        self.names = [n for n, _, _ in self.joints]
        self.parent = {n: p for n, p, _ in self.joints}
        self.position = {n: pos for n, _, pos in self.joints}
        self.children = {}
        for n, p, _ in self.joints:
            self.children.setdefault(p, []).append(n)
        self.world = set(t.get("world", []))
        self.aim = t.get("aim", {})
        self.snap = t.get("snap", {})
        self.limbs = t.get("limbs", [])
        self.up_from = t.get("up_from", [])
        self.twist = t.get("twist", {})
        self.mirror = t.get("mirror", [])
        self._ro = t.get("rotate_order", {})

    def ancestors(self, name):
        p = self.parent.get(name)
        while p:
            yield p
            p = self.parent.get(p)

    def is_finger(self, name):
        return any(a in self.up_from for a in self.ancestors(name))

    def up_source(self, name):
        """The ancestor whose Z axis this joint uses as up (fingers -> hand), or None."""
        return next((a for a in self.ancestors(name) if a in self.up_from), None)

    def aim_target(self, name):
        return self.aim.get(name) or (self.children.get(name) or [None])[0]

    def first_child(self, name):
        return (self.children.get(name) or [None])[0]

    def rotate_order(self, name):
        return self._ro.get(name, self._ro.get("*", 0))


_TEMPLATE = []


def get():
    if not _TEMPLATE:
        _TEMPLATE.append(SkeletonTemplate())
    return _TEMPLATE[0]
