"""World-space matrix helpers (row-vector convention, like Maya)."""
import maya.cmds as cmds
import maya.api.OpenMaya as om

MIRROR_X = om.MMatrix([-1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1])


def pos(node):
    return om.MVector(*cmds.xform(node, q=True, ws=True, translation=True))


def flat(m):
    return [m.getElement(i // 4, i % 4) for i in range(16)]


def world(node, unscaled=True):
    m = om.MMatrix(cmds.xform(node, q=True, ws=True, matrix=True))
    if not unscaled:
        return m
    t = om.MTransformationMatrix(m)
    t.setScale((1, 1, 1), om.MSpace.kWorld)
    return t.asMatrix()


def at(p):
    """Identity rotation at point p."""
    m = om.MMatrix()
    for i in range(3):
        m.setElement(3, i, p[i])
    return m


def axis(m, i):
    """Row i (0 X, 1 Y, 2 Z) of a matrix as a unit vector."""
    return om.MVector(m.getElement(i, 0), m.getElement(i, 1), m.getElement(i, 2)).normal()


def origin(m):
    return om.MVector(m.getElement(3, 0), m.getElement(3, 1), m.getElement(3, 2))


def compose(x, y, z, p):
    return om.MMatrix([x.x, x.y, x.z, 0, y.x, y.y, y.z, 0, z.x, z.y, z.z, 0, p.x, p.y, p.z, 1])
