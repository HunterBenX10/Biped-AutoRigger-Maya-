"""Side and naming rules: foo_l / foo_r / foo (centre)."""
import re

_SIDE = re.compile(r"(?<=_)([lLrR])(?=_|$)")


HELPER = "_hlp"


def side(name):
    """'l', 'r' or 'c' from a joint-style name (suffix; helpers: pec_l_hlp -> 'l')."""
    if name.endswith(HELPER):
        name = name[:-len(HELPER)]
    return "l" if name.endswith("_l") else "r" if name.endswith("_r") else "c"


def is_left(name):
    """True if any token is l/L (leg_l_grp, hand_L_grp, upperarm_l_fk_ctrl...)."""
    return any(m.group(1) in "lL" for m in _SIDE.finditer(name or ""))


def mirror(name):
    """Left name -> right name (keeps the letter case)."""
    if not name:
        return name
    return _SIDE.sub(lambda m: {"l": "r", "L": "R"}.get(m.group(1), m.group(1)), name)


def for_side(name, s):
    return mirror(name) if s == "r" else name


def base(name):
    """thigh_twist_01_l -> thigh_twist_01 (for joint labels)."""
    if name.endswith(HELPER):
        return base(name[:-len(HELPER)]) + HELPER          # pec_l_hlp -> pec_hlp
    return name[:-2] if side(name) != "c" else name


def short(node):
    return node.split("|")[-1].split(":")[-1]
