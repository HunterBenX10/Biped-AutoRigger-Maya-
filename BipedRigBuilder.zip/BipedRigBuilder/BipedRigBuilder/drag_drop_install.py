"""Biped Rig Builder - installer.

DRAG THIS FILE INTO THE MAYA VIEWPORT (keep it next to the biped_rig_builder folder).

It copies biped_rig_builder into your Maya scripts folder, adds a button to the shelf
you have open, and opens the tool. Drop it again any time to update / reinstall.
"""
import os
import shutil
import stat
import sys

import maya.cmds as cmds
import maya.mel as mel

PKG = "biped_rig_builder"
TITLE = "Biped Rig Builder"
COMMAND = ("import sys\n"
           "for _m in [m for m in sys.modules if m == '{0}' or m.startswith('{0}.')]:\n"
           "    del sys.modules[_m]\n"
           "import {0}\n"
           "{0}.show()\n").format(PKG)


def onMayaDroppedPythonFile(*_):
    """Maya calls this when the file is dropped into the viewport."""
    install()


def _source_folder():
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else ""
    if here and os.path.isdir(os.path.join(here, PKG)):
        return here
    picked = cmds.fileDialog2(fileMode=3, caption="Pick the folder that contains '{}'".format(
        PKG))
    if picked and os.path.isdir(os.path.join(picked[0], PKG)):
        return picked[0]
    cmds.error("Couldn't find the '{}' folder next to the installer.".format(PKG))


def _shelf_button(icon):
    top = mel.eval("$_brb_tmp = $gShelfTopLevel")
    shelf = cmds.tabLayout(top, query=True, selectTab=True)
    for b in cmds.shelfLayout(shelf, query=True, childArray=True) or []:
        if cmds.objectTypeUI(b) == "shelfButton" and \
                cmds.shelfButton(b, query=True, annotation=True) == TITLE:
            cmds.deleteUI(b)                                  # no duplicates on reinstall
    cmds.shelfButton(parent=shelf, label="BipedRig", annotation=TITLE, image=icon,
                     image1=icon, command=COMMAND, sourceType="python",
                     imageOverlayLabel="")
    cmds.saveAllShelves(top)
    return shelf


def _writable(path):
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    except OSError:
        pass


def _sync(src, dst):
    """Copy the package OVER the installed one, file by file. Never deletes the folder
    first: on Windows / OneDrive a folder that's synced, indexed or open in Explorer
    can't be removed (that was the 'Access is denied'). Returns files it couldn't
    replace."""
    skipped = []
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        rel = os.path.relpath(root, src)
        out = os.path.join(dst, rel) if rel != "." else dst
        if not os.path.isdir(out):
            os.makedirs(out)
        for f in files:
            if f.endswith(".pyc"):
                continue
            target = os.path.join(out, f)
            try:
                if os.path.exists(target):
                    _writable(target)
                shutil.copyfile(os.path.join(root, f), target)
            except (IOError, OSError):
                skipped.append(os.path.relpath(target, dst))
    for root, dirs, files in os.walk(dst):          # stale bytecode from older versions
        for f in files:
            if f.endswith(".pyc"):
                try:
                    _writable(os.path.join(root, f))
                    os.remove(os.path.join(root, f))
                except OSError:
                    pass
    return skipped


def install():
    src = os.path.join(_source_folder(), PKG)
    scripts = cmds.internalVar(userScriptDir=True)
    dst = os.path.join(scripts, PKG)
    for name in [m for m in sys.modules if m == PKG or m.startswith(PKG + ".")]:
        del sys.modules[name]                     # let go of the old copy first
    skipped = _sync(src, dst)
    if skipped:
        cmds.warning("{} file(s) were in use and kept their old version (OneDrive / an "
                     "open Explorer window?): {}. Close Maya and drop again to finish."
                     .format(len(skipped), ", ".join(skipped[:3])))
    # the installed copy wins over any other copy (e.g. an unzipped folder in Downloads)
    sys.path[:] = [p for p in sys.path if not os.path.isdir(os.path.join(p, PKG)) or
                   os.path.normcase(os.path.abspath(p)) ==
                   os.path.normcase(os.path.abspath(scripts))]
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    icon = os.path.join(dst, "icons", "biped_rig_builder.png").replace("\\", "/")
    shelf = _shelf_button(icon)
    exec(COMMAND, {})
    cmds.inViewMessage(amg="<hl>{}</hl> installed - button added to the '{}' shelf.".format(
        TITLE, shelf), pos="topCenter", fade=True)
    print("{} installed to {}".format(TITLE, dst))


if __name__ == "__main__":                                   # pasted into the Script Editor
    install()
